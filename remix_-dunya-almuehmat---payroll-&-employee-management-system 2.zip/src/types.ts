export type NationalityType = 'Saudi' | 'Expat';
export type EmployeeStatus = 'active' | 'inactive';
export type LeaveStatus = 'pending' | 'approved' | 'rejected';
export type LeaveType = 'Annual' | 'Sick' | 'Emergency' | 'Unpaid';
export type CashAdvanceStatus = 'active' | 'paid';

export interface Admin {
  id: number;
  username: string;
  created_at?: string;
}

export interface Employee {
  id: number;
  employee_id: string;
  full_name: string;
  nationality: NationalityType;
  iqama_number: string;
  iqama_expiry: string;
  passport_number: string;
  job_title: string;
  hire_date: string;
  basic_salary: number;
  allowances: number;
  insurance: number;
  iban: string;
  pin_code?: string;
  phone_number?: string;
  email?: string;
  status: EmployeeStatus;
}

export interface AttendanceRecord {
  id: number;
  employee_id: number;
  employee_name?: string;
  employee_code?: string;
  date: string;
  time_in: string | null;
  time_out: string | null;
}

export interface OvertimeRule {
  id: number;
  rule_name: string;
  multiplier: number;
  description?: string;
  is_active: number;
}

export type BonusType = 'Performance Bonus' | 'Holiday / Eid Bonus' | 'Signing Bonus' | 'Custom Incentive';

export interface EmployeeBonus {
  id: number;
  employee_id: number;
  employee_name?: string;
  employee_code?: string;
  bonus_type: BonusType;
  amount: number;
  effective_date: string;
  description?: string;
  status: 'pending' | 'processed' | 'cancelled';
  payroll_id?: number | null;
  created_at?: string;
}

export interface PayrollRecord {
  id: number;
  employee_id: number;
  employee_name?: string;
  employee_code?: string;
  job_title?: string;
  iban?: string;
  period_start: string;
  period_end: string;
  basic_salary: number;
  allowances: number;
  present_days?: number;
  absent_days?: number;
  unpaid_leave_days?: number;
  daily_rate?: number;
  attendance_deduction?: number;
  deductions: number;
  insurance_deduction: number;
  cash_advance_deduction: number;
  overtime_hours?: number;
  overtime_pay?: number;
  overtime_rule_id?: number;
  bonus_pay?: number;
  bonus_details?: string;
  net_salary: number;
  status?: 'draft' | 'processed' | 'paid';
  generated_date: string;
}

export interface CashAdvance {
  id: number;
  employee_id: number;
  employee_name?: string;
  employee_code?: string;
  amount: number;
  balance: number;
  monthly_deduction: number;
  status: CashAdvanceStatus;
  created_at?: string;
}

export interface LeaveRequest {
  id: number;
  employee_id: number;
  employee_name?: string;
  employee_code?: string;
  leave_type: LeaveType;
  start_date: string;
  end_date: string;
  reason?: string;
  status: LeaveStatus;
  created_at?: string;
}

export interface DashboardStats {
  totalEmployees: number;
  activeEmployees: number;
  saudiCount: number;
  expatCount: number;
  presentToday: number;
  pendingLeaves: number;
  activeAdvancesTotal: number;
  currentMonthPayrollTotal: number;
  iqamaExpiringSoonCount: number;
}

export type NotificationType = 'leave_approved' | 'salary_released' | 'cash_advance_deducted' | 'system';

export interface AppNotification {
  id: number;
  employee_id?: number | null;
  employee_name?: string;
  employee_code?: string;
  type: NotificationType;
  title: string;
  message: string;
  is_read: number;
  created_at: string;
}
