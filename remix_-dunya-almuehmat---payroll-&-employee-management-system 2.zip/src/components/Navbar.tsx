import React, { useState, useEffect } from 'react';
import {
  Building2,
  Clock,
  Shield,
  Monitor,
  LogOut,
  Bell,
  CheckCircle2,
  Banknote,
  MinusCircle,
  X,
  Check,
} from 'lucide-react';
import { api } from '../lib/api';
import { AppNotification } from '../types';

interface NavbarProps {
  mode: 'admin' | 'kiosk' | 'login';
  adminUsername?: string;
  onSwitchToKiosk: () => void;
  onLogout: () => void;
  onOpenSettings?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  mode,
  adminUsername,
  onSwitchToKiosk,
  onLogout,
}) => {
  const [time, setTime] = useState<string>('');
  const [date, setDate] = useState<string>('');

  // Notifications State
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  const fetchNotifications = async () => {
    try {
      const list = await api.getNotifications();
      setNotifications(list);
    } catch (err) {
      // silent
    }
  };

  useEffect(() => {
    fetchNotifications();
    const notifInterval = setInterval(fetchNotifications, 12000);
    return () => clearInterval(notifInterval);
  }, []);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }));
      setDate(now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }));
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const handleMarkAllRead = async () => {
    try {
      await api.markNotificationRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
    } catch (err) {
      console.error(err);
    }
  };

  const getNotifIcon = (type: string) => {
    switch (type) {
      case 'leave_approved':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'salary_released':
        return <Banknote className="w-4 h-4 text-sky-400" />;
      case 'cash_advance_deducted':
        return <MinusCircle className="w-4 h-4 text-amber-400" />;
      default:
        return <Bell className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <header id="main-header" className="bg-[#1e293b]/90 backdrop-blur border-b border-slate-700 text-white sticky top-0 z-40 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between relative">
        
        {/* Brand & Company Name */}
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-sky-500 flex items-center justify-center text-white font-bold text-lg shadow-md shadow-sky-500/20">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-base sm:text-lg text-sky-400 tracking-wider uppercase leading-tight">
              Dunya AlMuehmat
            </h1>
            <p className="text-[11px] text-slate-400 font-medium">
              for Office Equipments <span className="text-emerald-400 font-arabic ml-1">· دنيا المهمات</span>
            </p>
          </div>
        </div>

        {/* Live Clock & Network Indicator */}
        <div className="hidden md:flex items-center space-x-6 text-sm">
          <div className="flex items-center space-x-2 bg-slate-800/90 px-3 py-1.5 rounded-lg border border-slate-700">
            <Clock className="w-4 h-4 text-sky-400 animate-pulse" />
            <span className="font-mono font-medium text-slate-200">{time}</span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400 text-xs">{date}</span>
          </div>

          <div className="flex items-center space-x-1.5 text-xs text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping"></span>
            <span className="font-mono text-emerald-400 font-medium">● LAN Online</span>
            <span className="text-slate-500">(SAR)</span>
          </div>
        </div>

        {/* User Controls & Kiosk Switch */}
        <div className="flex items-center space-x-3">
          
          {/* Notification Center Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifMenu(!showNotifMenu)}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition relative"
              title="System Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-sky-500 text-slate-950 font-bold text-[10px] rounded-full flex items-center justify-center animate-bounce">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown Panel */}
            {showNotifMenu && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#1e293b] border border-slate-700 rounded-xl shadow-2xl z-50 overflow-hidden text-xs">
                <div className="p-3 bg-slate-900 border-b border-slate-700 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-sky-400" />
                    <span className="font-bold text-white">HR & System Activity Notifications</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {unreadCount > 0 && (
                      <button
                        onClick={handleMarkAllRead}
                        className="text-[10px] text-sky-400 hover:underline flex items-center gap-1 font-medium"
                      >
                        <Check className="w-3 h-3" />
                        <span>Mark read</span>
                      </button>
                    )}
                    <button onClick={() => setShowNotifMenu(false)} className="text-slate-400 hover:text-white">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="max-h-80 overflow-y-auto divide-y divide-slate-800">
                  {notifications.length === 0 ? (
                    <div className="p-6 text-center text-slate-500">No notifications yet.</div>
                  ) : (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        className={`p-3 transition ${n.is_read ? 'bg-slate-900/40 opacity-75' : 'bg-slate-800/80 border-l-2 border-sky-400'}`}
                      >
                        <div className="flex items-start gap-2.5">
                          <div className="mt-0.5">{getNotifIcon(n.type)}</div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-slate-200">{n.title}</span>
                              <span className="text-[10px] text-slate-500 font-mono">
                                {n.created_at ? new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-300 mt-0.5 leading-snug">{n.message}</p>
                            {n.employee_name && (
                              <span className="inline-block mt-1 text-[10px] bg-slate-900 text-sky-300 px-1.5 py-0.5 rounded border border-slate-700">
                                Employee: {n.employee_name} ({n.employee_code})
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {mode === 'admin' && (
            <>
              <button
                id="btn-switch-kiosk"
                onClick={onSwitchToKiosk}
                className="flex items-center space-x-2 bg-sky-500 hover:bg-sky-600 text-white px-3.5 py-2 rounded-lg text-xs font-bold shadow-lg shadow-sky-500/20 transition"
                title="Switch to Employee Punch Kiosk"
              >
                <Monitor className="w-4 h-4" />
                <span className="hidden sm:inline">Launch Employee Kiosk</span>
              </button>

              <div className="flex items-center space-x-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 text-xs">
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-slate-300 font-medium">{adminUsername || 'Admin'}</span>
              </div>

              <button
                id="btn-admin-logout"
                onClick={onLogout}
                className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </>
          )}

          {mode === 'kiosk' && (
            <button
              id="btn-exit-kiosk"
              onClick={onLogout}
              className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-700 transition"
            >
              <Shield className="w-3.5 h-3.5 text-slate-400" />
              <span>Admin Login</span>
            </button>
          )}
        </div>

      </div>
    </header>
  );
};
