import React, { useState, useEffect } from 'react';
import {
  Clock,
  UserCheck,
  Search,
  Calendar,
  CheckCircle2,
  AlertCircle,
  X,
  Send,
  Building2,
  User,
  History,
  LogIn,
  LogOut,
  FileText,
  Eye,
  Lock,
  Unlock,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';
import { Employee, AttendanceRecord, LeaveRequest, PayrollRecord } from '../types';
import { api } from '../lib/api';
import { PayslipModal } from './PayslipModal';

interface KioskViewProps {
  onBackToAdmin: () => void;
}

export const KioskView: React.FC<KioskViewProps> = ({ onBackToAdmin }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmpId, setSelectedEmpId] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  // Time state
  const [currentTime, setCurrentTime] = useState('');
  const [currentDate, setCurrentDate] = useState('');

  // Toast / Alert feedback
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error';
    title: string;
    message: string;
  } | null>(null);

  // Recent logs for selected employee
  const [employeePunches, setEmployeePunches] = useState<AttendanceRecord[]>([]);
  const [employeeLeaves, setEmployeeLeaves] = useState<LeaveRequest[]>([]);
  const [employeePayslips, setEmployeePayslips] = useState<PayrollRecord[]>([]);
  const [selectedPayslip, setSelectedPayslip] = useState<PayrollRecord | null>(null);

  // Confidential Paystub PIN Vault Protection
  const [isPaystubUnlocked, setIsPaystubUnlocked] = useState(false);
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [verifyingPin, setVerifyingPin] = useState(false);

  // Leave Modal
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [leaveForm, setLeaveForm] = useState({
    leave_type: 'Annual',
    start_date: new Date().toISOString().split('T')[0],
    end_date: new Date().toISOString().split('T')[0],
    reason: '',
  });

  // Clock runner
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
      setCurrentDate(
        now.toLocaleDateString('en-US', {
          weekday: 'long',
          month: 'long',
          day: 'numeric',
          year: 'numeric',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Load employees
  const loadEmployees = async () => {
    try {
      setLoading(true);
      const data = await api.getEmployees({ status: 'active' });
      setEmployees(data);
      if (data.length > 0 && !selectedEmpId) {
        setSelectedEmpId(data[0].id);
      }
    } catch (err: any) {
      console.error('Error loading kiosk employees', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEmployees();
  }, []);

  // Fetch history for selected employee
  const loadEmployeeHistory = async (empId: number) => {
    try {
      const punches = await api.getAttendance({ employee_id: empId });
      setEmployeePunches(punches.slice(0, 5));

      const leaves = await api.getLeaveRequests();
      setEmployeeLeaves(leaves.filter((l) => l.employee_id === empId).slice(0, 5));

      const payslips = await api.getPayroll({ employee_id: empId });
      setEmployeePayslips(payslips.slice(0, 5));
    } catch (err) {
      console.error('Error loading history', err);
    }
  };

  useEffect(() => {
    if (selectedEmpId) {
      setIsPaystubUnlocked(false);
      setPinInput('');
      setPinError(null);
      loadEmployeeHistory(selectedEmpId);
    }
  }, [selectedEmpId]);

  const handleVerifyPinSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedEmpId || !pinInput) return;

    try {
      setVerifyingPin(true);
      setPinError(null);
      const res = await api.verifyEmployeePin(selectedEmpId, pinInput);
      if (res.verified) {
        setIsPaystubUnlocked(true);
        setShowPinModal(false);
        setPinInput('');
      } else {
        setPinError(res.error || 'Incorrect Security PIN or Iqama digits.');
      }
    } catch (err: any) {
      setPinError(err.message || 'Incorrect Security PIN or Iqama digits.');
    } finally {
      setVerifyingPin(false);
    }
  };

  const selectedEmployee = employees.find((e) => e.id === selectedEmpId);

  // Handle Punch In or Punch Out
  const handlePunch = async (action: 'in' | 'out') => {
    if (!selectedEmpId) return;
    setActionLoading(true);
    setFeedback(null);

    try {
      const res = await api.kioskPunch(selectedEmpId, action);
      setFeedback({
        type: 'success',
        title: action === 'in' ? 'Punch In Successful!' : 'Punch Out Successful!',
        message: res.message,
      });
      loadEmployeeHistory(selectedEmpId);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'Action Failed',
        message: err.message || 'Error recording attendance.',
      });
    } finally {
      setActionLoading(false);
    }
  };

  // Submit Leave Request
  const handleLeaveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmpId) return;
    setActionLoading(true);

    try {
      await api.createLeaveRequest({
        employee_id: selectedEmpId,
        leave_type: leaveForm.leave_type,
        start_date: leaveForm.start_date,
        end_date: leaveForm.end_date,
        reason: leaveForm.reason,
      });

      setFeedback({
        type: 'success',
        title: 'Leave Request Submitted',
        message: `Your ${leaveForm.leave_type} leave request from ${leaveForm.start_date} to ${leaveForm.end_date} has been sent to management for approval.`,
      });
      setShowLeaveModal(false);
      loadEmployeeHistory(selectedEmpId);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        title: 'Request Failed',
        message: err.message || 'Error submitting leave request.',
      });
    } finally {
      setActionLoading(false);
    }
  };

  const filteredEmployees = employees.filter(
    (e) =>
      e.full_name.toLowerCase().includes(search.toLowerCase()) ||
      e.employee_id.toLowerCase().includes(search.toLowerCase()) ||
      e.job_title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div id="kiosk-container" className="min-h-screen bg-[#0f172a] text-slate-100 flex flex-col p-4 sm:p-6 lg:p-8 select-none">
      
      {/* Kiosk Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between bg-[#1e293b] border border-slate-700 rounded-xl p-4 sm:p-6 shadow-xl mb-6 gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-sky-500 text-white flex items-center justify-center font-bold text-2xl shadow-lg shadow-sky-500/20">
            <Building2 className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white italic serif">
              Dunya AlMuehmat - Employee Attendance Kiosk
            </h1>
            <p className="text-xs text-slate-400 font-arabic">
              دنيا المهمات لمعدات المكاتب · نظام الحضور والغياب
            </p>
          </div>
        </div>

        {/* Big Live Digital Clock */}
        <div className="flex items-center space-x-4 bg-slate-900 px-5 py-3 rounded-xl border border-slate-700 text-center sm:text-right">
          <Clock className="w-6 h-6 text-sky-400 animate-pulse hidden sm:block" />
          <div>
            <div className="font-mono text-2xl sm:text-3xl font-extrabold text-sky-400 tracking-wider">
              {currentTime}
            </div>
            <div className="text-xs text-slate-400 font-medium">{currentDate}</div>
          </div>
        </div>
      </div>

      {/* Main Kiosk Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1">
        
        {/* Left Panel: Employee Selector (5 cols) */}
        <div className="lg:col-span-5 bg-[#1e293b] border border-slate-700 rounded-xl p-5 flex flex-col h-[550px] lg:h-[650px] shadow-xl">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-700">
            <h2 className="text-base font-bold text-slate-200 flex items-center gap-2 italic serif">
              <User className="w-5 h-5 text-sky-400" />
              1. Select Employee Name
            </h2>
            <span className="text-xs bg-slate-900 border border-slate-700 px-2.5 py-1 rounded-full text-slate-400 font-mono">
              {employees.length} Active
            </span>
          </div>

          {/* Search bar */}
          <div className="relative mb-4">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            <input
              id="input-kiosk-search"
              type="text"
              placeholder="Search by name, ID or title..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-sky-400"
            />
          </div>

          {/* Employee Grid/List */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {loading ? (
              <div className="text-center text-slate-500 py-10 text-sm">Loading employees list...</div>
            ) : filteredEmployees.length === 0 ? (
              <div className="text-center text-slate-500 py-10 text-sm">No active employees found matching query.</div>
            ) : (
              filteredEmployees.map((emp) => {
                const isSelected = emp.id === selectedEmpId;
                return (
                  <button
                    key={emp.id}
                    id={`kiosk-emp-${emp.id}`}
                    onClick={() => {
                      setSelectedEmpId(emp.id);
                      setFeedback(null);
                    }}
                    className={`w-full text-left p-3.5 rounded-lg border transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-sky-500/10 border-sky-400 shadow-md ring-1 ring-sky-400/50 text-white'
                        : 'bg-slate-900/60 border-slate-700/60 hover:bg-slate-800/60 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm ${
                          isSelected ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {emp.full_name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-sm leading-tight text-slate-100">{emp.full_name}</div>
                        <div className="text-xs text-slate-400 mt-0.5">
                          <span className="font-mono text-sky-400">{emp.employee_id}</span> • {emp.job_title}
                        </div>
                      </div>
                    </div>
                    {isSelected && <CheckCircle2 className="w-5 h-5 text-sky-400 flex-shrink-0" />}
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Panel: Action Punch Area (7 cols) */}
        <div className="lg:col-span-7 flex flex-col space-y-6">
          
          {/* Active Employee Banner */}
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-6 shadow-xl">
            {selectedEmployee ? (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] uppercase tracking-widest font-bold text-sky-400">
                    Selected Employee
                  </span>
                  <h2 className="text-2xl font-black text-white mt-1 italic serif">{selectedEmployee.full_name}</h2>
                  <div className="flex flex-wrap items-center gap-2 mt-2 text-xs text-slate-400">
                    <span className="bg-slate-900 border border-slate-700 px-2.5 py-1 rounded-md text-slate-300 font-mono">
                      {selectedEmployee.employee_id}
                    </span>
                    <span>•</span>
                    <span>{selectedEmployee.job_title}</span>
                    <span>•</span>
                    <span className="bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-slate-300">
                      {selectedEmployee.nationality}
                    </span>
                  </div>
                </div>

                <div className="text-right border-t sm:border-t-0 sm:border-l border-slate-700 pt-3 sm:pt-0 sm:pl-6">
                  <div className="text-xs text-slate-500">Iqama / ID</div>
                  <div className="font-mono text-sm text-slate-200">{selectedEmployee.iqama_number}</div>
                </div>
              </div>
            ) : (
              <div className="text-center py-6 text-slate-500">Please select an employee from the left panel.</div>
            )}
          </div>

          {/* Feedback Toast Banner */}
          {feedback && (
            <div
              className={`p-4 rounded-xl border flex items-start gap-3 shadow-lg ${
                feedback.type === 'success'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-100'
                  : 'bg-red-500/10 border-red-500/30 text-red-100'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <h4 className="font-bold text-sm">{feedback.title}</h4>
                <p className="text-xs mt-0.5 opacity-90">{feedback.message}</p>
              </div>
              <button
                onClick={() => setFeedback(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Touch Punch Buttons (iPad Friendly) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Punch In Button */}
            <button
              id="btn-kiosk-punch-in"
              disabled={!selectedEmpId || actionLoading}
              onClick={() => handlePunch('in')}
              className="p-6 bg-sky-500 hover:bg-sky-600 active:scale-[0.98] disabled:opacity-50 text-white rounded-xl shadow-lg shadow-sky-500/20 border border-sky-400 transition flex flex-col items-center justify-center text-center space-y-2 group"
            >
              <div className="w-14 h-14 rounded-full bg-white/10 flex items-center justify-center group-hover:scale-110 transition">
                <LogIn className="w-8 h-8 text-white" />
              </div>
              <span className="text-xl font-black tracking-wide italic serif">PUNCH IN</span>
              <span className="text-xs text-sky-100 opacity-90 font-medium">Record Shift Arrival</span>
            </button>

            {/* Punch Out Button */}
            <button
              id="btn-kiosk-punch-out"
              disabled={!selectedEmpId || actionLoading}
              onClick={() => handlePunch('out')}
              className="p-6 bg-amber-500 hover:bg-amber-600 active:scale-[0.98] disabled:opacity-50 text-slate-950 rounded-xl shadow-lg shadow-amber-500/20 border border-amber-400 transition flex flex-col items-center justify-center text-center space-y-2 group"
            >
              <div className="w-14 h-14 rounded-full bg-slate-950/10 flex items-center justify-center group-hover:scale-110 transition">
                <LogOut className="w-8 h-8 text-slate-950" />
              </div>
              <span className="text-xl font-black tracking-wide italic serif">PUNCH OUT</span>
              <span className="text-xs text-slate-900 opacity-90 font-bold">Record Shift Departure</span>
            </button>

          </div>

          {/* Leave Request Action */}
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center text-sky-400">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-100">Need Leave / Time Off?</h3>
                <p className="text-xs text-slate-400">Submit an official leave application to admin</p>
              </div>
            </div>
            <button
              id="btn-kiosk-request-leave"
              disabled={!selectedEmpId}
              onClick={() => setShowLeaveModal(true)}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 active:bg-slate-800 text-slate-100 font-bold rounded-lg text-xs border border-slate-700 transition flex items-center gap-2 shadow-sm"
            >
              <Send className="w-4 h-4 text-sky-400" />
              <span>Request Leave</span>
            </button>
          </div>

          {/* Recent Activity Log for selected employee */}
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl flex-1 flex flex-col min-h-[200px]">
            <h3 className="text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-3 flex items-center gap-2">
              <History className="w-4 h-4 text-slate-500" />
              Recent Kiosk Activity for {selectedEmployee?.full_name || 'Selected Employee'}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1">
              
              {/* Recent Punches */}
              <div className="bg-slate-900 rounded-lg p-3 border border-slate-700">
                <div className="text-xs font-semibold text-slate-300 mb-2">Punch History (Last 5)</div>
                {employeePunches.length === 0 ? (
                  <div className="text-xs text-slate-500 py-3 text-center">No punch logs recorded yet.</div>
                ) : (
                  <div className="space-y-1.5 text-xs">
                    {employeePunches.map((p) => (
                      <div key={p.id} className="flex justify-between items-center py-1 border-b border-slate-800 last:border-0">
                        <span className="text-slate-400 font-mono">{p.date}</span>
                        <div className="space-x-2 font-mono">
                          <span className="text-emerald-400">IN: {p.time_in || '--'}</span>
                          <span className="text-amber-400">OUT: {p.time_out || '--'}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Recent Leaves */}
              <div className="bg-slate-900 rounded-lg p-3 border border-slate-700">
                <div className="text-xs font-semibold text-slate-300 mb-2">Leave Requests</div>
                {employeeLeaves.length === 0 ? (
                  <div className="text-xs text-slate-500 py-3 text-center">No leave requests found.</div>
                ) : (
                  <div className="space-y-1.5 text-xs">
                    {employeeLeaves.map((l) => (
                      <div key={l.id} className="flex justify-between items-center py-1 border-b border-slate-800 last:border-0">
                        <div>
                          <span className="font-semibold text-slate-200">{l.leave_type}</span>
                          <span className="text-slate-400 text-[11px] block">{l.start_date} to {l.end_date}</span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            l.status === 'approved'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : l.status === 'rejected'
                              ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {l.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Confidential Salary Payslips */}
              <div className="bg-slate-900 rounded-lg p-3 border border-slate-700">
                <div className="text-xs font-semibold text-slate-300 mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-sky-400" />
                    <span>Issued Payslips & Paystubs</span>
                  </div>
                  {isPaystubUnlocked ? (
                    <button
                      onClick={() => setIsPaystubUnlocked(false)}
                      className="text-[10px] text-amber-400 hover:text-amber-300 flex items-center gap-1 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30 transition"
                      title="Lock confidential vault"
                    >
                      <Lock className="w-3 h-3" />
                      <span>Lock Vault</span>
                    </button>
                  ) : (
                    <span className="text-[10px] text-amber-400/80 flex items-center gap-1 font-mono">
                      <Lock className="w-3 h-3" />
                      Protected
                    </span>
                  )}
                </div>

                {employeePayslips.length === 0 ? (
                  <div className="text-xs text-slate-500 py-3 text-center">No payslips issued yet.</div>
                ) : !isPaystubUnlocked ? (
                  /* LOCKED PRIVATE PAYSTUB STATE */
                  <div className="p-3 bg-slate-950/60 rounded-lg border border-amber-500/20 text-center space-y-2">
                    <div className="w-8 h-8 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-full flex items-center justify-center mx-auto">
                      <KeyRound className="w-4 h-4" />
                    </div>
                    <div className="text-xs font-bold text-amber-300">Confidential Paystub Vault</div>
                    <p className="text-[11px] text-slate-400 leading-tight">
                      {employeePayslips.length} paystub(s) available. PIN verification required for employee privacy.
                    </p>
                    <button
                      onClick={() => setShowPinModal(true)}
                      className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs transition shadow-md shadow-amber-500/20 flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Enter PIN / Iqama Digits</span>
                    </button>
                  </div>
                ) : (
                  /* UNLOCKED STATE */
                  <div className="space-y-1.5 text-xs">
                    <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] px-2 py-1 rounded flex items-center gap-1 font-medium mb-2">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Vault Unlocked for {selectedEmployee?.full_name}</span>
                    </div>
                    {employeePayslips.map((ps) => (
                      <div key={ps.id} className="flex justify-between items-center py-1 border-b border-slate-800 last:border-0">
                        <div>
                          <span className="font-mono text-sky-400 font-bold block">{ps.net_salary?.toLocaleString()} SAR</span>
                          <span className="text-slate-400 text-[10px]">{ps.period_start} to {ps.period_end}</span>
                        </div>
                        <button
                          onClick={() => setSelectedPayslip(ps)}
                          className="px-2 py-1 bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30 rounded text-[10px] font-bold flex items-center gap-1 transition active:scale-95"
                        >
                          <Eye className="w-3 h-3" />
                          <span>PDF Paystub</span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>

        </div>

      </div>

      {/* LEAVE MODAL */}
      {showLeaveModal && selectedEmployee && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700 mb-4">
              <h3 className="font-bold text-lg text-slate-100 flex items-center gap-2 italic serif">
                <Calendar className="w-5 h-5 text-sky-400" />
                Submit Leave Request
              </h3>
              <button
                onClick={() => setShowLeaveModal(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Applying for: <strong className="text-sky-400">{selectedEmployee.full_name}</strong> ({selectedEmployee.employee_id})
            </p>

            <form onSubmit={handleLeaveSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Leave Type
                </label>
                <select
                  value={leaveForm.leave_type}
                  onChange={(e) => setLeaveForm({ ...leaveForm, leave_type: e.target.value })}
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                >
                  <option value="Annual">Annual Paid Leave</option>
                  <option value="Sick">Sick Leave</option>
                  <option value="Emergency">Emergency Leave</option>
                  <option value="Unpaid">Unpaid Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    required
                    value={leaveForm.start_date}
                    onChange={(e) => setLeaveForm({ ...leaveForm, start_date: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    required
                    value={leaveForm.end_date}
                    onChange={(e) => setLeaveForm({ ...leaveForm, end_date: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Reason / Notes (Optional)
                </label>
                <textarea
                  rows={3}
                  placeholder="Describe your reason for leave..."
                  value={leaveForm.reason}
                  onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="pt-3 flex items-center justify-end space-x-3 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setShowLeaveModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="px-5 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-xs font-bold shadow-lg shadow-sky-500/20"
                >
                  {actionLoading ? 'Submitting...' : 'Submit Leave Application'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SECURITY PIN VERIFICATION MODAL */}
      {showPinModal && selectedEmployee && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1e293b] border border-amber-500/40 rounded-2xl w-full max-w-sm p-6 shadow-2xl relative text-center">
            <button
              onClick={() => {
                setShowPinModal(false);
                setPinInput('');
                setPinError(null);
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-full flex items-center justify-center mx-auto mb-3">
              <Lock className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-bold text-white font-serif italic">
              Confidential Paystub Access
            </h3>
            <p className="text-xs text-slate-300 mt-1 mb-4 leading-relaxed">
              To view salary details for <strong className="text-amber-300">{selectedEmployee.full_name}</strong>, enter your 4-digit Security PIN or the last 4 digits of your Iqama/ID.
            </p>

            <form onSubmit={handleVerifyPinSubmit} className="space-y-3">
              <div>
                <input
                  type="password"
                  maxLength={10}
                  autoFocus
                  placeholder="Enter PIN / Iqama Digits"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  className="w-full text-center tracking-[0.3em] font-mono text-xl py-2.5 px-4 bg-slate-900 border border-amber-500/40 rounded-xl text-amber-300 focus:outline-none focus:border-amber-400 shadow-inner"
                />
              </div>

              {pinError && (
                <div className="bg-red-500/10 border border-red-500/30 text-red-400 text-xs p-2 rounded-lg flex items-center justify-center gap-1.5 font-medium">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{pinError}</span>
                </div>
              )}

              {/* Touch Keypad for Kiosk Screen */}
              <div className="grid grid-cols-3 gap-2 my-2">
                {['1','2','3','4','5','6','7','8','9'].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setPinInput((prev) => (prev.length < 10 ? prev + num : prev))}
                    className="py-2.5 bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 font-mono text-lg font-bold text-slate-100 rounded-xl transition shadow"
                  >
                    {num}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setPinInput('')}
                  className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs font-bold rounded-xl uppercase tracking-wider"
                >
                  Clear
                </button>
                <button
                  type="button"
                  onClick={() => setPinInput((prev) => (prev.length < 10 ? prev + '0' : prev))}
                  className="py-2.5 bg-slate-800 hover:bg-slate-700 active:bg-amber-500 active:text-slate-950 font-mono text-lg font-bold text-slate-100 rounded-xl transition shadow"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={() => setPinInput((prev) => prev.slice(0, -1))}
                  className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs font-bold rounded-xl uppercase tracking-wider"
                >
                  ⌫
                </button>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPinModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={verifyingPin || !pinInput}
                  className="w-1/2 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition shadow-lg shadow-amber-500/20 disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  <Unlock className="w-4 h-4" />
                  <span>{verifyingPin ? 'Verifying...' : 'Unlock Vault'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PAYSLIP MODAL */}
      {selectedPayslip && (
        <PayslipModal
          record={selectedPayslip}
          onClose={() => setSelectedPayslip(null)}
        />
      )}

    </div>
  );
};
