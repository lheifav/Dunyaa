import React, { useState, useEffect } from 'react';
import {
  Clock,
  Calendar,
  Filter,
  Plus,
  Trash2,
  Edit,
  X,
  UserCheck,
  Building2,
} from 'lucide-react';
import { AttendanceRecord, Employee } from '../types';
import { api } from '../lib/api';

export const AttendanceManagement: React.FC = () => {
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [selectedEmployee, setSelectedEmployee] = useState<string>('all');

  // Modal for Manual Attendance Entry / Adjustment
  const [showModal, setShowModal] = useState(false);
  const [modalData, setModalData] = useState({
    employee_id: 0,
    date: new Date().toISOString().split('T')[0],
    time_in: '08:00',
    time_out: '17:00',
  });

  const loadAttendance = async () => {
    try {
      setLoading(true);
      const params: any = {};
      if (selectedDate) params.date = selectedDate;
      if (selectedEmployee !== 'all') params.employee_id = Number(selectedEmployee);

      const data = await api.getAttendance(params);
      setRecords(data);
    } catch (err) {
      console.error('Error fetching attendance logs:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadEmployees = async () => {
    try {
      const data = await api.getEmployees({ status: 'active' });
      setEmployees(data);
      if (data.length > 0 && modalData.employee_id === 0) {
        setModalData((prev) => ({ ...prev, employee_id: data[0].id }));
      }
    } catch (err) {
      console.error('Error fetching employees:', err);
    }
  };

  useEffect(() => {
    loadEmployees();
  }, []);

  useEffect(() => {
    loadAttendance();
  }, [selectedDate, selectedEmployee]);

  const handleManualSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalData.employee_id) return;

    try {
      await api.manualAttendance({
        employee_id: modalData.employee_id,
        date: modalData.date,
        time_in: modalData.time_in ? `${modalData.time_in}:00` : undefined,
        time_out: modalData.time_out ? `${modalData.time_out}:00` : undefined,
      });
      setShowModal(false);
      loadAttendance();
    } catch (err: any) {
      alert(err.message || 'Error updating attendance.');
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to remove this attendance log?')) {
      try {
        await api.deleteAttendance(id);
        loadAttendance();
      } catch (err: any) {
        alert(err.message || 'Error deleting log.');
      }
    }
  };

  return (
    <div id="attendance-management" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2 italic serif">
            <Clock className="w-6 h-6 text-sky-400" />
            Attendance & Kiosk Logs
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time punch records from Employee Kiosk & Admin adjustments.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-lg text-xs transition shadow-lg shadow-sky-500/20 flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Manual Attendance Entry</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div>
            <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-1">Select Date</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="py-1.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-xs focus:outline-none focus:border-sky-400"
            />
          </div>

          <div>
            <label className="block text-[10px] uppercase tracking-widest font-bold text-slate-400 mb-1">Employee Filter</label>
            <select
              value={selectedEmployee}
              onChange={(e) => setSelectedEmployee(e.target.value)}
              className="py-1.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-xs focus:outline-none focus:border-sky-400"
            >
              <option value="all">All Employees</option>
              {employees.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.full_name} ({emp.employee_id})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="text-xs text-slate-400 font-mono bg-slate-900 px-3.5 py-2 rounded-lg border border-slate-700">
          Logs Found: <span className="font-bold text-sky-400">{records.length}</span>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
              <tr>
                <th className="py-3.5 px-4">Date</th>
                <th className="py-3.5 px-4">Employee</th>
                <th className="py-3.5 px-4 font-mono">Punch In</th>
                <th className="py-3.5 px-4 font-mono">Punch Out</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/60">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    Loading attendance records...
                  </td>
                </tr>
              ) : records.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No attendance records found for this filter.
                  </td>
                </tr>
              ) : (
                records.map((rec) => {
                  const isComplete = rec.time_in && rec.time_out;
                  return (
                    <tr key={rec.id} className="hover:bg-slate-800/50 transition">
                      <td className="py-3.5 px-4 font-mono text-slate-300">{rec.date}</td>
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-100">{rec.employee_name}</div>
                        <div className="font-mono text-sky-400 text-[11px]">{rec.employee_code}</div>
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-emerald-400">
                        {rec.time_in || '--:--'}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-amber-400">
                        {rec.time_out || '--:--'}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            isComplete
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : rec.time_in
                              ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30 animate-pulse'
                              : 'bg-red-500/10 text-red-400 border border-red-500/30'
                          }`}
                        >
                          {isComplete ? 'Complete' : rec.time_in ? 'In Shift' : 'Absent'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => handleDelete(rec.id)}
                          className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded transition"
                          title="Remove Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MANUAL ENTRY MODAL */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700 mb-4">
              <h3 className="font-bold text-lg text-slate-100 flex items-center gap-2 italic serif">
                <Clock className="w-5 h-5 text-sky-400" />
                Manual Attendance Entry
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleManualSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Employee *
                </label>
                <select
                  required
                  value={modalData.employee_id}
                  onChange={(e) => setModalData({ ...modalData, employee_id: Number(e.target.value) })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.full_name} ({emp.employee_id})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Date *
                </label>
                <input
                  type="date"
                  required
                  value={modalData.date}
                  onChange={(e) => setModalData({ ...modalData, date: e.target.value })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Punch In Time
                  </label>
                  <input
                    type="time"
                    value={modalData.time_in}
                    onChange={(e) => setModalData({ ...modalData, time_in: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Punch Out Time
                  </label>
                  <input
                    type="time"
                    value={modalData.time_out}
                    onChange={(e) => setModalData({ ...modalData, time_out: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end space-x-3 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-xs font-bold shadow-lg shadow-sky-500/20"
                >
                  Save Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
