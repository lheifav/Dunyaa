import React, { useState, useEffect } from 'react';
import {
  Banknote,
  Calculator,
  CheckCircle,
  Eye,
  Trash2,
  Calendar,
  ShieldCheck,
  MessageCircle,
  Mail,
  Download,
  ExternalLink,
  FileText,
} from 'lucide-react';
import { PayrollRecord, OvertimeRule } from '../types';
import { api } from '../lib/api';
import { PayslipModal } from './PayslipModal';
import { getWhatsAppUrl, getEmailUrl, notificationTemplates } from '../lib/notifications';
import { generateSifFileContent, generateMudadCsvContent, downloadFile } from '../lib/mudad';

export const PayrollManagement: React.FC = () => {
  const [history, setHistory] = useState<PayrollRecord[]>([]);
  const [availablePeriods, setAvailablePeriods] = useState<{ period_start: string; period_end: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [overtimeRules, setOvertimeRules] = useState<OvertimeRule[]>([]);

  // Period state
  const today = new Date();
  const defaultYearMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
  const [selectedMonth, setSelectedMonth] = useState(defaultYearMonth);

  // Calculation / Preview state
  const [previewItems, setPreviewItems] = useState<Partial<PayrollRecord>[] | null>(null);
  const [calculating, setCalculating] = useState(false);
  const [generating, setGenerating] = useState(false);

  // Overtime state per employee ID during calculation: { [empId]: { hours: number; rule_id: number } }
  const [overtimeData, setOvertimeData] = useState<Record<number, { hours: number; rule_id?: number }>>({});

  // Modal View Payslip
  const [selectedPayslip, setSelectedPayslip] = useState<PayrollRecord | null>(null);

  // Helper to compute period start/end from YYYY-MM
  const getPeriodDates = (yearMonthStr: string) => {
    const [year, month] = yearMonthStr.split('-').map(Number);
    const start = `${year}-${String(month).padStart(2, '0')}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    const end = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
    return { start, end };
  };

  const loadData = async () => {
    try {
      setLoading(true);
      const { start } = getPeriodDates(selectedMonth);
      const [histData, rules, periods] = await Promise.all([
        api.getPayroll({ period_start: start }),
        api.getOvertimeRules(),
        api.getPayrollPeriods(),
      ]);
      setHistory(histData);
      setOvertimeRules(rules);
      setAvailablePeriods(periods);
    } catch (err) {
      console.error('Error loading payroll history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    setPreviewItems(null);
  }, [selectedMonth]);

  // SIF Export
  const handleExportSif = () => {
    if (history.length === 0) {
      alert('No processed payroll records available in selected period to export SIF file.');
      return;
    }
    const { start, end } = getPeriodDates(selectedMonth);
    const sifContent = generateSifFileContent(history, {
      establishmentId: '7001234567',
      bankCode: 'RJHI',
      payoutYearMonth: selectedMonth,
      paymentDate: end,
    });
    downloadFile(`SIF_DUNYA_${selectedMonth}.sif`, sifContent, 'text/plain');
  };

  // Mudad Export
  const handleExportMudad = () => {
    if (history.length === 0) {
      alert('No processed payroll records available in selected period to export Mudad file.');
      return;
    }
    const csvContent = generateMudadCsvContent(history, {
      establishmentId: '7001234567',
      bankCode: 'RJHI',
      payoutYearMonth: selectedMonth,
    });
    downloadFile(`MUDAD_WPS_${selectedMonth}.csv`, csvContent, 'text/csv');
  };

  // Handle Calculate Preview
  const handleCalculate = async () => {
    setCalculating(true);

    try {
      const { start, end } = getPeriodDates(selectedMonth);
      const calcs = await api.calculatePayroll(start, end, overtimeData);
      setPreviewItems(calcs);
    } catch (err: any) {
      alert(err.message || 'Error calculating payroll preview.');
    } finally {
      setCalculating(false);
    }
  };

  const handleOvertimeHoursChange = (empId: number, hours: number) => {
    const existing = overtimeData[empId] || { hours: 0, rule_id: overtimeRules[0]?.id };
    const updated = { ...overtimeData, [empId]: { ...existing, hours } };
    setOvertimeData(updated);
  };

  const handleOvertimeRuleChange = (empId: number, ruleId: number) => {
    const existing = overtimeData[empId] || { hours: 0, rule_id: ruleId };
    const updated = { ...overtimeData, [empId]: { ...existing, rule_id: ruleId } };
    setOvertimeData(updated);
  };

  // Handle Commit & Generate Payroll
  const handleGenerate = async () => {
    if (!previewItems || previewItems.length === 0) return;
    if (!confirm(`Commit and process payroll for ${previewItems.length} active employees? This will lock the records and automatically update cash advance balances.`)) return;

    setGenerating(true);
    try {
      const { start, end } = getPeriodDates(selectedMonth);
      await api.generatePayroll(previewItems, start, end);
      alert('Payroll run generated and saved successfully!');
      setPreviewItems(null);
      loadData();
    } catch (err: any) {
      alert(err.message || 'Error generating payroll.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDeletePayrollRecord = async (id: number) => {
    if (confirm('Delete this payroll entry?')) {
      try {
        await api.deletePayroll(id);
        loadData();
      } catch (err: any) {
        alert(err.message || 'Error deleting record.');
      }
    }
  };

  return (
    <div id="payroll-management" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white flex items-center gap-2 italic serif">
              <Banknote className="w-6 h-6 text-sky-400" />
              Payroll Processing Engine
            </h1>
            <span className="hidden md:flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full">
              <ShieldCheck className="w-3 h-3" />
              Database Saved
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Automated salary calculations in SAR including basic, allowances, custom overtime rules, itemized bonuses, & cash advance deductions.
          </p>
        </div>

        {/* Pay Period / Payout Dropdown Picker */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center space-x-2 bg-[#1e293b] border border-slate-700 p-2 rounded-xl">
            <Calendar className="w-4 h-4 text-sky-400 ml-1" />
            <span className="text-xs text-slate-300 font-semibold">Pay Period:</span>
            
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-100 py-1.5 px-3 rounded-lg text-xs font-mono focus:outline-none focus:border-sky-400"
            >
              <option value={defaultYearMonth}>Current Month ({defaultYearMonth}) - Draft</option>
              {availablePeriods.map((p) => {
                const yearMonth = p.period_start.substring(0, 7);
                return (
                  <option key={p.period_start} value={yearMonth}>
                    Payout Period: {p.period_start} to {p.period_end} (Processed)
                  </option>
                );
              })}
            </select>
          </div>

          <button
            onClick={handleExportSif}
            className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5"
            title="Download SIF File for Saudi Banks"
          >
            <Download className="w-4 h-4" />
            <span>Generate SIF</span>
          </button>

          <button
            onClick={handleExportMudad}
            className="px-3.5 py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5"
            title="Export Mudad WPS Compliance CSV"
          >
            <Download className="w-4 h-4" />
            <span>Mudad Export</span>
          </button>
        </div>
      </div>

      {/* Paystub Summary Metrics Cards */}
      {history.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-3.5 shadow-lg">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Basic Total</span>
            <div className="text-base font-bold text-slate-100 font-mono mt-1">
              {history.reduce((sum, r) => sum + r.basic_salary, 0).toLocaleString()} <span className="text-[10px] text-sky-400 font-sans">SAR</span>
            </div>
          </div>

          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-3.5 shadow-lg">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Allowances</span>
            <div className="text-base font-bold text-slate-100 font-mono mt-1">
              {history.reduce((sum, r) => sum + r.allowances, 0).toLocaleString()} <span className="text-[10px] text-sky-400 font-sans">SAR</span>
            </div>
          </div>

          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-3.5 shadow-lg">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Overtime</span>
            <div className="text-base font-bold text-sky-300 font-mono mt-1">
              +{history.reduce((sum, r) => sum + (r.overtime_pay || 0), 0).toLocaleString()} <span className="text-[10px] text-sky-400 font-sans">SAR</span>
            </div>
          </div>

          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-3.5 shadow-lg">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Bonuses</span>
            <div className="text-base font-bold text-emerald-400 font-mono mt-1">
              +{history.reduce((sum, r) => sum + (r.bonus_pay || 0), 0).toLocaleString()} <span className="text-[10px] text-sky-400 font-sans">SAR</span>
            </div>
          </div>

          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-3.5 shadow-lg">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Deductions</span>
            <div className="text-base font-bold text-red-400 font-mono mt-1">
              -{history.reduce((sum, r) => sum + (r.insurance_deduction + r.cash_advance_deduction + r.deductions), 0).toLocaleString()} <span className="text-[10px] text-sky-400 font-sans">SAR</span>
            </div>
          </div>

          <div className="bg-slate-900 border border-sky-400/60 rounded-xl p-3.5 shadow-xl">
            <span className="text-[10px] uppercase font-bold text-sky-400 block">Net Salary Total</span>
            <div className="text-lg font-black text-white font-mono mt-1">
              {history.reduce((sum, r) => sum + r.net_salary, 0).toLocaleString()} <span className="text-[10px] text-sky-400 font-sans">SAR</span>
            </div>
          </div>
        </div>
      )}

      {/* Auto-Calculate Action Bar */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2 italic serif">
            <Calculator className="w-4 h-4 text-sky-400" />
            Process Monthly Payroll for {selectedMonth}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Auto-fetch active employees, apply active bonuses & overtime inputs, deduct advance repayments & insurance.
          </p>
        </div>

        <button
          id="btn-calculate-payroll"
          disabled={calculating}
          onClick={handleCalculate}
          className="px-5 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-lg text-xs transition shadow-lg shadow-sky-500/20 flex items-center gap-2 active:scale-95"
        >
          {calculating ? 'Calculating...' : 'Auto-Calculate Payroll Preview'}
        </button>
      </div>

      {/* PREVIEW TABLE (Before Committing) */}
      {previewItems && (
        <div className="bg-[#1e293b] border-2 border-sky-400/80 rounded-xl p-5 shadow-2xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-700 gap-3">
            <div>
              <span className="text-[10px] font-bold text-sky-400 uppercase tracking-widest">
                Calculated Payroll Preview
              </span>
              <h3 className="text-lg font-bold text-white italic serif">Review & Adjust Overtime Before Locking</h3>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleCalculate}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg border border-slate-700 transition"
              >
                Recalculate
              </button>
              <button
                id="btn-commit-payroll"
                disabled={generating}
                onClick={handleGenerate}
                className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs transition shadow-lg shadow-emerald-500/20 flex items-center gap-2 active:scale-95"
              >
                <CheckCircle className="w-4 h-4" />
                <span>{generating ? 'Processing...' : 'Lock & Save Payroll Run'}</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900/80 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
                <tr>
                  <th className="py-3 px-3">Employee</th>
                  <th className="py-3 px-3 text-center">Attendance Log</th>
                  <th className="py-3 px-3 text-right">Basic + Allow.</th>
                  <th className="py-3 px-3 text-center min-w-[200px]">Overtime (Hrs & Rule)</th>
                  <th className="py-3 px-3 text-right text-emerald-400">Bonus Pay</th>
                  <th className="py-3 px-3 text-right text-red-400">Deductions</th>
                  <th className="py-3 px-3 text-right">Net Salary (SAR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/60">
                {previewItems.map((item, idx) => {
                  const empId = item.employee_id!;
                  const curOT = overtimeData[empId] || { hours: item.overtime_hours || 0, rule_id: item.overtime_rule_id || overtimeRules[0]?.id };

                  return (
                    <tr key={idx} className="hover:bg-slate-800/50 transition">
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-100">{item.employee_name}</div>
                        <div className="font-mono text-sky-400 text-[11px]">{item.employee_code}</div>
                      </td>

                      <td className="py-3 px-3 text-center">
                        <div className="inline-flex flex-col text-[11px]">
                          <span className="text-emerald-400 font-bold">{item.present_days ?? 0} days present</span>
                          <span className="text-slate-400 text-[10px]">
                            {item.absent_days ? `${item.absent_days} absent` : '0 absent'} • {item.unpaid_leave_days ? `${item.unpaid_leave_days} unpaid` : '0 unpaid'}
                          </span>
                        </div>
                      </td>

                      <td className="py-3 px-3 text-right font-mono text-slate-200">
                        {((item.basic_salary || 0) + (item.allowances || 0)).toLocaleString()}
                      </td>

                      {/* Interactive Overtime Input in Preview */}
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1.5 bg-slate-900 p-1.5 rounded-lg border border-slate-700">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            value={curOT.hours}
                            onChange={(e) => handleOvertimeHoursChange(empId, Number(e.target.value))}
                            placeholder="0 hrs"
                            className="w-16 py-1 px-1.5 bg-slate-800 text-slate-100 font-mono text-center text-xs rounded border border-slate-700 focus:outline-none focus:border-sky-400"
                          />
                          <span className="text-[11px] text-slate-400">hrs</span>

                          <select
                            value={curOT.rule_id}
                            onChange={(e) => handleOvertimeRuleChange(empId, Number(e.target.value))}
                            className="py-1 px-1.5 bg-slate-800 text-slate-200 text-[11px] rounded border border-slate-700 focus:outline-none focus:border-sky-400"
                          >
                            {overtimeRules.map((r) => (
                              <option key={r.id} value={r.id}>
                                {r.rule_name} ({r.multiplier}x)
                              </option>
                            ))}
                          </select>
                        </div>
                        {Boolean(item.overtime_pay) && (
                          <div className="text-[10px] font-mono text-sky-300 font-bold mt-1">
                            +{item.overtime_pay?.toLocaleString()} SAR
                          </div>
                        )}
                      </td>

                      {/* Bonus Pay Column */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-emerald-400">
                        {item.bonus_pay ? `+${item.bonus_pay.toLocaleString()} SAR` : '—'}
                      </td>

                      {/* Deductions Column */}
                      <td className="py-3 px-3 text-right font-mono text-red-400 font-medium">
                        -{( (item.attendance_deduction || 0) + (item.insurance_deduction || 0) + (item.cash_advance_deduction || 0) ).toLocaleString()}
                      </td>

                      {/* Net Salary Column */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-sky-400 text-sm">
                        {item.net_salary?.toLocaleString()} SAR
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SAVED PAYROLL HISTORY TABLE */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
        <div className="p-4 bg-slate-900/80 border-b border-slate-700 flex items-center justify-between">
          <h3 className="font-bold text-slate-300 text-[10px] uppercase tracking-widest">
            Saved Payroll Run History for {selectedMonth}
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            Entries: {history.length}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/60 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
              <tr>
                <th className="py-3.5 px-4">Employee</th>
                <th className="py-3.5 px-4">Period</th>
                <th className="py-3.5 px-4 text-center">Overtime & Bonuses</th>
                <th className="py-3.5 px-4 text-right">Gross Earnings</th>
                <th className="py-3.5 px-4 text-right">Total Deductions</th>
                <th className="py-3.5 px-4 text-right">Net Salary (SAR)</th>
                <th className="py-3.5 px-4 text-center">Dispatch (WhatsApp / Email)</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/60">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    Loading payroll history...
                  </td>
                </tr>
              ) : history.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No generated payroll runs found for {selectedMonth}. Click "Auto-Calculate Payroll Preview" above to start!
                  </td>
                </tr>
              ) : (
                history.map((rec) => {
                  const tpl = notificationTemplates.paystub(rec);
                  const waUrl = getWhatsAppUrl(rec.phone_number, tpl.text);
                  const mailUrl = getEmailUrl(rec.email, tpl.subject, tpl.text);
                  const gross = rec.basic_salary + rec.allowances + (rec.overtime_pay || 0) + (rec.bonus_pay || 0);

                  return (
                    <tr key={rec.id} className="hover:bg-slate-800/50 transition">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-100">{rec.employee_name}</div>
                        <div className="font-mono text-sky-400 text-[11px]">{rec.employee_code}</div>
                      </td>

                      <td className="py-3.5 px-4 font-mono text-slate-400 text-[11px]">
                        {rec.period_start} to {rec.period_end}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="flex flex-col gap-1 items-center text-[10px]">
                          {Boolean(rec.overtime_pay) ? (
                            <span className="px-1.5 py-0.5 bg-sky-500/10 border border-sky-500/30 text-sky-300 font-mono font-bold rounded">
                              OT: +{rec.overtime_pay?.toLocaleString()} SAR ({rec.overtime_hours}h)
                            </span>
                          ) : (
                            <span className="text-slate-500 font-mono">No OT</span>
                          )}
                          {Boolean(rec.bonus_pay) && (
                            <span className="px-1.5 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-mono font-bold rounded">
                              Bonus: +{rec.bonus_pay?.toLocaleString()} SAR
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono text-slate-300">
                        {gross.toLocaleString()}
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono text-red-400 font-medium">
                        -{(rec.insurance_deduction + rec.cash_advance_deduction + rec.deductions).toLocaleString()}
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400 text-sm">
                        {rec.net_salary.toLocaleString()} SAR
                      </td>

                      {/* Quick WhatsApp & Email Notification Dispatch */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <a
                            href={waUrl}
                            target="_blank"
                            rel="noreferrer"
                            title="Send Salary Statement via WhatsApp"
                            className="p-1.5 bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 rounded-lg transition border border-emerald-500/30 active:scale-95 flex items-center gap-1 text-[11px] font-bold"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>WhatsApp</span>
                          </a>

                          <a
                            href={mailUrl}
                            target="_blank"
                            rel="noreferrer"
                            title="Send Salary Statement via Email"
                            className="p-1.5 bg-sky-500/20 hover:bg-sky-500 text-sky-300 hover:text-slate-950 rounded-lg transition border border-sky-500/30 active:scale-95 flex items-center gap-1 text-[11px] font-bold"
                          >
                            <Mail className="w-3.5 h-3.5" />
                            <span>Email</span>
                          </a>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center space-x-2">
                          <button
                            onClick={() => setSelectedPayslip(rec)}
                            className="px-2.5 py-1.5 bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/30 text-sky-400 font-bold rounded-lg text-xs transition flex items-center gap-1 active:scale-95"
                            title="View & Download PDF Payslip"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Payslip</span>
                          </button>
                          <button
                            onClick={() => handleDeletePayrollRecord(rec.id)}
                            className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg transition active:scale-95"
                            title="Delete Record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PAYSLIP MODAL */}
      {selectedPayslip && (
        <PayslipModal record={selectedPayslip} onClose={() => setSelectedPayslip(null)} />
      )}

    </div>
  );
};

