import React, { useState, useEffect } from 'react';
import { Building2, Lock, User, Monitor, AlertCircle, ArrowRight, UserPlus, CheckCircle2, ShieldAlert } from 'lucide-react';
import { api } from '../lib/api';

interface LoginViewProps {
  onLoginSuccess: (user: { id: number; username: string }) => void;
  onEnterKiosk: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({
  onLoginSuccess,
  onEnterKiosk,
}) => {
  const [mode, setMode] = useState<'signin' | 'register'>('signin');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  const [adminStats, setAdminStats] = useState<{ count: number; maxAllowed: number; canRegister: boolean } | null>(null);

  const fetchAdminStats = async () => {
    try {
      const stats = await api.getAdminCount();
      setAdminStats(stats);
    } catch (err) {
      console.error('Failed to fetch admin stats:', err);
    }
  };

  useEffect(() => {
    fetchAdminStats();
  }, []);

  const handleToggleMode = (newMode: 'signin' | 'register') => {
    setMode(newMode);
    setError(null);
    setSuccessMsg(null);
    setUsername('');
    setPassword('');
    setConfirmPassword('');
    fetchAdminStats();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (mode === 'signin') {
        const res = await api.login(username, password);
        if (res.success) {
          onLoginSuccess(res.user);
        }
      } else {
        // Register mode
        if (password !== confirmPassword) {
          throw new Error('Passwords do not match.');
        }
        if (password.length < 4) {
          throw new Error('Password must be at least 4 characters long.');
        }

        const res = await api.register(username, password);
        if (res.success) {
          setSuccessMsg('Account created successfully! Signing you in...');
          setTimeout(() => {
            onLoginSuccess(res.user);
          }, 1000);
        }
      }
    } catch (err: any) {
      setError(err.message || (mode === 'signin' ? 'Login failed.' : 'Registration failed.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="login-container" className="min-h-[calc(100vh-4rem)] bg-[#0f172a] flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-md">
        
        {/* Company Header Card */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-sky-500 text-white shadow-lg shadow-sky-500/20 mb-3">
            <Building2 className="w-9 h-9" />
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight italic serif">
            Dunya AlMuehmat
          </h2>
          <p className="text-sm font-arabic text-sky-400 font-medium mt-0.5">
            دنيا المهمات لمعدات المكاتب
          </p>
          <p className="text-xs text-slate-400 mt-0.5">
            Office Equipments Payroll & Employee System
          </p>
        </div>

        {/* Login/Register Card */}
        <div className="bg-[#1e293b] border border-slate-700 rounded-2xl p-6 sm:p-8 shadow-2xl">
          
          {/* Header & Tabs */}
          <div className="flex items-center justify-between pb-4 mb-5 border-b border-slate-700">
            <div className="flex items-center gap-2">
              {mode === 'signin' ? (
                <Lock className="w-5 h-5 text-sky-400" />
              ) : (
                <UserPlus className="w-5 h-5 text-emerald-400" />
              )}
              <h3 className="text-lg font-bold text-slate-100 italic serif">
                {mode === 'signin' ? 'Admin Portal' : 'Create Admin Account'}
              </h3>
            </div>
            {adminStats && (
              <span className={`text-xs px-2.5 py-1 rounded-full border font-mono font-bold ${
                adminStats.count >= 3 
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' 
                  : 'bg-slate-900 border-slate-700 text-sky-400'
              }`}>
                {adminStats.count} / {adminStats.maxAllowed} Admins
              </span>
            )}
          </div>

          {/* Alert Messages */}
          {error && (
            <div className="mb-5 p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-200 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200 text-xs flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Registration Limit Notice when max reached in Register mode */}
          {mode === 'register' && adminStats && adminStats.count >= 3 && (
            <div className="mb-5 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-2.5">
              <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <strong className="block font-bold">Account Limit Reached (3/3)</strong>
                System is restricted to a maximum of 3 admin accounts. You cannot register additional accounts unless an existing account is removed.
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Admin Username
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="input-username"
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Type admin username"
                  className="w-full pl-9 pr-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="input-password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Type password"
                  className="w-full pl-9 pr-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-sky-400 focus:ring-1 focus:ring-sky-400"
                />
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Confirm Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="input-confirm-password"
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full pl-9 pr-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400"
                  />
                </div>
              </div>
            )}

            <button
              id="btn-login-submit"
              type="submit"
              disabled={loading || (mode === 'register' && adminStats ? adminStats.count >= 3 : false)}
              className={`w-full py-3 px-4 text-white font-bold rounded-xl text-sm transition shadow-lg flex items-center justify-center gap-2 active:scale-98 ${
                mode === 'signin'
                  ? 'bg-sky-500 hover:bg-sky-400 active:bg-sky-600 shadow-sky-500/20'
                  : 'bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed'
              }`}
            >
              {loading ? (
                <span>{mode === 'signin' ? 'Signing in...' : 'Creating Account...'}</span>
              ) : (
                <>
                  <span>{mode === 'signin' ? 'Sign In as Admin' : 'Register Admin Account'}</span>
                  {mode === 'signin' ? <ArrowRight className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                </>
              )}
            </button>
          </form>

          {/* Mode Switcher */}
          <div className="mt-5 pt-4 border-t border-slate-700/80 text-center">
            {mode === 'signin' ? (
              <button
                type="button"
                onClick={() => handleToggleMode('register')}
                className="text-xs font-semibold text-sky-400 hover:text-sky-300 transition flex items-center justify-center gap-1.5 mx-auto"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Create a new admin account (Max 3 allowed)</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleToggleMode('signin')}
                className="text-xs font-semibold text-slate-400 hover:text-slate-200 transition flex items-center justify-center gap-1.5 mx-auto"
              >
                <Lock className="w-3.5 h-3.5 text-sky-400" />
                <span>Already have an account? Return to Sign In</span>
              </button>
            )}
          </div>
        </div>

        {/* Separate Employee Kiosk Section */}
        <div className="mt-6 bg-[#1e293b] border border-slate-700 rounded-2xl p-5 text-center shadow-lg">
          <p className="text-xs text-slate-400 font-medium mb-2">
            Are you an employee clocking in or requesting leave?
          </p>
          <button
            id="btn-kiosk-mode-launch"
            onClick={onEnterKiosk}
            className="w-full py-3 px-4 bg-slate-900 hover:bg-slate-800 text-sky-400 font-bold rounded-xl text-sm border border-sky-400/30 hover:border-sky-400 transition flex items-center justify-center gap-2 shadow-sm active:scale-98"
          >
            <Monitor className="w-5 h-5 text-sky-400" />
            <span>Open Employee Kiosk (Touch Mode)</span>
          </button>
        </div>

      </div>
    </div>
  );
};

