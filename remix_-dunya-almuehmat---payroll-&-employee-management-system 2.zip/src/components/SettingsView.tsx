import React, { useState, useEffect } from 'react';
import {
  Settings,
  Lock,
  Building2,
  Wifi,
  Tablet,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Database,
  Download,
  FileCode,
  Clock,
  HardDrive,
  Trash2,
  UserCheck,
  Users,
} from 'lucide-react';
import { api } from '../lib/api';

interface SettingsViewProps {
  adminUsername: string;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ adminUsername }) => {
  // Change password state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passMsg, setPassMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [passLoading, setPassLoading] = useState(false);

  // Admin profiles state
  const [admins, setAdmins] = useState<Array<{ id: number; username: string; created_at?: string }>>([]);
  const [adminMsg, setAdminMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // LAN Info
  const [lanInfo, setLanInfo] = useState<{
    port: number;
    lanIps: string[];
    companyName: string;
    companyNameArabic: string;
    currency: string;
  } | null>(null);

  const loadAdmins = async () => {
    try {
      const data = await api.getAdmins();
      setAdmins(data);
    } catch (err) {
      console.error('Failed to load admin profiles:', err);
    }
  };

  useEffect(() => {
    api.getLanInfo().then(setLanInfo).catch(console.error);
    loadAdmins();
  }, []);

  const handleDeleteAdmin = async (adminToDelete: { id: number; username: string }) => {
    setAdminMsg(null);
    if (admins.length <= 1) {
      setAdminMsg({ type: 'error', text: 'Cannot delete the last remaining admin profile.' });
      return;
    }

    if (confirm(`Are you sure you want to delete admin profile "${adminToDelete.username}"?`)) {
      try {
        const res = await api.deleteAdmin(adminToDelete.id);
        setAdminMsg({ type: 'success', text: res.message || 'Admin profile deleted.' });
        loadAdmins();
      } catch (err: any) {
        setAdminMsg({ type: 'error', text: err.message || 'Error deleting admin profile.' });
      }
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);

    if (newPassword !== confirmPassword) {
      setPassMsg({ type: 'error', text: 'New passwords do not match.' });
      return;
    }
    if (newPassword.length < 5) {
      setPassMsg({ type: 'error', text: 'Password must be at least 5 characters.' });
      return;
    }

    setPassLoading(true);
    try {
      await api.changePassword({
        username: adminUsername,
        oldPassword,
        newPassword,
      });
      setPassMsg({ type: 'success', text: 'Password updated successfully!' });
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setPassMsg({ type: 'error', text: err.message || 'Error changing password.' });
    } finally {
      setPassLoading(false);
    }
  };

  return (
    <div id="settings-view" className="space-y-6">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white flex items-center gap-2 italic serif">
          <Settings className="w-6 h-6 text-sky-400" />
          System Security & Database Controls
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Single admin security, auto-logout parameters, LAN tablet connectivity, and full SQLite database backups.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Admin Security & Database Backups */}
        <div className="space-y-6">
          
          {/* Database Backup & Maintenance Box */}
          <div className="bg-[#1e293b] border border-sky-500/30 rounded-xl p-6 shadow-xl relative overflow-hidden">
            <div className="flex items-center space-x-2 pb-4 border-b border-slate-700 mb-4">
              <Database className="w-5 h-5 text-sky-400" />
              <h3 className="font-bold text-slate-100 text-sm italic serif">Database Backup & Export Controls</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Export and safeguard your full payroll database, employee profiles, attendance logs, cash advances, and leave records with a single click.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <a
                href={api.getBackupDbUrl()}
                download
                className="flex items-center justify-center gap-2 py-3 px-4 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl text-xs transition shadow-lg shadow-sky-500/20 active:scale-95 text-center"
              >
                <Download className="w-4 h-4 flex-shrink-0" />
                <span>Download SQLite (.db)</span>
              </a>

              <a
                href={api.getBackupJsonUrl()}
                download
                className="flex items-center justify-center gap-2 py-3 px-4 bg-slate-800 hover:bg-slate-700 text-sky-300 font-bold rounded-xl text-xs border border-sky-500/30 transition shadow active:scale-95 text-center"
              >
                <FileCode className="w-4 h-4 flex-shrink-0" />
                <span>Export JSON Data</span>
              </a>
            </div>

            <div className="mt-4 p-3 bg-slate-900 rounded-lg border border-slate-700/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-slate-400">
                <HardDrive className="w-4 h-4 text-emerald-400" />
                <span>Storage Engine: <strong>SQLite (dunya_payroll.db)</strong></span>
              </div>
              <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold px-2 py-0.5 rounded-full">
                Auto-Saved
              </span>
            </div>
          </div>

          {/* Admin Security Settings Box */}
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-6 shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-700 mb-6">
              <div className="flex items-center space-x-2">
                <Lock className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-slate-100 text-sm italic serif">Single Admin Account Password</h3>
              </div>
              <span className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                Single Admin Enforced
              </span>
            </div>

            {passMsg && (
              <div
                className={`mb-4 p-3 rounded-lg border text-xs flex items-center gap-2 ${
                  passMsg.type === 'success'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-red-500/10 border-red-500/30 text-red-300'
                }`}
              >
                {passMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                )}
                <span>{passMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Admin Username
                </label>
                <input
                  type="text"
                  disabled
                  value={adminUsername}
                  className="w-full py-2 px-3 bg-slate-900/50 border border-slate-700 rounded-lg text-slate-400 text-sm font-mono cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  required
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-type new password"
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={passLoading}
                  className="w-full py-2.5 px-4 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-lg text-xs transition shadow-lg shadow-sky-500/20"
                >
                  {passLoading ? 'Updating...' : 'Update Password'}
                </button>
              </div>
            </form>
          </div>

          {/* Admin Accounts & Profiles Management Box */}
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-6 shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-700 mb-4">
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-slate-100 text-sm italic serif">Admin Profiles Management</h3>
              </div>
              <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-sky-400 font-mono font-bold">
                {admins.length} / 3 Profiles
              </span>
            </div>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Manage authorized admin user profiles. You can delete outdated or redundant admin accounts (at least 1 admin profile must remain).
            </p>

            {adminMsg && (
              <div
                className={`mb-4 p-3 rounded-lg border text-xs flex items-center gap-2 ${
                  adminMsg.type === 'success'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-red-500/10 border-red-500/30 text-red-300'
                }`}
              >
                {adminMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                )}
                <span>{adminMsg.text}</span>
              </div>
            )}

            <div className="space-y-2">
              {admins.map((adm) => {
                const isCurrent = adm.username.toLowerCase() === adminUsername.toLowerCase();
                return (
                  <div
                    key={adm.id}
                    className="p-3 bg-slate-900/80 border border-slate-800 rounded-xl flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className={`p-2 rounded-lg ${isCurrent ? 'bg-sky-500/20 text-sky-400' : 'bg-slate-800 text-slate-400'}`}>
                        <UserCheck className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-slate-100 truncate">{adm.username}</span>
                          {isCurrent && (
                            <span className="text-[10px] bg-sky-500/20 border border-sky-500/30 text-sky-300 px-2 py-0.5 rounded-full font-bold">
                              Current Session
                            </span>
                          )}
                        </div>
                        {adm.created_at && (
                          <span className="text-[10px] text-slate-500 block">Created: {new Date(adm.created_at).toLocaleDateString()}</span>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteAdmin(adm)}
                      disabled={admins.length <= 1}
                      title={admins.length <= 1 ? "Cannot delete the only remaining admin" : `Delete admin profile ${adm.username}`}
                      className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 active:bg-red-500/30 text-red-400 hover:text-red-300 border border-red-500/20 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-30 disabled:cursor-not-allowed flex-shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Profile</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right Column: Security Control & Network LAN */}
        <div className="space-y-6">
          
          {/* Security & Idle Control Policy Box */}
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-6 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 pb-3 border-b border-slate-700">
              <Clock className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-slate-100 text-sm italic serif">Session Control & Idle Auto-Logout</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              To safeguard confidential payroll figures and employee Iqama/salary records, the Admin panel enforces an automatic idle session lock.
            </p>

            <div className="space-y-2 text-xs bg-slate-900/60 p-3.5 rounded-lg border border-slate-800">
              <div className="flex justify-between items-center py-1 border-b border-slate-800">
                <span className="text-slate-400">Idle Inactivity Limit:</span>
                <strong className="text-amber-300 font-mono">15 Minutes</strong>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800">
                <span className="text-slate-400">Warning Countdown:</span>
                <strong className="text-slate-200 font-mono">30 Seconds Alert</strong>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-slate-400">Security Action:</span>
                <strong className="text-red-400 font-medium">Automatic Sign Out & Lock</strong>
              </div>
            </div>
          </div>

          {/* LAN Connection Guide Box */}
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-6 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 pb-3 border-b border-slate-700">
              <Wifi className="w-5 h-5 text-sky-400" />
              <h3 className="font-bold text-slate-100 text-sm italic serif">LAN Network & iPad Access</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              This standalone application is hosted on your local network. Employees can access the <strong>Kiosk Mode</strong> on any iPad, tablet, or smartphone connected to the same Wi-Fi / LAN network.
            </p>

            <div className="bg-slate-900 p-4 rounded-lg border border-slate-700 space-y-2">
              <div className="text-[10px] uppercase tracking-widest text-slate-400 font-bold flex items-center gap-1.5">
                <Tablet className="w-4 h-4 text-sky-400" />
                <span>LAN Access URL for iPad/Tablets</span>
              </div>
              <div className="font-mono text-sky-400 font-bold text-sm">
                http://[LOCAL-IP]:{lanInfo?.port || 3000}
              </div>
              {lanInfo?.lanIps && lanInfo.lanIps.length > 0 && (
                <div className="text-[11px] text-slate-400 mt-1">
                  Detected Local IPs: {lanInfo.lanIps.map((ip) => `${ip}:${lanInfo.port}`).join(', ')}
                </div>
              )}
            </div>
          </div>

          {/* Company Details Box */}
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-6 shadow-xl space-y-3">
            <div className="flex items-center space-x-2 pb-3 border-b border-slate-700">
              <Building2 className="w-5 h-5 text-sky-400" />
              <h3 className="font-bold text-slate-100 text-sm italic serif">Company System Profile</h3>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Company Name</span>
                <strong className="text-slate-100">{lanInfo?.companyName || 'Dunya AlMuehmat for Office Equipments'}</strong>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Arabic Name</span>
                <strong className="text-sky-400 font-arabic">{lanInfo?.companyNameArabic || 'دنيا المهمات لمعدات المكاتب'}</strong>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">System Currency</span>
                <strong className="text-slate-100 font-mono">SAR (Saudi Riyal)</strong>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">EOSB Policy</span>
                <strong className="text-slate-100">Excluded (No EOSB)</strong>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
