import React, { useEffect, useState } from 'react';
import {
  Users,
  Clock,
  Banknote,
  HandCoins,
  CalendarDays,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  UserCheck,
  Building2,
  PlusCircle,
  FileText,
  Download,
  ExternalLink,
} from 'lucide-react';
import { DashboardStats, AttendanceRecord, Employee, PayrollRecord } from '../types';
import { api } from '../lib/api';
import { ActiveTab } from './Sidebar';
import { PayslipModal } from './PayslipModal';
import { generateSifFileContent, generateMudadCsvContent, downloadFile } from '../lib/mudad';

interface DashboardOverviewProps {
  onNavigate: (tab: ActiveTab) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({ onNavigate }) => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [recentPayrolls, setRecentPayrolls] = useState<PayrollRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // Selected Payslip Modal
  const [selectedPayslip, setSelectedPayslip] = useState<PayrollRecord | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const s = await api.getDashboardStats();
      setStats(s);

      const today = new Date().toISOString().split('T')[0];
      const att = await api.getAttendance({ date: today });
      setTodayAttendance(att);

      const empList = await api.getEmployees();
      setEmployees(empList);

      const payList = await api.getPayroll();
      setRecentPayrolls(payList);
    } catch (err) {
      console.error('Error loading dashboard stats:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Open Paystub for specific employee
  const handleOpenEmployeePaystub = (employee: Employee) => {
    const latest = recentPayrolls.find((p) => p.employee_id === employee.id);
    if (latest) {
      setSelectedPayslip(latest);
    } else {
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      const todayStr = now.toISOString().split('T')[0];

      const draft: PayrollRecord = {
        id: 0,
        employee_id: employee.id!,
        employee_name: employee.full_name,
        employee_code: employee.employee_id,
        job_title: employee.job_title,
        iban: employee.iban,
        period_start: firstDay,
        period_end: todayStr,
        basic_salary: employee.basic_salary,
        allowances: employee.allowances || 0,
        overtime_hours: 0,
        overtime_pay: 0,
        bonus_pay: 0,
        deductions: 0,
        cash_advance_deduction: 0,
        insurance_deduction: Math.round(employee.basic_salary * 0.1),
        net_salary: employee.basic_salary + (employee.allowances || 0) - Math.round(employee.basic_salary * 0.1),
        status: 'draft',
        generated_date: todayStr,
      };
      setSelectedPayslip(draft);
    }
  };

  // SIF Export from Dashboard
  const handleExportSif = () => {
    if (recentPayrolls.length === 0) {
      alert('No processed payroll records found to generate SIF file.');
      return;
    }
    const todayStr = new Date().toISOString().split('T')[0];
    const sif = generateSifFileContent(recentPayrolls, {
      establishmentId: '7001234567',
      bankCode: 'RJHI',
      payoutYearMonth: todayStr.substring(0, 7),
    });
    downloadFile(`SIF_DUNYA_LATEST.sif`, sif, 'text/plain');
  };

  // Mudad Export from Dashboard
  const handleExportMudad = () => {
    if (recentPayrolls.length === 0) {
      alert('No processed payroll records found to generate Mudad file.');
      return;
    }
    const todayStr = new Date().toISOString().split('T')[0];
    const csv = generateMudadCsvContent(recentPayrolls, {
      establishmentId: '7001234567',
      bankCode: 'RJHI',
      payoutYearMonth: todayStr.substring(0, 7),
    });
    downloadFile(`MUDAD_WPS_LATEST.csv`, csv, 'text/csv');
  };

  return (
    <div id="dashboard-overview" className="space-y-6">
      
      {/* Top Welcome Banner */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-bold text-sky-400 uppercase tracking-widest mb-1">
            <Building2 className="w-4 h-4" />
            <span>Management Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight italic serif">
            Dunya AlMuehmat Overview
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Payroll & HR Management · Employee Records, Cash Advances & Attendance Overview
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('payroll')}
            className="px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-xs font-bold shadow-lg shadow-sky-500/20 transition flex items-center gap-1.5"
          >
            <Banknote className="w-4 h-4" />
            <span>Run Monthly Payroll</span>
          </button>
          <button
            onClick={() => onNavigate('employees')}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-600 hover:border-sky-400 transition flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4 text-sky-400" />
            <span>Add New Employee</span>
          </button>
        </div>
      </div>

      {/* Iqama Expiry Alert Banner */}
      {stats && stats.iqamaExpiringSoonCount > 0 && (
        <div className="bg-amber-950/80 border border-amber-600/80 text-amber-100 rounded-xl p-4 shadow-lg flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="w-6 h-6 text-amber-400 flex-shrink-0 animate-bounce" />
            <div>
              <h4 className="font-bold text-sm">Iqama Expiry Warning</h4>
              <p className="text-xs opacity-90">
                {stats.iqamaExpiringSoonCount} employee(s) have Iqama / residency expiring within the next 30 days. Please review and initiate renewals.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('employees')}
            className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs transition shadow flex items-center gap-1"
          >
            <span>Review Employees</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        {/* Metric 1: Total Staff */}
        <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Total Staff</span>
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center border border-sky-500/20">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-white">{loading ? '--' : stats?.totalEmployees}</div>
            <div className="text-[11px] text-slate-400 mt-1 flex items-center space-x-2">
              <span className="text-emerald-400 font-semibold">{stats?.saudiCount} Saudi</span>
              <span>•</span>
              <span className="text-sky-400 font-semibold">{stats?.expatCount} Expat</span>
            </div>
          </div>
        </div>

        {/* Metric 2: Today's Present Attendance */}
        <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Present Today</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-emerald-400">{loading ? '--' : stats?.presentToday}</div>
            <div className="text-[11px] text-slate-400 mt-1">
              Out of {stats?.activeEmployees || 0} active staff
            </div>
          </div>
        </div>

        {/* Metric 3: Active Cash Advances */}
        <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Active Advances</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20">
              <HandCoins className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl font-bold text-amber-400">
              {loading ? '--' : `${(stats?.activeAdvancesTotal || 0).toLocaleString()} SAR`}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Outstanding balance</div>
          </div>
        </div>

        {/* Metric 4: Pending Leaves */}
        <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Pending Leaves</span>
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center border border-sky-500/20">
              <CalendarDays className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-sky-400">{loading ? '--' : stats?.pendingLeaves}</div>
            <div className="text-[11px] text-slate-400 mt-1">Needs Review</div>
          </div>
        </div>

      </div>

      {/* Secondary Dashboard Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Today's Attendance Feed (7 cols) */}
        <div className="lg:col-span-7 bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-700 mb-4">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-sky-400" />
                <h3 className="font-bold text-slate-200 tracking-tight italic serif">Today's Attendance Kiosk Activity</h3>
              </div>
              <button
                onClick={() => onNavigate('attendance')}
                className="text-[10px] text-sky-400 uppercase tracking-wider font-bold hover:underline"
              >
                View Full Logs →
              </button>
            </div>

            {todayAttendance.length === 0 ? (
              <div className="text-center py-10 text-slate-500 text-xs italic">
                No employee punches recorded yet for today. Launch Employee Kiosk to punch in!
              </div>
            ) : (
              <div className="space-y-2.5">
                {todayAttendance.map((rec) => (
                  <div
                    key={rec.id}
                    className="p-3 bg-slate-900/60 border border-slate-700/70 rounded-lg flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold text-sm text-slate-100">{rec.employee_name}</div>
                      <div className="text-xs text-slate-400">
                        <span className="font-mono text-sky-400">{rec.employee_code}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 text-xs font-mono">
                      <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded text-[11px] font-bold">
                        IN: {rec.time_in || '--:--'}
                      </span>
                      <span className="px-2.5 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded text-[11px] font-bold">
                        OUT: {rec.time_out || '--:--'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right: Quick System Shortcuts (5 cols) */}
        <div className="lg:col-span-5 bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl space-y-4">
          <h3 className="font-bold text-slate-200 tracking-tight italic serif pb-3 border-b border-slate-700 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-sky-400" />
            System Navigation
          </h3>

          <div className="grid grid-cols-1 gap-2.5 text-xs">
            
            <button
              onClick={() => onNavigate('employees')}
              className="p-3 bg-slate-900/60 hover:bg-slate-800 border border-slate-700 rounded-lg flex items-center justify-between transition text-left"
            >
              <div className="flex items-center space-x-3">
                <Users className="w-4 h-4 text-sky-400" />
                <div>
                  <div className="font-bold text-slate-200">Employee Directory</div>
                  <div className="text-slate-400 text-[11px]">Manage Iqama, passports & salaries</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500" />
            </button>

            <button
              onClick={() => onNavigate('payroll')}
              className="p-3 bg-slate-900/60 hover:bg-slate-800 border border-slate-700 rounded-lg flex items-center justify-between transition text-left"
            >
              <div className="flex items-center space-x-3">
                <Banknote className="w-4 h-4 text-emerald-400" />
                <div>
                  <div className="font-bold text-slate-200">Payroll Engine</div>
                  <div className="text-slate-400 text-[11px]">Calculate & export official payslips (SAR)</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500" />
            </button>

            <button
              onClick={() => onNavigate('advances')}
              className="p-3 bg-slate-900/60 hover:bg-slate-800 border border-slate-700 rounded-lg flex items-center justify-between transition text-left"
            >
              <div className="flex items-center space-x-3">
                <HandCoins className="w-4 h-4 text-amber-400" />
                <div>
                  <div className="font-bold text-slate-200">Cash Advances</div>
                  <div className="text-slate-400 text-[11px]">Track employee advances & repayments</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500" />
            </button>

            <button
              onClick={() => onNavigate('leaves')}
              className="p-3 bg-slate-900/60 hover:bg-slate-800 border border-slate-700 rounded-lg flex items-center justify-between transition text-left"
            >
              <div className="flex items-center space-x-3">
                <CalendarDays className="w-4 h-4 text-purple-400" />
                <div>
                  <div className="font-bold text-slate-200">Leave Approvals</div>
                  <div className="text-slate-400 text-[11px]">Approve/reject submitted leave applications</div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500" />
            </button>

          </div>
        </div>

      </div>

      {/* Employee Staff Roster & Instant Paystub Action Section */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-700 gap-2">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-sky-400" />
            <h3 className="font-bold text-slate-100 text-sm italic serif">
              Active Employee Paystubs & Mudad Links
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono">
              Linked to Mudad WPS after payout
            </span>
            <button
              onClick={() => onNavigate('reports')}
              className="text-xs text-sky-400 font-bold hover:underline flex items-center gap-1"
            >
              <span>Full Reports & Analytics →</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {employees.map((emp) => {
            const hasProcessedPayroll = recentPayrolls.some((p) => p.employee_id === emp.id);
            return (
              <div
                key={emp.id}
                className="bg-slate-900/80 border border-slate-700/80 rounded-xl p-4 flex items-center justify-between gap-3 hover:border-slate-600 transition"
              >
                <div>
                  <div className="font-bold text-slate-100 text-xs sm:text-sm">{emp.full_name}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                    <span className="font-mono text-sky-400">{emp.employee_id}</span>
                    <span>•</span>
                    <span>{emp.job_title}</span>
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono mt-1">
                    Basic: {emp.basic_salary.toLocaleString()} SAR
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                  <button
                    onClick={() => handleOpenEmployeePaystub(emp)}
                    className="px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5 active:scale-95"
                    title="View, Print or Download Paystub linked to Mudad"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Paystub</span>
                  </button>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                      hasProcessedPayroll
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                    }`}
                  >
                    {hasProcessedPayroll ? 'Mudad Ready' : 'Draft Paystub'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Payslip Modal */}
      {selectedPayslip && (
        <PayslipModal record={selectedPayslip} onClose={() => setSelectedPayslip(null)} />
      )}

    </div>
  );
};
