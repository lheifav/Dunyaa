import React, { useState, useEffect } from 'react';
import {
  FileText,
  BarChart3,
  Calendar,
  Filter,
  Download,
  Users,
  Banknote,
  Clock,
  CalendarDays,
  HandCoins,
  Search,
  Building2,
  Printer,
  CheckCircle2,
  XCircle,
  Clock3,
  ExternalLink,
} from 'lucide-react';
import { Employee, PayrollRecord, LeaveRequest, CashAdvance } from '../types';
import { api } from '../lib/api';
import { generateSifFileContent, generateMudadCsvContent, downloadFile } from '../lib/mudad';
import { PayslipModal } from './PayslipModal';

export const ReportsManagement: React.FC = () => {
  const [activeReportTab, setActiveReportTab] = useState<
    'payroll' | 'attendance' | 'leaves' | 'advances'
  >('payroll');

  // Filter States
  const today = new Date();
  const firstDayThisMonth = new Date(today.getFullYear(), today.getMonth(), 1)
    .toISOString()
    .split('T')[0];
  const todayStr = today.toISOString().split('T')[0];

  const [datePreset, setDatePreset] = useState<string>('this_month');
  const [startDate, setStartDate] = useState<string>(firstDayThisMonth);
  const [endDate, setEndDate] = useState<string>(todayStr);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Data States
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Report Data
  const [payrollReport, setPayrollReport] = useState<{ totals: any; records: PayrollRecord[] }>({
    totals: { basic: 0, allowances: 0, overtime: 0, bonuses: 0, deductions: 0, net: 0 },
    records: [],
  });

  const [attendanceReport, setAttendanceReport] = useState<{ summary: any; records: any[] }>({
    summary: { totalRecords: 0, totalPresent: 0, totalLate: 0, totalCompleteShifts: 0 },
    records: [],
  });

  const [leaveReport, setLeaveReport] = useState<{ summary: any; records: LeaveRequest[] }>({
    summary: { totalRequests: 0, approved: 0, pending: 0, rejected: 0, byType: { Annual: 0, Sick: 0, Emergency: 0, Unpaid: 0 } },
    records: [],
  });

  const [advanceReport, setAdvanceReport] = useState<{ totals: any; records: CashAdvance[] }>({
    totals: { totalGranted: 0, totalBalance: 0, totalRepaid: 0, activeCount: 0 },
    records: [],
  });

  // Modal Payslip
  const [selectedPayslip, setSelectedPayslip] = useState<PayrollRecord | null>(null);

  // Load Employees list for filter
  useEffect(() => {
    api.getEmployees().then(setEmployees).catch(console.error);
  }, []);

  // Handle Date Preset Changes
  const handlePresetChange = (preset: string) => {
    setDatePreset(preset);
    const now = new Date();

    if (preset === 'this_month') {
      const s = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      const e = now.toISOString().split('T')[0];
      setStartDate(s);
      setEndDate(e);
    } else if (preset === 'last_month') {
      const s = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0];
      const lastDay = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
      const e = new Date(now.getFullYear(), now.getMonth() - 1, lastDay).toISOString().split('T')[0];
      setStartDate(s);
      setEndDate(e);
    } else if (preset === 'this_quarter') {
      const currentQuarter = Math.floor(now.getMonth() / 3);
      const s = new Date(now.getFullYear(), currentQuarter * 3, 1).toISOString().split('T')[0];
      const e = now.toISOString().split('T')[0];
      setStartDate(s);
      setEndDate(e);
    } else if (preset === 'this_year') {
      const s = `${now.getFullYear()}-01-01`;
      const e = now.toISOString().split('T')[0];
      setStartDate(s);
      setEndDate(e);
    }
  };

  // Fetch Reports when filters or tab change
  const loadReports = async () => {
    try {
      setLoading(true);
      const params = { startDate, endDate, employeeId: selectedEmployeeId };

      if (activeReportTab === 'payroll') {
        const res = await api.getPayrollSummaryReport(params);
        setPayrollReport(res);
      } else if (activeReportTab === 'attendance') {
        const res = await api.getAttendanceLogsReport(params);
        setAttendanceReport(res);
      } else if (activeReportTab === 'leaves') {
        const res = await api.getLeaveStatsReport(params);
        setLeaveReport(res);
      } else if (activeReportTab === 'advances') {
        const res = await api.getCashAdvancesReport({ employeeId: selectedEmployeeId });
        setAdvanceReport(res);
      }
    } catch (err) {
      console.error('Error fetching report data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, [activeReportTab, startDate, endDate, selectedEmployeeId]);

  // Export SIF File
  const handleExportSif = () => {
    if (!payrollReport.records || payrollReport.records.length === 0) {
      alert('No payroll records available in selected filter to export SIF file.');
      return;
    }
    const sifContent = generateSifFileContent(payrollReport.records, {
      establishmentId: '7001234567',
      bankCode: 'RJHI',
      payoutYearMonth: startDate.substring(0, 7),
      paymentDate: endDate,
    });
    downloadFile(`SIF_DUNYA_${startDate}_to_${endDate}.sif`, sifContent, 'text/plain');
  };

  // Export Mudad CSV
  const handleExportMudad = () => {
    if (!payrollReport.records || payrollReport.records.length === 0) {
      alert('No payroll records available in selected filter to export Mudad file.');
      return;
    }
    const csvContent = generateMudadCsvContent(payrollReport.records, {
      establishmentId: '7001234567',
      bankCode: 'RJHI',
      payoutYearMonth: startDate.substring(0, 7),
    });
    downloadFile(`MUDAD_WPS_${startDate}_to_${endDate}.csv`, csvContent, 'text/csv');
  };

  // Print current report view
  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div id="reports-management" className="space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white flex items-center gap-2 italic serif">
              <BarChart3 className="w-6 h-6 text-sky-400" />
              Executive Analytics & Reports Console
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Generate, filter, and export detailed HR reports for Payroll, Attendance, Leaves, and Outstanding Cash Advances.
          </p>
        </div>

        {/* Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 print:hidden">
          <button
            onClick={handleExportSif}
            className="px-3.5 py-2 bg-[#10b981] hover:bg-[#059669] text-white text-xs font-bold rounded-lg shadow-lg shadow-emerald-500/20 transition flex items-center gap-1.5 active:scale-95"
            title="Download Wage Protection System (WPS) SIF Bank File"
          >
            <Download className="w-4 h-4" />
            <span>Generate SIF File</span>
          </button>

          <button
            onClick={handleExportMudad}
            className="px-3.5 py-2 bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold rounded-lg shadow-lg shadow-sky-500/20 transition flex items-center gap-1.5 active:scale-95"
            title="Download Mudad KSA Government Payroll Compliance File"
          >
            <Download className="w-4 h-4" />
            <span>Mudad WPS Export</span>
          </button>

          <button
            onClick={handlePrintReport}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold rounded-lg transition flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4 text-sky-400" />
            <span>Print View</span>
          </button>
        </div>
      </div>

      {/* FILTER BAR PANEL */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-xl space-y-4 print:hidden">
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-sky-400 uppercase tracking-wider">
            <Filter className="w-4 h-4" />
            <span>Report Filtering Parameters</span>
          </div>
          <span className="text-[11px] text-slate-400">
            Dunya AlMuehmat for Office Equipments · KSA
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 text-xs">
          
          {/* Preset Selector (3 cols) */}
          <div className="lg:col-span-3 space-y-1">
            <label className="text-slate-400 font-semibold block text-[11px]">Quick Date Range</label>
            <select
              value={datePreset}
              onChange={(e) => handlePresetChange(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 py-2 px-3 rounded-lg font-medium focus:outline-none focus:border-sky-400"
            >
              <option value="this_month">This Month</option>
              <option value="last_month">Last Month</option>
              <option value="this_quarter">This Quarter</option>
              <option value="this_year">This Year (2026)</option>
              <option value="custom">Custom Date Range</option>
            </select>
          </div>

          {/* Start Date (2 cols) */}
          <div className="lg:col-span-2 space-y-1">
            <label className="text-slate-400 font-semibold block text-[11px]">Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setDatePreset('custom');
              }}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 py-2 px-2.5 rounded-lg font-mono focus:outline-none focus:border-sky-400"
            />
          </div>

          {/* End Date (2 cols) */}
          <div className="lg:col-span-2 space-y-1">
            <label className="text-slate-400 font-semibold block text-[11px]">End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setDatePreset('custom');
              }}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 py-2 px-2.5 rounded-lg font-mono focus:outline-none focus:border-sky-400"
            />
          </div>

          {/* Employee Filter (3 cols) */}
          <div className="lg:col-span-3 space-y-1">
            <label className="text-slate-400 font-semibold block text-[11px]">Filter Employee</label>
            <select
              value={selectedEmployeeId}
              onChange={(e) => setSelectedEmployeeId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 py-2 px-3 rounded-lg font-medium focus:outline-none focus:border-sky-400"
            >
              <option value="all">All Active & Inactive Staff</option>
              {employees.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.full_name} ({emp.employee_id})
                </option>
              ))}
            </select>
          </div>

          {/* Search Query Filter (2 cols) */}
          <div className="lg:col-span-2 space-y-1">
            <label className="text-slate-400 font-semibold block text-[11px]">Search Term</label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search..."
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 py-2 pl-8 pr-2.5 rounded-lg focus:outline-none focus:border-sky-400 text-xs"
              />
            </div>
          </div>

        </div>
      </div>

      {/* REPORT CATEGORY NAV TABS */}
      <div className="flex border-b border-slate-700 overflow-x-auto space-x-2 pb-0.5 print:hidden">
        <button
          onClick={() => setActiveReportTab('payroll')}
          className={`flex items-center space-x-2 py-3 px-5 text-xs sm:text-sm font-bold border-b-2 transition whitespace-nowrap ${
            activeReportTab === 'payroll'
              ? 'border-sky-400 text-sky-400 bg-slate-800/60 rounded-t-lg'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
          }`}
        >
          <Banknote className="w-4 h-4" />
          <span>Monthly Payroll Summaries</span>
        </button>

        <button
          onClick={() => setActiveReportTab('attendance')}
          className={`flex items-center space-x-2 py-3 px-5 text-xs sm:text-sm font-bold border-b-2 transition whitespace-nowrap ${
            activeReportTab === 'attendance'
              ? 'border-sky-400 text-sky-400 bg-slate-800/60 rounded-t-lg'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Detailed Attendance Logs</span>
        </button>

        <button
          onClick={() => setActiveReportTab('leaves')}
          className={`flex items-center space-x-2 py-3 px-5 text-xs sm:text-sm font-bold border-b-2 transition whitespace-nowrap ${
            activeReportTab === 'leaves'
              ? 'border-sky-400 text-sky-400 bg-slate-800/60 rounded-t-lg'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
          }`}
        >
          <CalendarDays className="w-4 h-4" />
          <span>Leave Usage Statistics</span>
        </button>

        <button
          onClick={() => setActiveReportTab('advances')}
          className={`flex items-center space-x-2 py-3 px-5 text-xs sm:text-sm font-bold border-b-2 transition whitespace-nowrap ${
            activeReportTab === 'advances'
              ? 'border-sky-400 text-sky-400 bg-slate-800/60 rounded-t-lg'
              : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
          }`}
        >
          <HandCoins className="w-4 h-4" />
          <span>Outstanding Cash Advances</span>
        </button>
      </div>

      {/* REPORT CONTENT VIEWPORT */}
      {loading ? (
        <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-12 text-center text-slate-400 text-xs">
          Loading report parameters and compiling data...
        </div>
      ) : (
        <>
          {/* REPORT 1: PAYROLL SUMMARY REPORT */}
          {activeReportTab === 'payroll' && (
            <div className="space-y-6">
              
              {/* Summary Metrics Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Basic</span>
                  <div className="text-lg font-bold text-slate-100 font-mono mt-1">
                    {payrollReport.totals.basic.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Allowances</span>
                  <div className="text-lg font-bold text-slate-100 font-mono mt-1">
                    {payrollReport.totals.allowances.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Overtime Pay</span>
                  <div className="text-lg font-bold text-sky-300 font-mono mt-1">
                    +{payrollReport.totals.overtime.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Bonuses Awarded</span>
                  <div className="text-lg font-bold text-emerald-400 font-mono mt-1">
                    +{payrollReport.totals.bonuses.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Deductions</span>
                  <div className="text-lg font-bold text-red-400 font-mono mt-1">
                    -{payrollReport.totals.deductions.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>

                <div className="bg-slate-900 border border-sky-400/60 rounded-xl p-4 shadow-xl">
                  <span className="text-[10px] uppercase font-bold text-sky-400 block">Net Payable Disbursed</span>
                  <div className="text-xl font-black text-white font-mono mt-1">
                    {payrollReport.totals.net.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>
              </div>

              {/* Mudad Government Integration Link Box */}
              <div className="bg-slate-900 border border-emerald-500/40 rounded-xl p-4 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                    WPS
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-100 text-sm italic serif">Mudad Wage Protection System (مدد)</h4>
                    <p className="text-xs text-slate-400">
                      Standardized KSA Ministry of Human Resources SIF / WPS File format ready for direct submission to Mudad & Saudi Banks.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportSif}
                    className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs transition shadow flex items-center gap-1.5"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download SIF File</span>
                  </button>
                  <a
                    href="https://mudad.com.sa"
                    target="_blank"
                    rel="noreferrer"
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-sky-400 font-bold rounded-lg text-xs border border-slate-700 transition flex items-center gap-1.5"
                  >
                    <span>Open Mudad Portal</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Records Table */}
              <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
                <div className="p-4 bg-slate-900/80 border-b border-slate-700 flex items-center justify-between">
                  <h3 className="font-bold text-slate-200 text-xs uppercase tracking-widest">
                    Payroll Records ({payrollReport.records.length})
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">Range: {startDate} to {endDate}</span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-900/60 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
                      <tr>
                        <th className="py-3 px-4">Employee Name</th>
                        <th className="py-3 px-4">Period</th>
                        <th className="py-3 px-4 text-right">Basic</th>
                        <th className="py-3 px-4 text-right">Allowances</th>
                        <th className="py-3 px-4 text-right text-sky-300">Overtime</th>
                        <th className="py-3 px-4 text-right text-emerald-400">Bonus</th>
                        <th className="py-3 px-4 text-right text-red-400">Deductions</th>
                        <th className="py-3 px-4 text-right font-bold text-sky-400">Net Salary (SAR)</th>
                        <th className="py-3 px-4 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60 font-mono text-[11px]">
                      {payrollReport.records.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="py-8 text-center text-slate-500 font-sans text-xs">
                            No payroll records found for selected period and filter.
                          </td>
                        </tr>
                      ) : (
                        payrollReport.records
                          .filter((r) =>
                            searchQuery
                              ? r.employee_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                r.employee_code?.toLowerCase().includes(searchQuery.toLowerCase())
                              : true
                          )
                          .map((r) => (
                            <tr key={r.id} className="hover:bg-slate-800/50 transition">
                              <td className="py-3 px-4 font-sans font-bold text-slate-100">
                                {r.employee_name}
                                <span className="block font-mono text-sky-400 text-[10px]">{r.employee_code}</span>
                              </td>
                              <td className="py-3 px-4 text-slate-400 text-[10px]">{r.period_start} to {r.period_end}</td>
                              <td className="py-3 px-4 text-right">{r.basic_salary.toLocaleString()}</td>
                              <td className="py-3 px-4 text-right">{r.allowances.toLocaleString()}</td>
                              <td className="py-3 px-4 text-right text-sky-300">{r.overtime_pay ? `+${r.overtime_pay.toLocaleString()}` : '0'}</td>
                              <td className="py-3 px-4 text-right text-emerald-400">{r.bonus_pay ? `+${r.bonus_pay.toLocaleString()}` : '0'}</td>
                              <td className="py-3 px-4 text-right text-red-400">
                                -{(r.insurance_deduction + r.cash_advance_deduction + r.deductions).toLocaleString()}
                              </td>
                              <td className="py-3 px-4 text-right font-bold text-sky-400 text-xs">
                                {r.net_salary.toLocaleString()} SAR
                              </td>
                              <td className="py-3 px-4 text-center font-sans">
                                <button
                                  onClick={() => setSelectedPayslip(r)}
                                  className="px-2.5 py-1 bg-sky-500/10 border border-sky-500/30 text-sky-400 font-bold rounded text-[11px] hover:bg-sky-500/20"
                                >
                                  Paystub
                                </button>
                              </td>
                            </tr>
                          ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* REPORT 2: DETAILED ATTENDANCE LOGS REPORT */}
          {activeReportTab === 'attendance' && (
            <div className="space-y-6">
              
              {/* Summary KPIs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Logged Entries</span>
                  <div className="text-2xl font-bold text-white mt-1">{attendanceReport.summary.totalRecords}</div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Present Punches</span>
                  <div className="text-2xl font-bold text-emerald-400 mt-1">{attendanceReport.summary.totalPresent}</div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Late Clock-Ins (&gt;8:30 AM)</span>
                  <div className="text-2xl font-bold text-amber-400 mt-1">{attendanceReport.summary.totalLate}</div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Completed Shifts (In + Out)</span>
                  <div className="text-2xl font-bold text-sky-400 mt-1">{attendanceReport.summary.totalCompleteShifts}</div>
                </div>
              </div>

              {/* Table */}
              <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
                <div className="p-4 bg-slate-900/80 border-b border-slate-700 flex items-center justify-between">
                  <h3 className="font-bold text-slate-200 text-xs uppercase tracking-widest">
                    Attendance Audit Trail ({attendanceReport.records.length})
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">Range: {startDate} to {endDate}</span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-900/60 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
                      <tr>
                        <th className="py-3 px-4">Date</th>
                        <th className="py-3 px-4">Employee</th>
                        <th className="py-3 px-4 text-center">Clock IN</th>
                        <th className="py-3 px-4 text-center">Clock OUT</th>
                        <th className="py-3 px-4 text-center">Punch Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60 font-mono text-[11px]">
                      {attendanceReport.records.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-8 text-center text-slate-500 font-sans text-xs">
                            No attendance punch records found in date range.
                          </td>
                        </tr>
                      ) : (
                        attendanceReport.records
                          .filter((r) =>
                            searchQuery
                              ? r.employee_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                r.employee_code?.toLowerCase().includes(searchQuery.toLowerCase())
                              : true
                          )
                          .map((r) => (
                            <tr key={r.id} className="hover:bg-slate-800/50 transition">
                              <td className="py-3 px-4 font-bold text-slate-200">{r.date}</td>
                              <td className="py-3 px-4 font-sans font-bold text-slate-100">
                                {r.employee_name}
                                <span className="block font-mono text-sky-400 text-[10px]">{r.employee_code}</span>
                              </td>
                              <td className="py-3 px-4 text-center text-emerald-400 font-bold">{r.time_in || '--:--'}</td>
                              <td className="py-3 px-4 text-center text-amber-400 font-bold">{r.time_out || '--:--'}</td>
                              <td className="py-3 px-4 text-center font-sans">
                                {r.status === 'Late Arrival' ? (
                                  <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[10px] font-bold rounded">
                                    Late Arrival
                                  </span>
                                ) : r.status === 'Present' ? (
                                  <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold rounded">
                                    On Time
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 bg-sky-500/10 border border-sky-500/30 text-sky-300 text-[10px] font-bold rounded">
                                    {r.status}
                                  </span>
                                )}
                              </td>
                            </tr>
                          ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* REPORT 3: LEAVE USAGE STATISTICS REPORT */}
          {activeReportTab === 'leaves' && (
            <div className="space-y-6">
              
              {/* Summary KPIs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Requests</span>
                  <div className="text-2xl font-bold text-white mt-1">{leaveReport.summary.totalRequests}</div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Approved Leave Days</span>
                  <div className="text-2xl font-bold text-emerald-400 mt-1">{leaveReport.summary.approved}</div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Pending Requests</span>
                  <div className="text-2xl font-bold text-amber-400 mt-1">{leaveReport.summary.pending}</div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Rejected Applications</span>
                  <div className="text-2xl font-bold text-red-400 mt-1">{leaveReport.summary.rejected}</div>
                </div>
              </div>

              {/* Leave Type Breakdown Bar */}
              <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-5 shadow-xl space-y-3">
                <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider">
                  Approved Days Breakdown by Leave Category
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
                    <span className="text-sky-400 font-sans font-bold block">Annual Paid Leave</span>
                    <span className="text-xl font-bold text-white mt-1 block">{leaveReport.summary.byType.Annual || 0} days</span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
                    <span className="text-emerald-400 font-sans font-bold block">Sick Leave</span>
                    <span className="text-xl font-bold text-white mt-1 block">{leaveReport.summary.byType.Sick || 0} days</span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
                    <span className="text-amber-400 font-sans font-bold block">Emergency Leave</span>
                    <span className="text-xl font-bold text-white mt-1 block">{leaveReport.summary.byType.Emergency || 0} days</span>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-700">
                    <span className="text-purple-400 font-sans font-bold block">Unpaid Leave</span>
                    <span className="text-xl font-bold text-white mt-1 block">{leaveReport.summary.byType.Unpaid || 0} days</span>
                  </div>
                </div>
              </div>

              {/* Table */}
              <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
                <div className="p-4 bg-slate-900/80 border-b border-slate-700 flex items-center justify-between">
                  <h3 className="font-bold text-slate-200 text-xs uppercase tracking-widest">
                    Submitted Leave Applications ({leaveReport.records.length})
                  </h3>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-900/60 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
                      <tr>
                        <th className="py-3 px-4">Employee</th>
                        <th className="py-3 px-4">Leave Type</th>
                        <th className="py-3 px-4">Start Date</th>
                        <th className="py-3 px-4">End Date</th>
                        <th className="py-3 px-4">Reason</th>
                        <th className="py-3 px-4 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60 text-xs">
                      {leaveReport.records.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-500">
                            No leave applications recorded in date range.
                          </td>
                        </tr>
                      ) : (
                        leaveReport.records
                          .filter((r) =>
                            searchQuery
                              ? r.employee_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                r.employee_code?.toLowerCase().includes(searchQuery.toLowerCase())
                              : true
                          )
                          .map((r) => (
                            <tr key={r.id} className="hover:bg-slate-800/50 transition">
                              <td className="py-3 px-4 font-bold text-slate-100">
                                {r.employee_name}
                                <span className="block font-mono text-sky-400 text-[10px]">{r.employee_code}</span>
                              </td>
                              <td className="py-3 px-4 font-semibold text-slate-300">{r.leave_type}</td>
                              <td className="py-3 px-4 font-mono text-slate-400">{r.start_date}</td>
                              <td className="py-3 px-4 font-mono text-slate-400">{r.end_date}</td>
                              <td className="py-3 px-4 text-slate-400 italic max-w-xs truncate">{r.reason || '—'}</td>
                              <td className="py-3 px-4 text-center">
                                <span
                                  className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                                    r.status === 'approved'
                                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                      : r.status === 'rejected'
                                      ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                                      : 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                                  }`}
                                >
                                  {r.status}
                                </span>
                              </td>
                            </tr>
                          ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* REPORT 4: OUTSTANDING CASH ADVANCES BREAKDOWN */}
          {activeReportTab === 'advances' && (
            <div className="space-y-6">
              
              {/* Summary KPIs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Granted</span>
                  <div className="text-xl font-bold text-white font-mono mt-1">
                    {advanceReport.totals.totalGranted.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Repaid via Payroll</span>
                  <div className="text-xl font-bold text-emerald-400 font-mono mt-1">
                    {advanceReport.totals.totalRepaid.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>

                <div className="bg-slate-900 border border-amber-500/50 rounded-xl p-4 shadow-xl">
                  <span className="text-[10px] uppercase font-bold text-amber-400 block">Outstanding Balance</span>
                  <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                    {advanceReport.totals.totalBalance.toLocaleString()} <span className="text-xs text-sky-400 font-sans">SAR</span>
                  </div>
                </div>

                <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-lg">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Active Borrowers</span>
                  <div className="text-2xl font-bold text-sky-400 mt-1">{advanceReport.totals.activeCount}</div>
                </div>
              </div>

              {/* Itemized Table */}
              <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
                <div className="p-4 bg-slate-900/80 border-b border-slate-700 flex items-center justify-between">
                  <h3 className="font-bold text-slate-200 text-xs uppercase tracking-widest">
                    Cash Advances Ledger ({advanceReport.records.length})
                  </h3>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-900/60 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
                      <tr>
                        <th className="py-3 px-4">Employee</th>
                        <th className="py-3 px-4 text-right">Original Amount</th>
                        <th className="py-3 px-4 text-right text-emerald-400">Repaid to Date</th>
                        <th className="py-3 px-4 text-right text-amber-400 font-bold">Remaining Balance</th>
                        <th className="py-3 px-4 text-right">Monthly Deduction</th>
                        <th className="py-3 px-4 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60 font-mono text-[11px]">
                      {advanceReport.records.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-500 font-sans text-xs">
                            No cash advances found for selected filter.
                          </td>
                        </tr>
                      ) : (
                        advanceReport.records
                          .filter((r) =>
                            searchQuery
                              ? r.employee_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                r.employee_code?.toLowerCase().includes(searchQuery.toLowerCase())
                              : true
                          )
                          .map((r) => {
                            const repaid = r.amount - r.balance;
                            return (
                              <tr key={r.id} className="hover:bg-slate-800/50 transition">
                                <td className="py-3 px-4 font-sans font-bold text-slate-100">
                                  {r.employee_name}
                                  <span className="block font-mono text-sky-400 text-[10px]">{r.employee_code}</span>
                                </td>
                                <td className="py-3 px-4 text-right text-slate-200">{r.amount.toLocaleString()} SAR</td>
                                <td className="py-3 px-4 text-right text-emerald-400">{repaid.toLocaleString()} SAR</td>
                                <td className="py-3 px-4 text-right text-amber-400 font-bold text-xs">{r.balance.toLocaleString()} SAR</td>
                                <td className="py-3 px-4 text-right text-slate-300">-{r.monthly_deduction.toLocaleString()} SAR/mo</td>
                                <td className="py-3 px-4 text-center font-sans">
                                  <span
                                    className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                                      r.status === 'active'
                                        ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                    }`}
                                  >
                                    {r.status === 'active' ? 'Repaying' : 'Paid in Full'}
                                  </span>
                                </td>
                              </tr>
                            );
                          })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}
        </>
      )}

      {/* PAYSLIP MODAL */}
      {selectedPayslip && (
        <PayslipModal record={selectedPayslip} onClose={() => setSelectedPayslip(null)} />
      )}

    </div>
  );
};
