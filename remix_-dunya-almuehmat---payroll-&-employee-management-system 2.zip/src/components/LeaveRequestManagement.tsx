import React, { useState, useEffect } from 'react';
import {
  CalendarDays,
  Filter,
  Check,
  X,
  MessageCircle,
  Mail,
} from 'lucide-react';
import { LeaveRequest } from '../types';
import { api } from '../lib/api';
import { getWhatsAppUrl, getEmailUrl, notificationTemplates } from '../lib/notifications';

export const LeaveRequestManagement: React.FC = () => {
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const loadRequests = async () => {
    try {
      setLoading(true);
      const data = await api.getLeaveRequests();
      setRequests(data);
    } catch (err) {
      console.error('Error loading leave requests:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, []);

  const handleUpdateStatus = async (id: number, status: 'approved' | 'rejected') => {
    try {
      await api.updateLeaveStatus(id, status);
      loadRequests();
    } catch (err: any) {
      alert(err.message || 'Error updating status.');
    }
  };

  const filteredRequests = requests.filter((r) => {
    if (filterStatus === 'all') return true;
    return r.status === filterStatus;
  });

  return (
    <div id="leave-request-management" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2 italic serif">
            <CalendarDays className="w-6 h-6 text-sky-400" />
            Leave Request Approvals
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Review and approve leave applications submitted via Employee Kiosk.
          </p>
        </div>

        {/* Filter Dropdown */}
        <div className="flex items-center space-x-2 bg-[#1e293b] border border-slate-700 p-2 rounded-xl">
          <Filter className="w-4 h-4 text-sky-400 ml-1" />
          <span className="text-xs text-slate-300 font-medium">Status:</span>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-100 py-1.5 px-3 rounded-lg text-xs focus:outline-none focus:border-sky-400"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending Approval</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
              <tr>
                <th className="py-3.5 px-4">Employee</th>
                <th className="py-3.5 px-4">Leave Type</th>
                <th className="py-3.5 px-4 font-mono">Start - End Date</th>
                <th className="py-3.5 px-4">Reason</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/60">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    Loading leave requests...
                  </td>
                </tr>
              ) : filteredRequests.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No leave requests found matching this status.
                  </td>
                </tr>
              ) : (
                filteredRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-800/50 transition">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-100">{req.employee_name}</div>
                      <div className="font-mono text-sky-400 text-[11px]">{req.employee_code}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-sky-300">{req.leave_type}</span>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-300">
                      {req.start_date} → {req.end_date}
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 max-w-xs truncate">
                      {req.reason || 'No details provided.'}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                          req.status === 'approved'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : req.status === 'rejected'
                            ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/30 animate-pulse'
                        }`}
                      >
                        {req.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {req.status === 'pending' ? (
                        <div className="flex items-center justify-center space-x-2">
                          <button
                            onClick={() => handleUpdateStatus(req.id, 'approved')}
                            className="px-2.5 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 rounded-lg font-bold text-[11px] transition flex items-center gap-1 active:scale-95"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(req.id, 'rejected')}
                            className="px-2.5 py-1 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 rounded-lg font-bold text-[11px] transition flex items-center gap-1 active:scale-95"
                          >
                            <X className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center space-x-2">
                          {(() => {
                            const tpl = notificationTemplates.leaveStatus(req.employee_name, req.leave_type, req.status, req.start_date, req.end_date);
                            const waUrl = getWhatsAppUrl(req.phone_number, tpl.text);
                            const mailUrl = getEmailUrl(req.email, tpl.subject, tpl.text);
                            return (
                              <>
                                <a
                                  href={waUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  title="Send Status via WhatsApp"
                                  className="p-1.5 bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 border border-emerald-500/30 rounded-lg transition text-[11px] font-bold flex items-center gap-1"
                                >
                                  <MessageCircle className="w-3.5 h-3.5" />
                                  <span>WhatsApp</span>
                                </a>
                                <a
                                  href={mailUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  title="Send Status via Email"
                                  className="p-1.5 bg-sky-500/10 hover:bg-sky-500 text-sky-400 hover:text-slate-950 border border-sky-500/30 rounded-lg transition text-[11px] font-bold flex items-center gap-1"
                                >
                                  <Mail className="w-3.5 h-3.5" />
                                  <span>Email</span>
                                </a>
                              </>
                            );
                          })()}
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
