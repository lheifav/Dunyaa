import React, { useState, useEffect } from 'react';
import {
  HandCoins,
  Plus,
  Trash2,
  Edit2,
  X,
  MessageCircle,
  Mail,
} from 'lucide-react';
import { CashAdvance, Employee } from '../types';
import { api } from '../lib/api';
import { getWhatsAppUrl, getEmailUrl, notificationTemplates } from '../lib/notifications';

export const CashAdvanceManagement: React.FC = () => {
  const [advances, setAdvances] = useState<CashAdvance[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);

  // Grant Modal State
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    employee_id: 0,
    amount: 1000,
    monthly_deduction: 250,
  });

  // Repayment Modal
  const [editingAdvance, setEditingAdvance] = useState<CashAdvance | null>(null);
  const [repayData, setRepayData] = useState({
    balance: 0,
    monthly_deduction: 0,
  });

  const loadAdvances = async () => {
    try {
      setLoading(true);
      const data = await api.getCashAdvances();
      setAdvances(data);
    } catch (err) {
      console.error('Error loading cash advances:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadEmployees = async () => {
    try {
      const emps = await api.getEmployees({ status: 'active' });
      setEmployees(emps);
      if (emps.length > 0 && formData.employee_id === 0) {
        setFormData((prev) => ({ ...prev, employee_id: emps[0].id }));
      }
    } catch (err) {
      console.error('Error loading employees:', err);
    }
  };

  useEffect(() => {
    loadEmployees();
    loadAdvances();
  }, []);

  const handleGrantAdvance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.employee_id) return;

    try {
      await api.createCashAdvance(formData);
      setShowModal(false);
      loadAdvances();
    } catch (err: any) {
      alert(err.message || 'Error granting cash advance.');
    }
  };

  const handleUpdateAdvance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdvance) return;

    try {
      await api.updateCashAdvance(editingAdvance.id, repayData);
      setEditingAdvance(null);
      loadAdvances();
    } catch (err: any) {
      alert(err.message || 'Error updating cash advance.');
    }
  };

  const handleDelete = async (id: number) => {
    if (confirm('Delete this cash advance record?')) {
      try {
        await api.deleteCashAdvance(id);
        loadAdvances();
      } catch (err: any) {
        alert(err.message || 'Error deleting advance.');
      }
    }
  };

  return (
    <div id="cash-advance-management" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2 italic serif">
            <HandCoins className="w-6 h-6 text-sky-400" />
            Cash Advance Tracker
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Grant employee cash advances and set automatic monthly repayment deductions.
          </p>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-lg text-xs transition shadow-lg shadow-sky-500/20 flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Grant Cash Advance</span>
        </button>
      </div>

      {/* Table */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
              <tr>
                <th className="py-3.5 px-4">Employee</th>
                <th className="py-3.5 px-4 text-right">Original Amount</th>
                <th className="py-3.5 px-4 text-right">Remaining Balance</th>
                <th className="py-3.5 px-4 text-right">Monthly Deduction</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/60">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    Loading cash advance records...
                  </td>
                </tr>
              ) : advances.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No cash advances recorded yet.
                  </td>
                </tr>
              ) : (
                advances.map((adv) => (
                  <tr key={adv.id} className="hover:bg-slate-800/50 transition">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-100">{adv.employee_name}</div>
                      <div className="font-mono text-sky-400 text-[11px]">{adv.employee_code}</div>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-slate-200 font-bold">
                      {adv.amount.toLocaleString()} SAR
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-amber-400 font-bold text-sm">
                      {adv.balance.toLocaleString()} SAR
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-slate-300">
                      {adv.monthly_deduction.toLocaleString()} SAR/mo
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                          adv.status === 'active'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                            : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        }`}
                      >
                        {adv.status === 'active' ? 'Active' : 'Paid Off'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center space-x-2">
                        {(() => {
                          const tpl = notificationTemplates.cashAdvanceDeduction(adv.employee_name, adv.monthly_deduction, adv.balance);
                          const waUrl = getWhatsAppUrl(adv.phone_number, tpl.text);
                          const mailUrl = getEmailUrl(adv.email, tpl.subject, tpl.text);
                          return (
                            <>
                              <a
                                href={waUrl}
                                target="_blank"
                                rel="noreferrer"
                                title="Send Alert via WhatsApp"
                                className="p-1.5 bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 border border-emerald-500/30 rounded-lg transition text-[11px] font-bold flex items-center gap-1 active:scale-95"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">WhatsApp</span>
                              </a>
                              <a
                                href={mailUrl}
                                target="_blank"
                                rel="noreferrer"
                                title="Send Alert via Email"
                                className="p-1.5 bg-sky-500/10 hover:bg-sky-500 text-sky-400 hover:text-slate-950 border border-sky-500/30 rounded-lg transition text-[11px] font-bold flex items-center gap-1 active:scale-95"
                              >
                                <Mail className="w-3.5 h-3.5" />
                                <span className="hidden sm:inline">Email</span>
                              </a>
                            </>
                          );
                        })()}

                        <button
                          onClick={() => {
                            setEditingAdvance(adv);
                            setRepayData({
                              balance: adv.balance,
                              monthly_deduction: adv.monthly_deduction,
                            });
                          }}
                          className="p-1.5 text-slate-400 hover:text-sky-400 hover:bg-slate-800 rounded transition active:scale-95"
                          title="Adjust Balance / Repayment"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(adv.id)}
                          className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded transition active:scale-95"
                          title="Delete Record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* GRANT CASH ADVANCE MODAL */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700 mb-4">
              <h3 className="font-bold text-lg text-slate-100 flex items-center gap-2 italic serif">
                <HandCoins className="w-5 h-5 text-sky-400" />
                Grant Cash Advance
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleGrantAdvance} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Employee *
                </label>
                <select
                  required
                  value={formData.employee_id}
                  onChange={(e) => setFormData({ ...formData, employee_id: Number(e.target.value) })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.full_name} ({emp.employee_id})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Advance Amount (SAR) *
                </label>
                <input
                  type="number"
                  required
                  min={100}
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Monthly Deduction per Payroll (SAR) *
                </label>
                <input
                  type="number"
                  required
                  min={50}
                  value={formData.monthly_deduction}
                  onChange={(e) => setFormData({ ...formData, monthly_deduction: Number(e.target.value) })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="pt-3 flex items-center justify-end space-x-3 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-xs font-bold shadow-lg shadow-sky-500/20"
                >
                  Confirm Advance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADJUST BALANCE / REPAYMENT MODAL */}
      {editingAdvance && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700 mb-4">
              <h3 className="font-bold text-lg text-slate-100 flex items-center gap-2 italic serif">
                <Edit2 className="w-5 h-5 text-sky-400" />
                Adjust Cash Advance Balance
              </h3>
              <button onClick={() => setEditingAdvance(null)} className="text-slate-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Updating for <strong className="text-slate-200">{editingAdvance.employee_name}</strong>
            </p>

            <form onSubmit={handleUpdateAdvance} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Remaining Balance (SAR)
                </label>
                <input
                  type="number"
                  required
                  min={0}
                  value={repayData.balance}
                  onChange={(e) => setRepayData({ ...repayData, balance: Number(e.target.value) })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Monthly Repayment Deduction (SAR)
                </label>
                <input
                  type="number"
                  required
                  min={0}
                  value={repayData.monthly_deduction}
                  onChange={(e) => setRepayData({ ...repayData, monthly_deduction: Number(e.target.value) })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="pt-3 flex items-center justify-end space-x-3 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setEditingAdvance(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-xs font-bold shadow-lg shadow-sky-500/20"
                >
                  Save Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
