import React, { useState, useEffect } from 'react';
import {
  Award,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Calculator,
  MessageCircle,
  Mail,
  Sparkles,
  DollarSign,
  TrendingUp,
  Clock,
  Send,
} from 'lucide-react';
import { api } from '../lib/api';
import { OvertimeRule, EmployeeBonus, Employee, BonusType } from '../types';
import { getWhatsAppUrl, getEmailUrl, notificationTemplates } from '../lib/notifications';

export const OvertimeBonusManagement: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'overtime' | 'bonuses'>('overtime');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [rules, setRules] = useState<OvertimeRule[]>([]);
  const [bonuses, setBonuses] = useState<EmployeeBonus[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // New Rule Form Modal / State
  const [showRuleModal, setShowRuleModal] = useState(false);
  const [editingRule, setEditingRule] = useState<OvertimeRule | null>(null);
  const [ruleName, setRuleName] = useState('');
  const [multiplier, setMultiplier] = useState(1.5);
  const [ruleDescription, setRuleDescription] = useState('');

  // New Bonus Form Modal / State
  const [showBonusModal, setShowBonusModal] = useState(false);
  const [selectedEmpId, setSelectedEmpId] = useState<number | ''>('');
  const [bonusType, setBonusType] = useState<BonusType>('Performance Bonus');
  const [bonusAmount, setBonusAmount] = useState<number | ''>(500);
  const [effectiveDate, setEffectiveDate] = useState(new Date().toISOString().split('T')[0]);
  const [bonusDescription, setBonusDescription] = useState('');

  // Interactive Overtime Calculator State
  const [calcBaseSalary, setCalcBaseSalary] = useState<number>(6500);
  const [calcAllowances, setCalcAllowances] = useState<number>(1500);
  const [calcHours, setCalcHours] = useState<number>(10);
  const [calcRuleId, setCalcRuleId] = useState<number>(0);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [empList, ruleList, bonusList] = await Promise.all([
        api.getEmployees({ status: 'active' }),
        api.getOvertimeRules(),
        api.getBonuses(),
      ]);
      setEmployees(empList);
      setRules(ruleList);
      setBonuses(bonusList);
      if (ruleList.length > 0 && !calcRuleId) {
        setCalcRuleId(ruleList[0].id);
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to load overtime and bonus data.' });
    } finally {
      setLoading(false);
    }
  };

  // Rule Handlers
  const handleOpenNewRule = () => {
    setEditingRule(null);
    setRuleName('');
    setMultiplier(1.5);
    setRuleDescription('');
    setShowRuleModal(true);
  };

  const handleEditRule = (r: OvertimeRule) => {
    setEditingRule(r);
    setRuleName(r.rule_name);
    setMultiplier(r.multiplier);
    setRuleDescription(r.description || '');
    setShowRuleModal(true);
  };

  const handleSaveRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleName.trim() || multiplier <= 0) return;

    try {
      if (editingRule) {
        await api.updateOvertimeRule(editingRule.id, {
          rule_name: ruleName.trim(),
          multiplier: Number(multiplier),
          description: ruleDescription.trim(),
        });
        setMessage({ type: 'success', text: `Overtime rule "${ruleName}" updated successfully.` });
      } else {
        await api.createOvertimeRule({
          rule_name: ruleName.trim(),
          multiplier: Number(multiplier),
          description: ruleDescription.trim(),
        });
        setMessage({ type: 'success', text: `Custom overtime rule "${ruleName}" created successfully.` });
      }
      setShowRuleModal(false);
      loadData();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to save overtime rule.' });
    }
  };

  const handleDeleteRule = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this overtime rule?')) return;
    try {
      await api.deleteOvertimeRule(id);
      setMessage({ type: 'success', text: 'Overtime rule deleted.' });
      loadData();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to delete rule.' });
    }
  };

  // Bonus Handlers
  const handleOpenNewBonus = () => {
    setSelectedEmpId(employees.length > 0 ? employees[0].id : '');
    setBonusType('Performance Bonus');
    setBonusAmount(500);
    setEffectiveDate(new Date().toISOString().split('T')[0]);
    setBonusDescription('');
    setShowBonusModal(true);
  };

  const handleSaveBonus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmpId || !bonusAmount || Number(bonusAmount) <= 0) return;

    try {
      const createdBonus = await api.createBonus({
        employee_id: Number(selectedEmpId),
        bonus_type: bonusType,
        amount: Number(bonusAmount),
        effective_date: effectiveDate,
        description: bonusDescription,
      });

      const emp = employees.find((e) => e.id === Number(selectedEmpId));
      setMessage({
        type: 'success',
        text: `Bonus of ${Number(bonusAmount).toLocaleString()} SAR assigned to ${emp?.full_name || 'employee'}.`,
      });
      setShowBonusModal(false);
      loadData();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to award bonus.' });
    }
  };

  const handleCancelBonus = async (id: number) => {
    if (!window.confirm('Are you sure you want to cancel this pending bonus?')) return;
    try {
      await api.cancelBonus(id);
      setMessage({ type: 'success', text: 'Bonus cancelled.' });
      loadData();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to cancel bonus.' });
    }
  };

  // Calculator Logic
  const activeRule = rules.find((r) => r.id === Number(calcRuleId)) || rules[0];
  const hourlyBaseRate = (Number(calcBaseSalary) + Number(calcAllowances)) / 240;
  const calcMultiplier = activeRule ? activeRule.multiplier : 1.5;
  const totalOvertimePayout = Math.round(hourlyBaseRate * calcMultiplier * Number(calcHours) * 100) / 100;

  return (
    <div id="overtime-bonus-view" className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-700/80 pb-5">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2 italic serif">
            <Award className="w-6 h-6 text-sky-400" />
            Custom Overtime Rules & Bonus Processing Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure custom overtime multipliers, issue itemized bonuses, and process payroll earnings with instant employee WhatsApp & Email notifications.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeSubTab === 'overtime' ? (
            <button
              onClick={handleOpenNewRule}
              className="py-2 px-4 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl text-xs transition flex items-center gap-2 shadow-lg shadow-sky-500/20 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Add Overtime Rule</span>
            </button>
          ) : (
            <button
              onClick={handleOpenNewBonus}
              className="py-2 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition flex items-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Award Employee Bonus</span>
            </button>
          )}
        </div>
      </div>

      {/* Global Alert Message */}
      {message && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-3 shadow-lg ${
            message.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-red-500/10 border-red-500/30 text-red-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            )}
            <span>{message.text}</span>
          </div>
          <button
            onClick={() => setMessage(null)}
            className="text-slate-400 hover:text-white font-bold text-xs"
          >
            ✕
          </button>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-700 space-x-6">
        <button
          onClick={() => setActiveSubTab('overtime')}
          className={`pb-3 text-xs font-bold transition flex items-center gap-2 border-b-2 ${
            activeSubTab === 'overtime'
              ? 'border-sky-400 text-sky-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Custom Overtime Rules ({rules.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('bonuses')}
          className={`pb-3 text-xs font-bold transition flex items-center gap-2 border-b-2 ${
            activeSubTab === 'bonuses'
              ? 'border-emerald-400 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Itemized Bonuses & Awards ({bonuses.length})</span>
        </button>
      </div>

      {/* SUB-TAB 1: OVERTIME RULES & CALCULATOR */}
      {activeSubTab === 'overtime' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Rules List (2 Columns) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-400" />
                <span>Configured Overtime Rate Rules</span>
              </h3>
              <span className="text-[11px] text-slate-400">
                Calculated on 240 hrs/month base hourly rate
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {rules.map((rule) => (
                <div
                  key={rule.id}
                  className="bg-[#1e293b] border border-slate-700/80 hover:border-sky-500/40 rounded-2xl p-5 shadow-xl transition relative group"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="inline-block px-2.5 py-1 bg-sky-500/10 border border-sky-500/30 text-sky-300 font-mono font-bold text-xs rounded-lg mb-2">
                        {rule.multiplier}x Multiplier
                      </span>
                      <h4 className="font-bold text-slate-100 text-sm">{rule.rule_name}</h4>
                    </div>

                    <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition">
                      <button
                        onClick={() => handleEditRule(rule)}
                        title="Edit Rule"
                        className="p-1.5 text-slate-400 hover:text-sky-300 hover:bg-slate-800 rounded-lg transition"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteRule(rule.id)}
                        title="Delete Rule"
                        className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    {rule.description || 'Custom company overtime rule'}
                  </p>

                  <div className="mt-4 pt-3 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-400">
                    <span>Labor Law Standard:</span>
                    <span className="font-bold text-slate-200">
                      {rule.multiplier === 1.5 ? 'Standard 150%' : rule.multiplier >= 2 ? 'Double 200%' : 'Special Rate'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Overtime Calculator Simulator (1 Column) */}
          <div className="bg-[#1e293b] border border-sky-500/30 rounded-2xl p-5 shadow-xl space-y-4 h-fit">
            <div className="flex items-center space-x-2 pb-3 border-b border-slate-700">
              <Calculator className="w-5 h-5 text-sky-400" />
              <h3 className="font-bold text-slate-100 text-sm italic serif">Overtime Calculation Simulator</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Test custom overtime payouts in real-time based on employee basic salary and selected multiplier rule.
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Basic Monthly Salary (SAR)
                </label>
                <input
                  type="number"
                  value={calcBaseSalary}
                  onChange={(e) => setCalcBaseSalary(Number(e.target.value))}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-xs focus:outline-none focus:border-sky-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Fixed Allowances (SAR)
                </label>
                <input
                  type="number"
                  value={calcAllowances}
                  onChange={(e) => setCalcAllowances(Number(e.target.value))}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-xs focus:outline-none focus:border-sky-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Overtime Hours Worked
                </label>
                <input
                  type="number"
                  value={calcHours}
                  onChange={(e) => setCalcHours(Number(e.target.value))}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-xs focus:outline-none focus:border-sky-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Applied Overtime Multiplier Rule
                </label>
                <select
                  value={calcRuleId}
                  onChange={(e) => setCalcRuleId(Number(e.target.value))}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-xs focus:outline-none focus:border-sky-400"
                >
                  {rules.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.rule_name} ({r.multiplier}x)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Calculated Result Card */}
            <div className="p-4 bg-slate-900/90 rounded-xl border border-sky-500/30 space-y-2 mt-4 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Base Hourly Rate:</span>
                <span className="font-mono text-slate-200">{hourlyBaseRate.toFixed(2)} SAR/hr</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Effective Overtime Rate:</span>
                <span className="font-mono text-sky-300">{(hourlyBaseRate * calcMultiplier).toFixed(2)} SAR/hr</span>
              </div>
              <div className="pt-2 border-t border-slate-800 flex justify-between items-center text-sm font-bold">
                <span className="text-white">Estimated Overtime Pay:</span>
                <span className="font-mono text-emerald-400 text-base">{totalOvertimePayout.toLocaleString()} SAR</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: ITEMIZED BONUSES */}
      {activeSubTab === 'bonuses' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Assigned Employee Bonuses & Incentives</span>
            </h3>
            <span className="text-[11px] text-slate-400">
              Pending bonuses are automatically included during monthly payroll generation.
            </span>
          </div>

          <div className="bg-[#1e293b] border border-slate-700/80 rounded-2xl shadow-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-900/70 uppercase text-[10px] font-bold text-slate-400 border-b border-slate-700">
                  <tr>
                    <th className="py-3.5 px-4">Employee</th>
                    <th className="py-3.5 px-4">Bonus Type</th>
                    <th className="py-3.5 px-4">Amount (SAR)</th>
                    <th className="py-3.5 px-4">Effective Date</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4 text-center">Employee Dispatch (WhatsApp / Email)</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {bonuses.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400 italic">
                        No employee bonuses recorded yet. Click "Award Employee Bonus" to issue one.
                      </td>
                    </tr>
                  ) : (
                    bonuses.map((b) => {
                      const emp = employees.find((e) => e.id === b.employee_id);
                      const tpl = notificationTemplates.bonusAwarded(b, emp);
                      const waUrl = getWhatsAppUrl(emp?.phone_number, tpl.text);
                      const mailUrl = getEmailUrl(emp?.email, tpl.subject, tpl.text);

                      return (
                        <tr key={b.id} className="hover:bg-slate-800/50 transition">
                          <td className="py-3 px-4 font-bold text-white">
                            <div>{b.employee_name || emp?.full_name || 'Employee'}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{b.employee_code || emp?.employee_id}</div>
                          </td>
                          <td className="py-3 px-4">
                            <span className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-semibold rounded-lg text-[11px]">
                              {b.bonus_type}
                            </span>
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-emerald-400 text-sm">
                            +{b.amount.toLocaleString()} SAR
                          </td>
                          <td className="py-3 px-4 font-mono text-slate-300">
                            {b.effective_date}
                          </td>
                          <td className="py-3 px-4">
                            {b.status === 'pending' && (
                              <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold rounded-full text-[10px]">
                                Pending Payroll
                              </span>
                            )}
                            {b.status === 'processed' && (
                              <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold rounded-full text-[10px]">
                                Included in Paystub
                              </span>
                            )}
                            {b.status === 'cancelled' && (
                              <span className="px-2 py-0.5 bg-red-500/10 border border-red-500/30 text-red-400 font-bold rounded-full text-[10px]">
                                Cancelled
                              </span>
                            )}
                          </td>

                          {/* Quick WhatsApp & Email Notification Dispatch */}
                          <td className="py-3 px-4 text-center">
                            <div className="flex items-center justify-center gap-2">
                              <a
                                href={waUrl}
                                target="_blank"
                                rel="noreferrer"
                                title="Send Bonus Notice via WhatsApp"
                                className="p-1.5 bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 rounded-lg transition border border-emerald-500/30 active:scale-95 flex items-center gap-1 text-[11px] font-bold"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                                <span>WhatsApp</span>
                              </a>

                              <a
                                href={mailUrl}
                                target="_blank"
                                rel="noreferrer"
                                title="Send Bonus Notice via Email"
                                className="p-1.5 bg-sky-500/20 hover:bg-sky-500 text-sky-300 hover:text-slate-950 rounded-lg transition border border-sky-500/30 active:scale-95 flex items-center gap-1 text-[11px] font-bold"
                              >
                                <Mail className="w-3.5 h-3.5" />
                                <span>Email</span>
                              </a>
                            </div>
                          </td>

                          <td className="py-3 px-4 text-right">
                            {b.status === 'pending' && (
                              <button
                                onClick={() => handleCancelBonus(b.id)}
                                className="text-xs text-red-400 hover:text-red-300 font-bold hover:underline"
                              >
                                Cancel
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* OVERTIME RULE MODAL */}
      {showRuleModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1e293b] border border-sky-500/40 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-white italic serif">
              {editingRule ? 'Edit Overtime Multiplier Rule' : 'Create Custom Overtime Rule'}
            </h3>

            <form onSubmit={handleSaveRule} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Rule Name / Title *
                </label>
                <input
                  type="text"
                  required
                  value={ruleName}
                  onChange={(e) => setRuleName(e.target.value)}
                  placeholder="e.g. Time-and-a-Half (1.5x)"
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Overtime Hourly Multiplier * (e.g. 1.5, 2.0)
                </label>
                <input
                  type="number"
                  step="0.05"
                  min="1"
                  max="5"
                  required
                  value={multiplier}
                  onChange={(e) => setMultiplier(Number(e.target.value))}
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono focus:outline-none focus:border-sky-400"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  Standard Saudi Labor Law is 1.5x (Time-and-a-half) or 2.0x (Holiday/Friday Double-time).
                </p>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Description / Criteria
                </label>
                <textarea
                  rows={2}
                  value={ruleDescription}
                  onChange={(e) => setRuleDescription(e.target.value)}
                  placeholder="Describe when this rate applies (e.g., Workday overtime, weekend shift, holiday)"
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRuleModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl shadow-lg shadow-sky-500/20"
                >
                  Save Rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BONUS AWARD MODAL */}
      {showBonusModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1e293b] border border-emerald-500/40 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-white italic serif flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <span>Award Employee Bonus</span>
            </h3>

            <form onSubmit={handleSaveBonus} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Select Employee *
                </label>
                <select
                  required
                  value={selectedEmpId}
                  onChange={(e) => setSelectedEmpId(Number(e.target.value))}
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:border-emerald-400"
                >
                  {employees.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.full_name} ({e.employee_id}) - {e.job_title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Bonus Category *
                </label>
                <select
                  value={bonusType}
                  onChange={(e) => setBonusType(e.target.value as BonusType)}
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:border-emerald-400"
                >
                  <option value="Performance Bonus">Performance Bonus</option>
                  <option value="Holiday / Eid Bonus">Holiday / Eid Bonus</option>
                  <option value="Signing Bonus">Signing / Loyalty Bonus</option>
                  <option value="Custom Incentive">Custom Incentive Bonus</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Bonus Amount (SAR) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={bonusAmount}
                  onChange={(e) => setBonusAmount(Number(e.target.value))}
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Effective Date
                </label>
                <input
                  type="date"
                  required
                  value={effectiveDate}
                  onChange={(e) => setEffectiveDate(e.target.value)}
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Notes / Description
                </label>
                <textarea
                  rows={2}
                  value={bonusDescription}
                  onChange={(e) => setBonusDescription(e.target.value)}
                  placeholder="Reason for bonus award (e.g. Excellent Q2 sales performance)"
                  className="w-full py-2.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBonusModal(false)}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl shadow-lg shadow-emerald-500/20"
                >
                  Award Bonus
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
