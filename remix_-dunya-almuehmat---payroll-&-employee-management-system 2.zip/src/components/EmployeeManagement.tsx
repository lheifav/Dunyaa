import React, { useState, useEffect } from 'react';
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  AlertTriangle,
  X,
  CheckCircle,
  Building2,
  DollarSign,
  ShieldCheck,
  CreditCard,
  Calendar,
} from 'lucide-react';
import { Employee, NationalityType, EmployeeStatus } from '../types';
import { api } from '../lib/api';

export const EmployeeManagement: React.FC = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterNationality, setFilterNationality] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Modal State
  const [showModal, setShowModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [formData, setFormData] = useState({
    employee_id: '',
    full_name: '',
    phone_number: '',
    email: '',
    nationality: 'Saudi' as NationalityType,
    iqama_number: '',
    iqama_expiry: '',
    passport_number: '',
    job_title: '',
    hire_date: new Date().toISOString().split('T')[0],
    basic_salary: 5000,
    allowances: 1000,
    insurance: 300,
    iban: 'SA',
    pin_code: '',
    status: 'active' as EmployeeStatus,
  });

  const [formError, setFormError] = useState<string | null>(null);

  const loadEmployees = async () => {
    try {
      setLoading(true);
      const data = await api.getEmployees({
        status: filterStatus,
        nationality: filterNationality,
        search,
      });
      setEmployees(data);
    } catch (err: any) {
      console.error('Error loading employees:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEmployees();
  }, [filterNationality, filterStatus, search]);

  const handleOpenAddModal = () => {
    setEditingEmployee(null);
    const nextCode = `EMP-${100 + employees.length + 1}`;
    setFormData({
      employee_id: nextCode,
      full_name: '',
      phone_number: '+966',
      email: '',
      nationality: 'Saudi',
      iqama_number: '',
      iqama_expiry: '',
      passport_number: '',
      job_title: '',
      hire_date: new Date().toISOString().split('T')[0],
      basic_salary: 5000,
      allowances: 1000,
      insurance: 300,
      iban: 'SA',
      pin_code: '',
      status: 'active',
    });
    setFormError(null);
    setShowModal(true);
  };

  const handleOpenEditModal = (emp: Employee) => {
    setEditingEmployee(emp);
    setFormData({
      employee_id: emp.employee_id,
      full_name: emp.full_name,
      phone_number: emp.phone_number || '',
      email: emp.email || '',
      nationality: emp.nationality,
      iqama_number: emp.iqama_number,
      iqama_expiry: emp.iqama_expiry,
      passport_number: emp.passport_number,
      job_title: emp.job_title,
      hire_date: emp.hire_date,
      basic_salary: emp.basic_salary,
      allowances: emp.allowances,
      insurance: emp.insurance,
      iban: emp.iban,
      pin_code: emp.pin_code || '',
      status: emp.status,
    });
    setFormError(null);
    setShowModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    try {
      if (editingEmployee) {
        await api.updateEmployee(editingEmployee.id, formData);
      } else {
        await api.createEmployee(formData);
      }
      setShowModal(false);
      loadEmployees();
    } catch (err: any) {
      setFormError(err.message || 'Error saving employee record.');
    }
  };

  const handleDelete = async (emp: Employee) => {
    if (confirm(`Are you sure you want to delete employee "${emp.full_name}"?`)) {
      try {
        await api.deleteEmployee(emp.id);
        loadEmployees();
      } catch (err: any) {
        alert(err.message || 'Error deleting employee.');
      }
    }
  };

  // Helper: Is Iqama expiring within 30 days?
  const isIqamaExpiringSoon = (expiryDateStr: string) => {
    if (!expiryDateStr) return false;
    const exp = new Date(expiryDateStr);
    const today = new Date();
    const diffDays = (exp.getTime() - today.getTime()) / (1000 * 3600 * 24);
    return diffDays >= 0 && diffDays <= 30;
  };

  return (
    <div id="employee-management" className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2 italic serif">
            <Users className="w-6 h-6 text-sky-400" />
            Employee Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Maintain employee records, salaries, Iqama expiry, insurance, and IBAN accounts.
          </p>
        </div>

        <button
          id="btn-add-employee"
          onClick={handleOpenAddModal}
          className="px-4 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-lg text-xs transition shadow-lg shadow-sky-500/20 flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add Employee</span>
        </button>
      </div>

      {/* Filters & Search Bar */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl p-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            id="input-employee-search"
            type="text"
            placeholder="Search name, ID, Iqama or title..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-sky-400"
          />
        </div>

        {/* Filter Dropdowns */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div>
            <select
              value={filterNationality}
              onChange={(e) => setFilterNationality(e.target.value)}
              className="py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none focus:border-sky-400"
            >
              <option value="all">All Nationalities</option>
              <option value="Saudi">Saudi Nationals</option>
              <option value="Expat">Expat Staff</option>
            </select>
          </div>

          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none focus:border-sky-400"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active Only</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>

      </div>

      {/* Employees Table */}
      <div className="bg-[#1e293b] border border-slate-700 rounded-xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-900/80 text-[10px] uppercase tracking-widest text-slate-400 font-bold border-b border-slate-700">
              <tr>
                <th className="py-3.5 px-4">Code / Name</th>
                <th className="py-3.5 px-4">Nationality</th>
                <th className="py-3.5 px-4">Iqama / Expiry</th>
                <th className="py-3.5 px-4">Job Title</th>
                <th className="py-3.5 px-4 text-right">Basic (SAR)</th>
                <th className="py-3.5 px-4 text-right">Allowances</th>
                <th className="py-3.5 px-4">Insurance</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/60">
              {loading ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500">
                    Loading employees...
                  </td>
                </tr>
              ) : employees.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500">
                    No employees found.
                  </td>
                </tr>
              ) : (
                employees.map((emp) => {
                  const expiring = isIqamaExpiringSoon(emp.iqama_expiry);
                  return (
                    <tr key={emp.id} className="hover:bg-slate-800/50 transition">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-100">{emp.full_name}</div>
                        <div className="font-mono text-sky-400 text-[11px]">{emp.employee_id}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2 py-0.5 rounded font-bold text-[10px] uppercase ${
                            emp.nationality === 'Saudi'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : 'bg-sky-500/10 text-sky-400 border border-sky-500/30'
                          }`}
                        >
                          {emp.nationality}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-mono">{emp.iqama_number}</div>
                        {emp.iqama_expiry && (
                          <div className={`text-[11px] flex items-center gap-1 mt-0.5 ${expiring ? 'text-amber-400 font-bold animate-pulse' : 'text-slate-400'}`}>
                            {expiring && <AlertTriangle className="w-3 h-3 text-amber-400" />}
                            <span>Exp: {emp.iqama_expiry}</span>
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">{emp.job_title}</td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-100">
                        {emp.basic_salary.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-slate-300">
                        {emp.allowances.toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-slate-400">
                        {emp.insurance > 0 ? `${emp.insurance} SAR` : 'None'}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            emp.status === 'active'
                              ? 'bg-emerald-500/10 text-emerald-400'
                              : 'bg-slate-800 text-slate-500'
                          }`}
                        >
                          {emp.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center space-x-2">
                          <button
                            onClick={() => handleOpenEditModal(emp)}
                            className="p-1.5 text-slate-400 hover:text-sky-400 hover:bg-slate-800 rounded transition"
                            title="Edit Employee"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(emp)}
                            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded transition"
                            title="Delete Employee"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ADD / EDIT EMPLOYEE MODAL */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#1e293b] border border-slate-700 rounded-xl w-full max-w-2xl p-6 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700 mb-4">
              <h3 className="font-bold text-lg text-slate-100 flex items-center gap-2 italic serif">
                <Users className="w-5 h-5 text-sky-400" />
                {editingEmployee ? 'Edit Employee Record' : 'Add New Employee'}
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 p-3 rounded-lg bg-red-950/80 border border-red-800 text-red-200 text-xs">
                {formError}
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Employee ID *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.employee_id}
                    onChange={(e) => setFormData({ ...formData, employee_id: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Fahad Al-Otaibi"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    WhatsApp Phone Number (+966)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. +966501234567"
                    value={formData.phone_number}
                    onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    placeholder="e.g. employee@dunya.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Nationality *
                  </label>
                  <select
                    value={formData.nationality}
                    onChange={(e) => setFormData({ ...formData, nationality: e.target.value as NationalityType })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  >
                    <option value="Saudi">Saudi National</option>
                    <option value="Expat">Expat</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Job Title *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sales Specialist"
                    value={formData.job_title}
                    onChange={(e) => setFormData({ ...formData, job_title: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Iqama / National ID *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.iqama_number}
                    onChange={(e) => setFormData({ ...formData, iqama_number: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Iqama Expiry Date
                  </label>
                  <input
                    type="date"
                    value={formData.iqama_expiry}
                    onChange={(e) => setFormData({ ...formData, iqama_expiry: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Passport Number
                  </label>
                  <input
                    type="text"
                    value={formData.passport_number}
                    onChange={(e) => setFormData({ ...formData, passport_number: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Hire Date
                  </label>
                  <input
                    type="date"
                    value={formData.hire_date}
                    onChange={(e) => setFormData({ ...formData, hire_date: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Basic Salary (SAR) *
                  </label>
                  <input
                    type="number"
                    required
                    value={formData.basic_salary}
                    onChange={(e) => setFormData({ ...formData, basic_salary: Number(e.target.value) })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Monthly Allowances (SAR)
                  </label>
                  <input
                    type="number"
                    value={formData.allowances}
                    onChange={(e) => setFormData({ ...formData, allowances: Number(e.target.value) })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Insurance Monthly Deduction (SAR)
                  </label>
                  <input
                    type="number"
                    value={formData.insurance}
                    onChange={(e) => setFormData({ ...formData, insurance: Number(e.target.value) })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as EmployeeStatus })}
                    className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 text-sm focus:outline-none focus:border-sky-400"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Bank IBAN
                </label>
                <input
                  type="text"
                  placeholder="e.g. SA0000000000000000000000"
                  value={formData.iban}
                  onChange={(e) => setFormData({ ...formData, iban: e.target.value })}
                  className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-amber-300 mb-1 flex items-center justify-between">
                  <span>Custom Security PIN (Paystub Vault Access)</span>
                  <span className="text-[10px] text-slate-400 font-normal">Default: Last 4 digits of Iqama</span>
                </label>
                <input
                  type="password"
                  maxLength={6}
                  placeholder="e.g. 1234 (Optional custom 4-digit PIN)"
                  value={formData.pin_code}
                  onChange={(e) => setFormData({ ...formData, pin_code: e.target.value })}
                  className="w-full py-2 px-3 bg-slate-900 border border-amber-500/30 rounded-lg text-amber-200 font-mono text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="pt-4 flex items-center justify-end space-x-3 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg text-xs font-bold shadow-lg shadow-sky-500/20"
                >
                  Save Employee
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
