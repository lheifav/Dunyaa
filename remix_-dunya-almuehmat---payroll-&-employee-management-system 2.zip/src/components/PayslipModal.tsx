import React from 'react';
import { Building2, X, Printer, Download, MessageCircle, Mail } from 'lucide-react';
import { PayrollRecord } from '../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { getWhatsAppUrl, getEmailUrl, notificationTemplates } from '../lib/notifications';

interface PayslipModalProps {
  record: PayrollRecord;
  onClose: () => void;
}

export const PayslipModal: React.FC<PayslipModalProps> = ({ record, onClose }) => {
  const notifTpl = notificationTemplates.paystub(record);
  const waUrl = getWhatsAppUrl(record.phone_number, notifTpl.text);
  const mailUrl = getEmailUrl(record.email, notifTpl.subject, notifTpl.text);

  const handlePrint = () => {
    try {
      const iframe = document.createElement('iframe');
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';

      document.body.appendChild(iframe);

      const printableHtml = `
        <!DOCTYPE html>
        <html>
          <head>
            <title>Payslip - ${record.employee_name} (${record.period_start})</title>
            <style>
              @page { size: auto; margin: 15mm; }
              body { font-family: system-ui, -apple-system, sans-serif; color: #0f172a; background: #ffffff; margin: 0; padding: 20px; font-size: 12px; }
              .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0284c7; padding-bottom: 12px; margin-bottom: 16px; }
              .company-title { font-size: 18px; font-weight: 800; color: #0284c7; margin: 0; }
              .company-subtitle { font-size: 12px; color: #64748b; margin-top: 2px; }
              .meta-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; background: #f8fafc; padding: 12px; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 16px; }
              .meta-item label { display: block; font-size: 10px; color: #64748b; text-transform: uppercase; font-weight: bold; }
              .meta-item strong { font-size: 12px; color: #0f172a; }
              .attn-strip { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; background: #f1f5f9; padding: 8px; border-radius: 6px; text-align: center; margin-bottom: 16px; font-size: 11px; }
              .cols { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
              .col { border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; }
              .col-title { font-weight: bold; font-size: 11px; text-transform: uppercase; padding-bottom: 6px; border-bottom: 1px solid #e2e8f0; margin-bottom: 8px; }
              .earnings-title { color: #0284c7; }
              .deductions-title { color: #dc2626; }
              .row { display: flex; justify-content: space-between; padding: 4px 0; border-bottom: 1px dashed #f1f5f9; }
              .total-row { font-weight: bold; border-top: 2px solid #e2e8f0; border-bottom: none; margin-top: 6px; padding-top: 6px; }
              .net-box { background: #f0f9ff; border: 2px solid #0284c7; border-radius: 8px; text-align: center; padding: 16px; margin-bottom: 20px; }
              .net-amount { font-size: 24px; font-weight: 900; color: #0369a1; }
              .footer { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 30px; font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 12px; }
              .sig-line { border-top: 1px solid #94a3b8; width: 220px; text-align: center; padding-top: 4px; font-style: italic; }
            </style>
          </head>
          <body>
            <div class="header">
              <div>
                <h1 class="company-title">Dunya AlMuehmat for Office Equipments</h1>
                <div class="company-subtitle">Official Monthly Salary Payslip · دنيا المهمات لمعدات المكاتب</div>
              </div>
              <div style="text-align: right; font-size: 11px; color: #64748b;">
                <div><strong>PAYSLIP #${record.id}</strong></div>
                <div>Issued: ${record.generated_date}</div>
              </div>
            </div>

            <div class="meta-grid">
              <div class="meta-item"><label>Employee Name</label><strong>${record.employee_name}</strong></div>
              <div class="meta-item"><label>Employee ID</label><strong>${record.employee_code}</strong></div>
              <div class="meta-item"><label>Job Title</label><strong>${record.job_title}</strong></div>
              <div class="meta-item"><label>Period</label><strong>${record.period_start} to ${record.period_end}</strong></div>
            </div>

            <div class="attn-strip">
              <div>Present: <strong>${record.present_days ?? 'N/A'} days</strong></div>
              <div>Unpaid Leave: <strong>${record.unpaid_leave_days ?? 0} days</strong></div>
              <div>Unexcused Absences: <strong>${record.absent_days ?? 0} days</strong></div>
            </div>

            <div class="cols">
              <div class="col">
                <div class="col-title earnings-title">1. Earnings (SAR)</div>
                <div class="row"><span>Basic Salary</span><strong>${record.basic_salary.toLocaleString()} SAR</strong></div>
                <div class="row"><span>Allowances</span><strong>${record.allowances.toLocaleString()} SAR</strong></div>
                ${record.overtime_pay ? `<div class="row"><span>Overtime Pay (${record.overtime_hours || 0} hrs)</span><strong>+${record.overtime_pay.toLocaleString()} SAR</strong></div>` : ''}
                ${record.bonus_pay ? `<div class="row"><span>Itemized Bonuses</span><strong>+${record.bonus_pay.toLocaleString()} SAR</strong></div>` : ''}
                <div class="row total-row" style="color: #0284c7;">
                  <span>Gross Earnings</span>
                  <span>${(record.basic_salary + record.allowances + (record.overtime_pay || 0) + (record.bonus_pay || 0)).toLocaleString()} SAR</span>
                </div>
              </div>

              <div class="col">
                <div class="col-title deductions-title">2. Deductions (SAR)</div>
                <div class="row"><span>Insurance Deduction</span><span>-${record.insurance_deduction.toLocaleString()} SAR</span></div>
                <div class="row"><span>Cash Advance Repayment</span><span>-${record.cash_advance_deduction.toLocaleString()} SAR</span></div>
                <div class="row"><span>Unpaid Leave / Absences</span><span>-${record.deductions.toLocaleString()} SAR</span></div>
                <div class="row total-row" style="color: #dc2626;">
                  <span>Total Deductions</span>
                  <span>-${(record.insurance_deduction + record.cash_advance_deduction + record.deductions).toLocaleString()} SAR</span>
                </div>
              </div>
            </div>

            <div class="net-box">
              <div style="font-size: 11px; font-weight: bold; color: #0284c7; text-transform: uppercase;">NET PAYABLE SALARY</div>
              <div class="net-amount">${record.net_salary.toLocaleString()} SAR</div>
              <div style="font-size: 11px; margin-top: 4px; color: #475569;">Bank IBAN: ${record.iban || 'N/A'}</div>
            </div>

            <div class="footer">
              <div>
                <div>Dunya AlMuehmat for Office Equipments Management</div>
                <div style="direction: rtl;">إدارة شركة دنيا المهمات لمعدات المكاتب</div>
              </div>
              <div class="sig-line">Authorized Signature & Stamp</div>
            </div>
          </body>
        </html>
      `;

      const doc = iframe.contentWindow?.document || iframe.contentDocument;
      if (doc) {
        doc.open();
        doc.write(printableHtml);
        doc.close();

        setTimeout(() => {
          try {
            iframe.contentWindow?.focus();
            iframe.contentWindow?.print();
          } catch {
            window.print();
          }
          setTimeout(() => {
            if (document.body.contains(iframe)) {
              document.body.removeChild(iframe);
            }
          }, 1000);
        }, 300);
      } else {
        window.print();
      }
    } catch {
      window.print();
    }
  };

  const handleExportPdf = () => {
    const doc = new jsPDF();

    // Company Header
    doc.setFontSize(16);
    doc.text('Dunya AlMuehmat for Office Equipments', 14, 20);
    doc.setFontSize(10);
    doc.text('Official Monthly Salary Payslip (SAR)', 14, 26);
    doc.text(`Generated Date: ${record.generated_date}`, 14, 32);

    doc.line(14, 36, 196, 36);

    // Employee & Attendance Info Table
    autoTable(doc, {
      startY: 40,
      head: [['Employee Information', 'Details']],
      body: [
        ['Employee Name', record.employee_name || 'N/A'],
        ['Employee Code', record.employee_code || 'N/A'],
        ['Job Title', record.job_title || 'N/A'],
        ['Bank IBAN', record.iban || 'N/A'],
        ['Payroll Period', `${record.period_start} to ${record.period_end}`],
        ['Attendance Summary', `Present: ${record.present_days ?? 'N/A'} days | Absent: ${record.absent_days ?? 0} days | Unpaid: ${record.unpaid_leave_days ?? 0} days`],
      ],
      theme: 'grid',
      headStyles: { fillColor: [14, 165, 233] },
    });

    // Salary Itemized Breakdown Table
    const earningsRows: any[] = [
      ['Basic Salary', 'Earning', `${record.basic_salary.toLocaleString()} SAR`],
      ['Monthly Allowances', 'Earning', `${record.allowances.toLocaleString()} SAR`],
    ];

    if (record.overtime_pay) {
      earningsRows.push([`Overtime Pay (${record.overtime_hours || 0} hrs)`, 'Earning', `+${record.overtime_pay.toLocaleString()} SAR`]);
    }
    if (record.bonus_pay) {
      earningsRows.push(['Performance / Special Bonuses', 'Earning', `+${record.bonus_pay.toLocaleString()} SAR`]);
    }

    earningsRows.push(
      ['Insurance Deduction', 'Deduction', `-${record.insurance_deduction.toLocaleString()} SAR`],
      ['Cash Advance Repayment', 'Deduction', `-${record.cash_advance_deduction.toLocaleString()} SAR`],
      ['Attendance / Unpaid Leave Deduction', 'Deduction', `-${record.deductions.toLocaleString()} SAR`],
      ['NET PAYABLE SALARY', 'TOTAL', `${record.net_salary.toLocaleString()} SAR`]
    );

    const finalY = (doc as any).lastAutoTable.finalY + 10;
    autoTable(doc, {
      startY: finalY,
      head: [['Item Description', 'Type', 'Amount (SAR)']],
      body: earningsRows,
      theme: 'striped',
      headStyles: { fillColor: [15, 23, 42] },
    });

    // Footer signature notice
    const footerY = (doc as any).lastAutoTable.finalY + 20;
    doc.setFontSize(9);
    doc.text('Authorized Signature & Stamp: _______________________', 14, footerY);
    doc.text('Employee Signature: _______________________', 120, footerY);
    doc.text('Dunya AlMuehmat for Office Equipments - Confidential HR Record', 14, footerY + 10);

    doc.save(`Payslip_${record.employee_code}_${record.period_start}.pdf`);
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-[#1e293b] border border-slate-700 rounded-2xl w-full max-w-3xl p-4 sm:p-6 shadow-2xl my-auto print:p-0 print:border-0 print:bg-white print:text-black">
        
        {/* Modal Controls Top Bar (Hidden when printing) */}
        <div className="flex flex-wrap items-center justify-between pb-4 border-b border-slate-700 mb-6 gap-3 print:hidden">
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-sky-400" />
            <span className="font-bold text-slate-100 text-sm italic serif">Official Salary Payslip</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <a
              href={waUrl}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 rounded-lg text-xs font-bold flex items-center gap-1.5 border border-emerald-500/30 transition active:scale-95"
              title="Send Paystub to Employee via WhatsApp"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp</span>
            </a>

            <a
              href={mailUrl}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 bg-sky-500/20 hover:bg-sky-500 text-sky-300 hover:text-slate-950 rounded-lg text-xs font-bold flex items-center gap-1.5 border border-sky-500/30 transition active:scale-95"
              title="Send Paystub to Employee via Email"
            >
              <Mail className="w-4 h-4" />
              <span>Email</span>
            </a>

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition active:scale-95"
            >
              <Printer className="w-4 h-4 text-sky-400" />
              <span>Print</span>
            </button>

            <button
              onClick={handleExportPdf}
              className="px-3.5 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow transition active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </button>

            <button 
              onClick={onClose} 
              className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white border border-red-500/30 rounded-lg text-xs font-bold flex items-center gap-1.5 transition active:scale-95 ml-2"
              title="Close Paystub Modal"
            >
              <X className="w-4 h-4" />
              <span>Close</span>
            </button>
          </div>
        </div>

        {/* PRINTABLE PAYSLIP CARD */}
        <div id="printable-payslip" className="bg-slate-900 border border-slate-700 rounded-xl p-6 print:bg-white print:text-slate-900 print:border-none print:shadow-none">
          
          {/* Header Branding */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-700 pb-4 mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-xl bg-sky-500 text-white flex items-center justify-center font-bold text-xl shadow">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <h2 className="font-extrabold text-lg text-slate-100 tracking-tight italic serif">
                  Dunya AlMuehmat for Office Equipments
                </h2>
                <p className="text-xs text-slate-400 font-arabic">
                  دنيا المهمات لمعدات المكاتب · قسيمة الراتب الشهرية
                </p>
              </div>
            </div>
            <div className="mt-3 sm:mt-0 text-left sm:text-right font-mono text-xs text-slate-400">
              <div>PAYSLIP #{record.id}</div>
              <div>Issued: {record.generated_date}</div>
            </div>
          </div>

          {/* Employee Meta Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-900/80 p-4 rounded-lg border border-slate-700 text-xs mb-4">
            <div>
              <span className="text-slate-400 block text-[11px]">Employee Name</span>
              <strong className="text-slate-100 font-semibold">{record.employee_name}</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Employee ID</span>
              <strong className="text-sky-400 font-mono">{record.employee_code}</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Job Title</span>
              <strong className="text-slate-200">{record.job_title}</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Payroll Period</span>
              <strong className="text-slate-200 font-mono">{record.period_start} - {record.period_end}</strong>
            </div>
          </div>

          {/* Attendance Breakdown Strip */}
          <div className="grid grid-cols-3 gap-2 bg-slate-800/60 p-3 rounded-lg border border-slate-700/80 text-xs mb-6 text-center">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Present Days</span>
              <span className="text-emerald-400 font-mono font-bold">{record.present_days ?? 'N/A'} days</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Unpaid Leave</span>
              <span className="text-amber-400 font-mono font-bold">{record.unpaid_leave_days ?? 0} days</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Unexcused Absences</span>
              <span className="text-red-400 font-mono font-bold">{record.absent_days ?? 0} days</span>
            </div>
          </div>

          {/* Earnings & Deductions Tables */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs mb-6">
            
            {/* Earnings Column */}
            <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-700">
              <h4 className="font-bold text-sky-400 text-[10px] uppercase tracking-widest mb-3 pb-2 border-b border-slate-700">
                1. Earnings (SAR)
              </h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center py-1">
                  <span className="text-slate-300">Basic Salary</span>
                  <span className="font-mono font-bold text-slate-100">{record.basic_salary.toLocaleString()} SAR</span>
                </div>
                <div className="flex justify-between items-center py-1 border-t border-slate-800">
                  <span className="text-slate-300">Allowances</span>
                  <span className="font-mono text-slate-100">{record.allowances.toLocaleString()} SAR</span>
                </div>

                {Boolean(record.overtime_pay) && (
                  <div className="flex justify-between items-center py-1 border-t border-slate-800 text-sky-300">
                    <span>Overtime Pay ({record.overtime_hours || 0} hrs)</span>
                    <span className="font-mono font-bold">+{record.overtime_pay?.toLocaleString()} SAR</span>
                  </div>
                )}

                {Boolean(record.bonus_pay) && (
                  <div className="flex justify-between items-center py-1 border-t border-slate-800 text-emerald-300">
                    <span>Itemized Bonuses</span>
                    <span className="font-mono font-bold">+{record.bonus_pay?.toLocaleString()} SAR</span>
                  </div>
                )}

                <div className="flex justify-between items-center pt-2 border-t border-slate-700 font-bold text-sky-400">
                  <span>Gross Earnings</span>
                  <span className="font-mono">
                    {(record.basic_salary + record.allowances + (record.overtime_pay || 0) + (record.bonus_pay || 0)).toLocaleString()} SAR
                  </span>
                </div>
              </div>
            </div>

            {/* Deductions Column */}
            <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-700">
              <h4 className="font-bold text-red-400 text-[10px] uppercase tracking-widest mb-3 pb-2 border-b border-slate-700">
                2. Deductions (SAR)
              </h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center py-1">
                  <span className="text-slate-300">Insurance Deduction</span>
                  <span className="font-mono text-slate-300">-{record.insurance_deduction.toLocaleString()} SAR</span>
                </div>
                <div className="flex justify-between items-center py-1 border-t border-slate-800">
                  <span className="text-slate-300">Cash Advance Repayment</span>
                  <span className="font-mono text-slate-300">-{record.cash_advance_deduction.toLocaleString()} SAR</span>
                </div>
                <div className="flex justify-between items-center py-1 border-t border-slate-800">
                  <span className="text-slate-300">Unpaid Leave / Absences</span>
                  <span className="font-mono text-slate-300">-{record.deductions.toLocaleString()} SAR</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-slate-700 font-bold text-red-400">
                  <span>Total Deductions</span>
                  <span className="font-mono">
                    -{(record.insurance_deduction + record.cash_advance_deduction + record.deductions).toLocaleString()} SAR
                  </span>
                </div>
              </div>
            </div>

          </div>

          {/* NET SALARY HIGHLIGHT BOX */}
          <div className="bg-slate-900 border border-sky-400/50 rounded-xl p-5 text-center shadow-xl">
            <span className="text-[10px] uppercase tracking-widest font-bold text-sky-400">
              NET PAYABLE SALARY
            </span>
            <div className="text-3xl font-black text-white mt-1 font-mono tracking-tight">
              {record.net_salary.toLocaleString()} <span className="text-lg text-sky-400 font-sans">SAR</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 font-mono">
              Bank IBAN: {record.iban || 'N/A'}
            </div>
          </div>

          {/* Authorization Footer */}
          <div className="mt-8 pt-4 border-t border-slate-700 flex justify-between items-end text-[11px] text-slate-500">
            <div>
              <p>Dunya AlMuehmat for Office Equipments Management</p>
              <p className="font-arabic mt-0.5">إدارة شركة دنيا المهمات لمعدات المكاتب</p>
            </div>
            <div className="text-center font-serif italic text-slate-400 border-b border-slate-700 pb-1 px-4">
              Authorized Signature & Stamp
            </div>
          </div>

        </div>

        {/* Modal Controls Bottom Footer Bar (Hidden when printing) */}
        <div className="mt-6 pt-4 border-t border-slate-700 flex flex-wrap items-center justify-between gap-3 print:hidden">
          <p className="text-xs text-slate-400">
            Dunya AlMuehmat Official HR Record
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-2 border border-slate-700 transition active:scale-95"
            >
              <Printer className="w-4 h-4 text-sky-400" />
              <span>Print Paystub</span>
            </button>

            <button
              onClick={handleExportPdf}
              className="px-4 py-2 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-2 shadow transition active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition active:scale-95"
            >
              <X className="w-4 h-4 text-red-400" />
              <span>Close Paystub</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
