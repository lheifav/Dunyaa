import React from 'react';
import {
  LayoutDashboard,
  Users,
  Clock,
  Banknote,
  HandCoins,
  CalendarDays,
  Settings,
  Award,
  BarChart3,
} from 'lucide-react';

export type ActiveTab =
  | 'dashboard'
  | 'employees'
  | 'attendance'
  | 'payroll'
  | 'overtime-bonuses'
  | 'advances'
  | 'leaves'
  | 'reports'
  | 'settings';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  pendingLeavesCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  pendingLeavesCount = 0,
}) => {
  const menuItems = [
    { id: 'dashboard' as ActiveTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'employees' as ActiveTab, label: 'Employees', icon: Users },
    { id: 'attendance' as ActiveTab, label: 'Attendance', icon: Clock },
    { id: 'payroll' as ActiveTab, label: 'Payroll Processing', icon: Banknote },
    { id: 'overtime-bonuses' as ActiveTab, label: 'Overtime & Bonuses', icon: Award },
    { id: 'advances' as ActiveTab, label: 'Cash Advances', icon: HandCoins },
    {
      id: 'leaves' as ActiveTab,
      label: 'Leave Requests',
      icon: CalendarDays,
      badge: pendingLeavesCount > 0 ? pendingLeavesCount : undefined,
    },
    { id: 'reports' as ActiveTab, label: 'Reports & Analytics', icon: BarChart3 },
    { id: 'settings' as ActiveTab, label: 'Settings', icon: Settings },
  ];

  return (
    <aside id="admin-sidebar" className="w-full lg:w-64 bg-[#1e293b] text-slate-300 border-b lg:border-b-0 lg:border-r border-slate-700 flex-shrink-0 lg:min-h-[calc(100vh-4rem)]">
      <div className="p-3 lg:p-4">
        <div className="hidden lg:block px-3 pt-2 pb-3 border-b border-slate-700/80 mb-3">
          <h2 className="text-sky-400 font-bold text-sm leading-tight uppercase tracking-wider">
            Dunya AlMuehmat
          </h2>
          <p className="text-[10px] text-slate-400 font-medium uppercase mt-0.5">Payroll & HR System</p>
        </div>

        <div className="hidden lg:block px-3 mb-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
          Main Menu
        </div>

        {/* Touch-Friendly Navigation: Horizontal Scroll on Mobile/iPad Portrait, Vertical List on Desktop */}
        <nav className="flex lg:flex-col overflow-x-auto touch-pan-x gap-1.5 pb-1 lg:pb-0 scrollbar-none">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => onSelectTab(item.id)}
                className={`flex-shrink-0 flex items-center justify-between px-4 py-3 lg:py-2.5 min-h-[46px] rounded-xl lg:rounded-lg text-xs lg:text-sm transition-all duration-150 active:scale-95 ${
                  isActive
                    ? 'bg-sky-500 text-white font-bold shadow-lg shadow-sky-500/20 lg:bg-sky-500/10 lg:text-sky-400 lg:border-r-2 lg:border-sky-400 lg:shadow-none'
                    : 'bg-slate-800/80 lg:bg-transparent text-slate-300 lg:text-slate-400 hover:text-slate-100 lg:hover:bg-slate-800 border border-slate-700/60 lg:border-0'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white lg:text-sky-400' : 'text-slate-400'}`} />
                  <span className="whitespace-nowrap">{item.label}</span>
                </div>
                {item.badge && (
                  <span className="ml-2 bg-amber-400 text-slate-950 font-bold text-[10px] px-2 py-0.5 rounded-full shadow-sm">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </aside>
  );
};
