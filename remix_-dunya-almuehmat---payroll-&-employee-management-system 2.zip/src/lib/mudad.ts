import { PayrollRecord, Employee } from '../types';

/**
 * Saudi Arabia Wage Protection System (WPS) - SIF File Generator
 * SIF (Salary Information File) is standard across Saudi banks (NCB, Al Rajhi, Riyad Bank, etc.) and Mudad.
 */
export interface SifCompanyHeader {
  establishmentId: string; // MOL ID / Commercial Registration (CR)
  bankCode: string; // e.g. "RIBL" (Riyad Bank), "RJHI" (Al Rajhi), "NCBK" (SNB)
  payoutYearMonth: string; // YYYY-MM
  paymentDate?: string; // YYYY-MM-DD
}

export function generateSifFileContent(
  payrollRecords: PayrollRecord[],
  headerInfo: SifCompanyHeader
): string {
  const lines: string[] = [];
  const estId = headerInfo.establishmentId || '7001234567';
  const bankCode = headerInfo.bankCode || 'RJHI';
  const payoutDate = headerInfo.paymentDate || new Date().toISOString().split('T')[0];
  const payoutMonth = headerInfo.payoutYearMonth || payoutDate.substring(0, 7);
  const nowTime = new Date().toTimeString().split(' ')[0].substring(0, 5); // HH:MM

  // Compute totals
  const totalNetSalary = payrollRecords.reduce((sum, r) => sum + r.net_salary, 0);
  const recordCount = payrollRecords.length;

  // Header Record (Type 1)
  // Format: 1,P,EST_ID,BANK_CODE,PAYMENT_DATE,PAYMENT_TIME,PAYOUT_MONTH,TOTAL_NET,RECORD_COUNT,CURRENCY
  lines.push(
    `1,P,${estId},${bankCode},${payoutDate},${nowTime},${payoutMonth},${totalNetSalary.toFixed(
      2
    )},${recordCount},SAR`
  );

  // Detail Records (Type 2)
  payrollRecords.forEach((rec, idx) => {
    const iqamaOrId = rec.employee_code || `EMP-${rec.employee_id}`;
    const iban = rec.iban || 'SA0000000000000000000000';
    const basic = (rec.basic_salary || 0).toFixed(2);
    const housing = Math.round((rec.allowances || 0) * 0.4 * 100) / 100; // estimated housing
    const otherAllowances = Math.round(((rec.allowances || 0) * 0.6 + (rec.overtime_pay || 0) + (rec.bonus_pay || 0)) * 100) / 100;
    const deductions = ((rec.insurance_deduction || 0) + (rec.cash_advance_deduction || 0) + (rec.deductions || 0)).toFixed(2);
    const net = (rec.net_salary || 0).toFixed(2);

    // Format: 2,SEQ_NUM,EMP_ID,EMP_IBAN,BASIC_SALARY,HOUSING_ALLOWANCE,OTHER_ALLOWANCE,DEDUCTIONS,NET_SALARY,PAYMENT_TYPE,STATUS
    lines.push(
      `2,${idx + 1},${iqamaOrId},${iban},${basic},${housing.toFixed(
        2
      )},${otherAllowances.toFixed(2)},${deductions},${net},SAL,PAID`
    );
  });

  return lines.join('\r\n');
}

/**
 * Generate Mudad Compliance CSV Export
 */
export function generateMudadCsvContent(
  payrollRecords: PayrollRecord[],
  headerInfo: SifCompanyHeader
): string {
  const headers = [
    'Sequence',
    'Employee Name',
    'Iqama/ID Number',
    'IBAN Account',
    'Job Title',
    'Period Start',
    'Period End',
    'Basic Salary (SAR)',
    'Allowances (SAR)',
    'Overtime & Bonuses (SAR)',
    'Total Deductions (SAR)',
    'Net Payable (SAR)',
    'Mudad WPS Status',
  ];

  const rows = payrollRecords.map((r, idx) => {
    const otAndBonus = (r.overtime_pay || 0) + (r.bonus_pay || 0);
    const deductions = r.insurance_deduction + r.cash_advance_deduction + r.deductions;
    return [
      idx + 1,
      `"${r.employee_name || 'N/A'}"`,
      `"${r.employee_code || 'N/A'}"`,
      `"${r.iban || 'N/A'}"`,
      `"${r.job_title || 'N/A'}"`,
      r.period_start,
      r.period_end,
      r.basic_salary.toFixed(2),
      r.allowances.toFixed(2),
      otAndBonus.toFixed(2),
      deductions.toFixed(2),
      r.net_salary.toFixed(2),
      'READY_FOR_MUDAD_DISPATCH',
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

/**
 * Trigger browser file download for generated text/csv
 */
export function downloadFile(filename: string, content: string, mimeType = 'text/plain') {
  const blob = new Blob([content], { type: `${mimeType};charset=utf-8;` });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
