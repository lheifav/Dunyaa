import {
  Employee,
  AttendanceRecord,
  PayrollRecord,
  CashAdvance,
  LeaveRequest,
  DashboardStats,
  OvertimeRule,
  EmployeeBonus,
} from '../types';

async function fetchJson<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `HTTP error ${res.status}`);
  }
  return res.json();
}

export const api = {
  // Auth
  getAdminCount: () =>
    fetchJson<{ count: number; maxAllowed: number; canRegister: boolean }>('/api/auth/admin-count'),

  register: (username: string, password: string) =>
    fetchJson<{ success: boolean; message: string; user: { id: number; username: string } }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),

  login: (username: string, password: string) =>
    fetchJson<{ success: boolean; user: { id: number; username: string } }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),

  changePassword: (data: any) =>
    fetchJson<{ success: boolean; message: string }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getAdmins: () =>
    fetchJson<Array<{ id: number; username: string; created_at?: string }>>('/api/auth/admins'),

  deleteAdmin: (id: number) =>
    fetchJson<{ success: boolean; message: string }>(`/api/auth/admins/${id}`, {
      method: 'DELETE',
    }),

  // Employees
  getEmployees: (params?: { status?: string; nationality?: string; search?: string }) => {
    const query = new URLSearchParams();
    if (params?.status) query.append('status', params.status);
    if (params?.nationality) query.append('nationality', params.nationality);
    if (params?.search) query.append('search', params.search);
    return fetchJson<Employee[]>(`/api/employees?${query.toString()}`);
  },

  createEmployee: (data: Partial<Employee>) =>
    fetchJson<Employee>('/api/employees', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateEmployee: (id: number, data: Partial<Employee>) =>
    fetchJson<Employee>(`/api/employees/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteEmployee: (id: number) =>
    fetchJson<{ success: boolean }>(`/api/employees/${id}`, { method: 'DELETE' }),

  verifyEmployeePin: (id: number, pin: string) =>
    fetchJson<{ verified: boolean; error?: string }>(`/api/employees/${id}/verify-pin`, {
      method: 'POST',
      body: JSON.stringify({ pin }),
    }),

  // Attendance
  getAttendance: (params?: { date?: string; employee_id?: number; month?: string }) => {
    const query = new URLSearchParams();
    if (params?.date) query.append('date', params.date);
    if (params?.employee_id) query.append('employee_id', String(params.employee_id));
    if (params?.month) query.append('month', params.month);
    return fetchJson<AttendanceRecord[]>(`/api/attendance?${query.toString()}`);
  },

  kioskPunch: (employee_id: number, action: 'in' | 'out' | 'auto') =>
    fetchJson<{
      success: boolean;
      action: string;
      message: string;
      employee: Employee;
      time: string;
    }>('/api/attendance/punch', {
      method: 'POST',
      body: JSON.stringify({ employee_id, action }),
    }),

  manualAttendance: (data: { employee_id: number; date: string; time_in?: string; time_out?: string }) =>
    fetchJson<{ success: boolean; message: string }>('/api/attendance/manual', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  deleteAttendance: (id: number) =>
    fetchJson<{ success: boolean }>(`/api/attendance/${id}`, { method: 'DELETE' }),

  // Payroll
  getPayrollPeriods: () =>
    fetchJson<{ period_start: string; period_end: string }[]>('/api/payroll/periods'),

  getPayroll: (params?: { period_start?: string; period_end?: string; employee_id?: number }) => {
    const query = new URLSearchParams();
    if (params?.period_start) query.append('period_start', params.period_start);
    if (params?.period_end) query.append('period_end', params.period_end);
    if (params?.employee_id) query.append('employee_id', String(params.employee_id));
    return fetchJson<PayrollRecord[]>(`/api/payroll?${query.toString()}`);
  },

  calculatePayroll: (period_start: string, period_end: string, overtime_data?: Record<number, { hours: number; rule_id?: number }>) =>
    fetchJson<Partial<PayrollRecord>[]>('/api/payroll/calculate', {
      method: 'POST',
      body: JSON.stringify({ period_start, period_end, overtime_data }),
    }),

  generatePayroll: (items: any[], period_start: string, period_end: string) =>
    fetchJson<{ success: boolean; message: string }>('/api/payroll/generate', {
      method: 'POST',
      body: JSON.stringify({ items, period_start, period_end }),
    }),

  deletePayroll: (id: number) =>
    fetchJson<{ success: boolean }>(`/api/payroll/${id}`, { method: 'DELETE' }),

  // Overtime Rules
  getOvertimeRules: () => fetchJson<OvertimeRule[]>('/api/overtime-rules'),

  createOvertimeRule: (data: Partial<OvertimeRule>) =>
    fetchJson<OvertimeRule>('/api/overtime-rules', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateOvertimeRule: (id: number, data: Partial<OvertimeRule>) =>
    fetchJson<OvertimeRule>(`/api/overtime-rules/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteOvertimeRule: (id: number) =>
    fetchJson<{ success: boolean }>(`/api/overtime-rules/${id}`, { method: 'DELETE' }),

  // Employee Bonuses
  getBonuses: (employee_id?: number) => {
    const url = employee_id ? `/api/bonuses?employee_id=${employee_id}` : '/api/bonuses';
    return fetchJson<EmployeeBonus[]>(url);
  },

  createBonus: (data: { employee_id: number; bonus_type: string; amount: number; effective_date?: string; description?: string }) =>
    fetchJson<EmployeeBonus>('/api/bonuses', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  cancelBonus: (id: number) =>
    fetchJson<{ success: boolean }>(`/api/bonuses/${id}/cancel`, { method: 'PUT' }),

  // Cash Advances
  getCashAdvances: () => fetchJson<CashAdvance[]>('/api/cash-advances'),

  createCashAdvance: (data: { employee_id: number; amount: number; monthly_deduction: number }) =>
    fetchJson<CashAdvance>('/api/cash-advances', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateCashAdvance: (id: number, data: { balance: number; monthly_deduction: number; status?: string }) =>
    fetchJson<CashAdvance>(`/api/cash-advances/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteCashAdvance: (id: number) =>
    fetchJson<{ success: boolean }>(`/api/cash-advances/${id}`, { method: 'DELETE' }),

  // Leave Requests
  getLeaveRequests: () => fetchJson<LeaveRequest[]>('/api/leave-requests'),

  createLeaveRequest: (data: {
    employee_id: number;
    leave_type: string;
    start_date: string;
    end_date: string;
    reason?: string;
  }) =>
    fetchJson<LeaveRequest>('/api/leave-requests', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateLeaveStatus: (id: number, status: 'approved' | 'rejected') =>
    fetchJson<LeaveRequest>(`/api/leave-requests/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    }),

  // Dashboard & LAN Info
  getDashboardStats: () => fetchJson<DashboardStats>('/api/dashboard/stats'),

  getLanInfo: () =>
    fetchJson<{
      port: number;
      lanIps: string[];
      companyName: string;
      companyNameArabic: string;
      currency: string;
      version: string;
    }>('/api/settings/lan-info'),

  // Notifications
  getNotifications: (employee_id?: number) => {
    const url = employee_id ? `/api/notifications?employee_id=${employee_id}` : '/api/notifications';
    return fetchJson<import('../types').AppNotification[]>(url);
  },

  markNotificationRead: (id?: number) =>
    fetchJson<{ success: boolean }>('/api/notifications/mark-read', {
      method: 'POST',
      body: JSON.stringify({ id }),
    }),

  // Reports
  getPayrollSummaryReport: (params?: { startDate?: string; endDate?: string; employeeId?: string }) => {
    const q = new URLSearchParams();
    if (params?.startDate) q.append('startDate', params.startDate);
    if (params?.endDate) q.append('endDate', params.endDate);
    if (params?.employeeId) q.append('employeeId', params.employeeId);
    return fetchJson<{ totals: any; records: PayrollRecord[] }>(`/api/reports/payroll-summary?${q.toString()}`);
  },

  getAttendanceLogsReport: (params?: { startDate?: string; endDate?: string; employeeId?: string }) => {
    const q = new URLSearchParams();
    if (params?.startDate) q.append('startDate', params.startDate);
    if (params?.endDate) q.append('endDate', params.endDate);
    if (params?.employeeId) q.append('employeeId', params.employeeId);
    return fetchJson<{ summary: any; records: any[] }>(`/api/reports/attendance-logs?${q.toString()}`);
  },

  getLeaveStatsReport: (params?: { startDate?: string; endDate?: string; employeeId?: string }) => {
    const q = new URLSearchParams();
    if (params?.startDate) q.append('startDate', params.startDate);
    if (params?.endDate) q.append('endDate', params.endDate);
    if (params?.employeeId) q.append('employeeId', params.employeeId);
    return fetchJson<{ summary: any; records: LeaveRequest[] }>(`/api/reports/leave-stats?${q.toString()}`);
  },

  getCashAdvancesReport: (params?: { employeeId?: string }) => {
    const q = new URLSearchParams();
    if (params?.employeeId) q.append('employeeId', params.employeeId);
    return fetchJson<{ totals: any; records: CashAdvance[] }>(`/api/reports/cash-advances?${q.toString()}`);
  },

  // Database Backup
  getBackupDbUrl: () => '/api/admin/backup-db',
  getBackupJsonUrl: () => '/api/admin/backup-json',
};
