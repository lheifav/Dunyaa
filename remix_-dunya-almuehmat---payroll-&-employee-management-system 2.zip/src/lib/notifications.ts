import { Employee, PayrollRecord, LeaveRequest, EmployeeBonus, CashAdvance } from '../types';

/**
 * Formats phone numbers for WhatsApp API URLs.
 * Converts local Saudi format (0501234567) to international format (966501234567).
 */
export function formatWhatsAppPhone(phone?: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/[^0-9]/g, '');
  if (cleaned.startsWith('05')) {
    cleaned = '966' + cleaned.substring(1);
  } else if (cleaned.startsWith('5') && cleaned.length === 9) {
    cleaned = '966' + cleaned;
  }
  return cleaned;
}

/**
 * Generates a direct WhatsApp web URL with pre-filled message text.
 */
export function getWhatsAppUrl(phone?: string, text?: string): string {
  const formattedPhone = formatWhatsAppPhone(phone);
  const encodedText = encodeURIComponent(text || '');
  if (formattedPhone) {
    return `https://wa.me/${formattedPhone}?text=${encodedText}`;
  }
  return `https://wa.me/?text=${encodedText}`;
}

/**
 * Generates a standard mailto: link for email dispatch.
 */
export function getEmailUrl(email?: string, subject?: string, body?: string): string {
  const encSubject = encodeURIComponent(subject || 'Payroll & HR Notification');
  const encBody = encodeURIComponent(body || '');
  if (email) {
    return `mailto:${email}?subject=${encSubject}&body=${encBody}`;
  }
  return `mailto:?subject=${encSubject}&body=${encBody}`;
}

/**
 * Message Templates for WhatsApp & Email
 */
export const notificationTemplates = {
  paystub: (p: PayrollRecord, emp?: Employee) => {
    const name = emp?.full_name || p.employee_name || 'Employee';
    const net = (p.net_salary || 0).toLocaleString();
    const period = `${p.period_start} to ${p.period_end}`;
    
    const text = `Dear ${name},\n\nYour salary statement for period (${period}) from Dunya AlMuehmat for Office Equipments has been generated.\n\n📊 Net Salary: ${net} SAR\n• Basic Salary: ${(p.basic_salary || 0).toLocaleString()} SAR\n• Allowances: ${(p.allowances || 0).toLocaleString()} SAR\n${p.overtime_pay ? `• Overtime Pay (${p.overtime_hours} hrs): ${p.overtime_pay.toLocaleString()} SAR\n` : ''}${p.bonus_pay ? `• Itemized Bonuses: ${p.bonus_pay.toLocaleString()} SAR\n` : ''}• Deductions: ${(p.deductions || 0).toLocaleString()} SAR\n\nThank you for your dedicated service!`;
    const subject = `Paystub Notice (${period}) - Dunya AlMuehmat`;
    return { text, subject };
  },

  leaveApproved: (l: LeaveRequest, emp?: Employee) => {
    const name = emp?.full_name || l.employee_name || 'Employee';
    const text = `Dear ${name},\n\nYour ${l.leave_type} leave request from ${l.start_date} to ${l.end_date} has been APPROVED by HR Admin at Dunya AlMuehmat.\n\nEnjoy your time off!`;
    const subject = `Leave Request Approved (${l.start_date} - ${l.end_date})`;
    return { text, subject };
  },

  leaveRejected: (l: LeaveRequest, emp?: Employee) => {
    const name = emp?.full_name || l.employee_name || 'Employee';
    const text = `Dear ${name},\n\nYour ${l.leave_type} leave request from ${l.start_date} to ${l.end_date} has been updated to REJECTED. Please contact HR for further details.`;
    const subject = `Leave Request Status Update - Dunya AlMuehmat`;
    return { text, subject };
  },

  leaveStatus: (employeeName: string, leaveType: string, status: string, startDate: string, endDate: string) => {
    const text = `Dear ${employeeName},\n\nYour ${leaveType} leave request from ${startDate} to ${endDate} has been marked as ${status.toUpperCase()} by HR Admin at Dunya AlMuehmat.`;
    const subject = `Leave Request ${status.toUpperCase()} - Dunya AlMuehmat`;
    return { text, subject };
  },

  bonusAwarded: (b: EmployeeBonus, emp?: Employee) => {
    const name = emp?.full_name || b.employee_name || 'Employee';
    const amount = (b.amount || 0).toLocaleString();
    const text = `Congratulations ${name}!\n\nYou have been awarded a ${b.bonus_type} of ${amount} SAR at Dunya AlMuehmat.\n\nNote: ${b.description || 'Appreciated for outstanding performance.'}\nThis bonus will be reflected in your upcoming paystub.`;
    const subject = `Bonus Award Notification (${b.bonus_type}) - Dunya AlMuehmat`;
    return { text, subject };
  },

  cashAdvance: (c: CashAdvance, emp?: Employee) => {
    const name = emp?.full_name || c.employee_name || 'Employee';
    const amount = (c.amount || 0).toLocaleString();
    const monthly = (c.monthly_deduction || 0).toLocaleString();
    const text = `Dear ${name},\n\nYour Cash Advance request of ${amount} SAR has been processed. A monthly salary deduction installment of ${monthly} SAR has been scheduled.`;
    const subject = `Cash Advance Notice - Dunya AlMuehmat`;
    return { text, subject };
  },

  cashAdvanceDeduction: (employeeName: string, monthlyDeduction: number, remainingBalance: number) => {
    const text = `Dear ${employeeName},\n\nNotice: A monthly cash advance deduction of ${monthlyDeduction.toLocaleString()} SAR has been applied to your current payroll statement. Your remaining cash advance balance is ${remainingBalance.toLocaleString()} SAR.\n\nDunya AlMuehmat HR & Payroll Department`;
    const subject = `Cash Advance Deduction Alert - Dunya AlMuehmat`;
    return { text, subject };
  },
};
