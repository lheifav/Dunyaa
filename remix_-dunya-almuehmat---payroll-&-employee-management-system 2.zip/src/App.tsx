import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { LoginView } from './components/LoginView';
import { KioskView } from './components/KioskView';
import { DashboardOverview } from './components/DashboardOverview';
import { EmployeeManagement } from './components/EmployeeManagement';
import { AttendanceManagement } from './components/AttendanceManagement';
import { PayrollManagement } from './components/PayrollManagement';
import { OvertimeBonusManagement } from './components/OvertimeBonusManagement';
import { CashAdvanceManagement } from './components/CashAdvanceManagement';
import { LeaveRequestManagement } from './components/LeaveRequestManagement';
import { ReportsManagement } from './components/ReportsManagement';
import { SettingsView } from './components/SettingsView';
import { api } from './lib/api';
import { ShieldAlert, Clock, LogOut } from 'lucide-react';

const IDLE_TIMEOUT_MS = 15 * 60 * 1000; // 15 Minutes
const IDLE_WARNING_MS = 14.5 * 60 * 1000; // 14.5 Minutes (30s warning window)

export default function App() {
  const [mode, setMode] = useState<'admin' | 'kiosk' | 'login'>('login');
  const [adminUser, setAdminUser] = useState<{ id: number; username: string } | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [pendingLeavesCount, setPendingLeavesCount] = useState(0);

  // Idle Timeout State
  const [showIdleModal, setShowIdleModal] = useState(false);
  const [idleCountdown, setIdleCountdown] = useState(30);
  const [loginMessage, setLoginMessage] = useState<string | null>(null);

  const lastActivityRef = useRef<number>(Date.now());

  // Reset activity timestamp on user interaction
  const resetActivity = () => {
    lastActivityRef.current = Date.now();
    if (showIdleModal) {
      setShowIdleModal(false);
      setIdleCountdown(30);
    }
  };

  // Setup Activity Listeners when in Admin Mode
  useEffect(() => {
    if (mode !== 'admin') return;

    lastActivityRef.current = Date.now();
    setShowIdleModal(false);

    const activityEvents = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'];
    const handleUserActivity = () => {
      // Only auto-reset if not showing the final countdown modal (or let user click stay logged in)
      if (!showIdleModal) {
        lastActivityRef.current = Date.now();
      }
    };

    activityEvents.forEach((evt) => window.addEventListener(evt, handleUserActivity));

    // Idle Monitor Interval
    const idleCheckInterval = setInterval(() => {
      const timeSinceLastActivity = Date.now() - lastActivityRef.current;

      if (timeSinceLastActivity >= IDLE_TIMEOUT_MS) {
        // Trigger auto-logout
        handleLogout('Session automatically logged out due to 15 minutes of inactivity.');
      } else if (timeSinceLastActivity >= IDLE_WARNING_MS) {
        // Trigger 30s countdown warning modal
        if (!showIdleModal) {
          setShowIdleModal(true);
        }
        const remainingSeconds = Math.max(0, Math.ceil((IDLE_TIMEOUT_MS - timeSinceLastActivity) / 1000));
        setIdleCountdown(remainingSeconds);
      }
    }, 1000);

    return () => {
      activityEvents.forEach((evt) => window.removeEventListener(evt, handleUserActivity));
      clearInterval(idleCheckInterval);
    };
  }, [mode, showIdleModal]);

  // Fetch pending leaves count periodically for sidebar badge
  const checkPendingLeaves = async () => {
    try {
      const stats = await api.getDashboardStats();
      setPendingLeavesCount(stats.pendingLeaves || 0);
    } catch (err) {
      // silent
    }
  };

  useEffect(() => {
    if (mode === 'admin') {
      checkPendingLeaves();
      const interval = setInterval(checkPendingLeaves, 10000);
      return () => clearInterval(interval);
    }
  }, [mode]);

  const handleLoginSuccess = (user: { id: number; username: string }) => {
    setAdminUser(user);
    setMode('admin');
    setActiveTab('dashboard');
    setLoginMessage(null);
  };

  const handleLogout = (msg?: string) => {
    setAdminUser(null);
    setMode('login');
    setShowIdleModal(false);
    if (msg) {
      setLoginMessage(msg);
    }
  };

  const handleSwitchToKiosk = () => {
    setMode('kiosk');
  };

  return (
    <div id="app-root" className="min-h-screen bg-[#0f172a] text-slate-200 flex flex-col font-sans antialiased relative">
      
      {/* Top Navbar */}
      <Navbar
        mode={mode}
        adminUsername={adminUser?.username}
        onSwitchToKiosk={handleSwitchToKiosk}
        onLogout={() => handleLogout()}
      />

      {/* Main Body */}
      <main className="flex-1 flex flex-col">
        {mode === 'login' && (
          <div>
            {loginMessage && (
              <div className="max-w-md mx-auto mt-4 p-3 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-xl text-xs flex items-center justify-center gap-2 font-medium text-center">
                <Clock className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>{loginMessage}</span>
              </div>
            )}
            <LoginView
              onLoginSuccess={handleLoginSuccess}
              onEnterKiosk={handleSwitchToKiosk}
            />
          </div>
        )}

        {mode === 'kiosk' && (
          <KioskView onBackToAdmin={() => setMode('login')} />
        )}

        {mode === 'admin' && (
          <div className="flex-1 flex flex-col md:flex-row">
            {/* Sidebar */}
            <Sidebar
              activeTab={activeTab}
              onSelectTab={(tab) => setActiveTab(tab)}
              pendingLeavesCount={pendingLeavesCount}
            />

            {/* Main Admin Tab Viewport */}
            <div className="flex-1 p-4 sm:p-6 lg:p-8 bg-[#0f172a] max-w-7xl">
              {activeTab === 'dashboard' && (
                <DashboardOverview onNavigate={(tab) => setActiveTab(tab)} />
              )}
              {activeTab === 'employees' && <EmployeeManagement />}
              {activeTab === 'attendance' && <AttendanceManagement />}
              {activeTab === 'payroll' && <PayrollManagement />}
              {activeTab === 'overtime-bonuses' && <OvertimeBonusManagement />}
              {activeTab === 'advances' && <CashAdvanceManagement />}
              {activeTab === 'leaves' && <LeaveRequestManagement />}
              {activeTab === 'reports' && <ReportsManagement />}
              {activeTab === 'settings' && (
                <SettingsView adminUsername={adminUser?.username || 'admin'} />
              )}
            </div>
          </div>
        )}
      </main>

      {/* IDLE TIMEOUT AUTO LOGOUT WARNING MODAL */}
      {showIdleModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#1e293b] border border-amber-500/50 rounded-2xl w-full max-w-md p-6 shadow-2xl text-center space-y-4">
            <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-full flex items-center justify-center mx-auto">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-white font-serif italic">
                Inactivity Lock Warning
              </h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                You have been inactive for over 14 minutes. For payroll security, your Admin session will lock automatically in:
              </p>
            </div>

            {/* Countdown Badge */}
            <div className="py-3 px-6 bg-slate-900 rounded-xl border border-amber-500/40 inline-block font-mono text-3xl font-bold text-amber-400 shadow-inner">
              00:{idleCountdown < 10 ? `0${idleCountdown}` : idleCountdown}
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => handleLogout('Signed out manually from idle warning screen.')}
                className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out Now</span>
              </button>
              <button
                onClick={resetActivity}
                className="w-1/2 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl text-xs transition shadow-lg shadow-sky-500/20 active:scale-95"
              >
                Stay Logged In
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
