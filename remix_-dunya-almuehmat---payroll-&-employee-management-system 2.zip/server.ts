import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import bcrypt from 'bcryptjs';
import { initDb, run, get, all, syncRowToFirestore, deleteRowFromFirestore } from './server/db';
import os from 'os';

async function startServer() {
  // Initialize Database
  await initDb();

  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Helper: Get local network IP addresses
  function getLocalIpAddresses() {
    const interfaces = os.networkInterfaces();
    const ips: string[] = [];
    for (const devName in interfaces) {
      const iface = interfaces[devName];
      if (!iface) continue;
      for (const alias of iface) {
        if (alias.family === 'IPv4' && !alias.internal) {
          ips.push(alias.address);
        }
      }
    }
    return ips;
  }

  // ==========================================
  // AUTHENTICATION ROUTES
  // ==========================================
  app.get('/api/auth/admin-count', async (req: Request, res: Response) => {
    try {
      const row = await get(`SELECT COUNT(*) as count FROM admins`);
      const count = row ? Number(row.count) : 0;
      res.json({
        count,
        maxAllowed: 3,
        canRegister: count < 3,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error fetching admin count.' });
    }
  });

  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        res.status(400).json({ error: 'Username and password are required.' });
        return;
      }

      if (username.trim().length < 3) {
        res.status(400).json({ error: 'Username must be at least 3 characters long.' });
        return;
      }

      if (password.length < 4) {
        res.status(400).json({ error: 'Password must be at least 4 characters long.' });
        return;
      }

      // Check account limit (Max 3)
      const row = await get(`SELECT COUNT(*) as count FROM admins`);
      const count = row ? Number(row.count) : 0;
      if (count >= 3) {
        res.status(400).json({
          error: 'Registration limit reached! Maximum allowed admin accounts is 3.',
        });
        return;
      }

      // Check if username taken
      const existing = await get(`SELECT id FROM admins WHERE LOWER(username) = LOWER(?)`, [username.trim()]);
      if (existing) {
        res.status(400).json({ error: `Username "${username.trim()}" is already taken.` });
        return;
      }

      const password_hash = await bcrypt.hash(password, 10);
      const result = await run(`INSERT INTO admins (username, password_hash) VALUES (?, ?)`, [
        username.trim(),
        password_hash,
      ]);

      await syncRowToFirestore('admins', result.lastID);

      res.status(201).json({
        success: true,
        message: 'Admin account created successfully!',
        user: { id: result.lastID, username: username.trim() },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error creating admin account.' });
    }
  });

  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        res.status(400).json({ error: 'Username and password are required.' });
        return;
      }

      const admin = await get(`SELECT * FROM admins WHERE username = ?`, [username]);
      if (!admin) {
        res.status(401).json({ error: 'Invalid username or password.' });
        return;
      }

      const passwordValid = await bcrypt.compare(password, admin.password_hash);
      if (!passwordValid) {
        res.status(401).json({ error: 'Invalid username or password.' });
        return;
      }

      res.json({
        success: true,
        user: { id: admin.id, username: admin.username },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Server error during login.' });
    }
  });

  app.post('/api/auth/change-password', async (req: Request, res: Response) => {
    try {
      const { username, oldPassword, newPassword } = req.body;
      if (!username || !oldPassword || !newPassword) {
        res.status(400).json({ error: 'All fields are required.' });
        return;
      }

      const admin = await get(`SELECT * FROM admins WHERE username = ?`, [username]);
      if (!admin) {
        res.status(404).json({ error: 'Admin account not found.' });
        return;
      }

      const passwordValid = await bcrypt.compare(oldPassword, admin.password_hash);
      if (!passwordValid) {
        res.status(401).json({ error: 'Current password is incorrect.' });
        return;
      }

      const newHash = await bcrypt.hash(newPassword, 10);
      await run(`UPDATE admins SET password_hash = ? WHERE id = ?`, [newHash, admin.id]);

      res.json({ success: true, message: 'Password updated successfully.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error changing password.' });
    }
  });

  // Get list of all admin profiles
  app.get('/api/auth/admins', async (req: Request, res: Response) => {
    try {
      const admins = await all(`SELECT id, username, created_at FROM admins ORDER BY id ASC`);
      res.json(admins);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error fetching admin profiles.' });
    }
  });

  // Delete an admin profile by ID
  app.delete('/api/auth/admins/:id', async (req: Request, res: Response) => {
    try {
      const adminId = Number(req.params.id);
      
      // Ensure at least 1 admin remains
      const countRow = await get(`SELECT COUNT(*) as count FROM admins`);
      const totalCount = countRow ? Number(countRow.count) : 0;
      if (totalCount <= 1) {
        res.status(400).json({ error: 'Cannot delete the last remaining admin profile.' });
        return;
      }

      const adminToDelete = await get(`SELECT * FROM admins WHERE id = ?`, [adminId]);
      if (!adminToDelete) {
        res.status(404).json({ error: 'Admin profile not found.' });
        return;
      }

      await run(`DELETE FROM admins WHERE id = ?`, [adminId]);
      await deleteRowFromFirestore('admins', adminId);

      res.json({ success: true, message: `Admin profile "${adminToDelete.username}" deleted successfully.` });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error deleting admin profile.' });
    }
  });

  // ==========================================
  // EMPLOYEES ROUTES
  // ==========================================
  app.get('/api/employees', async (req: Request, res: Response) => {
    try {
      const { status, nationality, search } = req.query;
      let query = `SELECT * FROM employees WHERE 1=1`;
      const params: any[] = [];

      if (status && status !== 'all') {
        query += ` AND status = ?`;
        params.push(status);
      }
      if (nationality && nationality !== 'all') {
        query += ` AND nationality = ?`;
        params.push(nationality);
      }
      if (search) {
        query += ` AND (full_name LIKE ? OR employee_id LIKE ? OR iqama_number LIKE ? OR job_title LIKE ?)`;
        const term = `%${search}%`;
        params.push(term, term, term, term);
      }

      query += ` ORDER BY id DESC`;
      const employees = await all(query, params);
      res.json(employees);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/employees', async (req: Request, res: Response) => {
    try {
      const {
        employee_id,
        full_name,
        nationality,
        iqama_number,
        iqama_expiry,
        passport_number,
        job_title,
        hire_date,
        basic_salary,
        allowances,
        insurance,
        iban,
        phone_number,
        email,
        status,
      } = req.body;

      if (!employee_id || !full_name || !iqama_number || !basic_salary) {
        res.status(400).json({ error: 'Required fields missing.' });
        return;
      }

      // Check if employee_id exists
      const existing = await get(`SELECT id FROM employees WHERE employee_id = ?`, [employee_id]);
      if (existing) {
        res.status(400).json({ error: `Employee ID "${employee_id}" is already in use.` });
        return;
      }

      const result = await run(
        `INSERT INTO employees (employee_id, full_name, nationality, iqama_number, iqama_expiry, passport_number, job_title, hire_date, basic_salary, allowances, insurance, iban, pin_code, phone_number, email, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          employee_id,
          full_name,
          nationality || 'Saudi',
          iqama_number,
          iqama_expiry || '',
          passport_number || '',
          job_title || 'Employee',
          hire_date || new Date().toISOString().split('T')[0],
          Number(basic_salary) || 0,
          Number(allowances) || 0,
          Number(insurance) || 0,
          iban || '',
          req.body.pin_code || null,
          phone_number || null,
          email || null,
          status || 'active',
        ]
      );

      await syncRowToFirestore('employees', result.lastID);
      const created = await get(`SELECT * FROM employees WHERE id = ?`, [result.lastID]);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/employees/:id', async (req: Request, res: Response) => {
    try {
      const id = req.params.id;
      const {
        employee_id,
        full_name,
        nationality,
        iqama_number,
        iqama_expiry,
        passport_number,
        job_title,
        hire_date,
        basic_salary,
        allowances,
        insurance,
        iban,
        pin_code,
        phone_number,
        email,
        status,
      } = req.body;

      await run(
        `UPDATE employees SET
          employee_id = ?,
          full_name = ?,
          nationality = ?,
          iqama_number = ?,
          iqama_expiry = ?,
          passport_number = ?,
          job_title = ?,
          hire_date = ?,
          basic_salary = ?,
          allowances = ?,
          insurance = ?,
          iban = ?,
          pin_code = ?,
          phone_number = ?,
          email = ?,
          status = ?
        WHERE id = ?`,
        [
          employee_id,
          full_name,
          nationality,
          iqama_number,
          iqama_expiry,
          passport_number,
          job_title,
          hire_date,
          Number(basic_salary),
          Number(allowances),
          Number(insurance),
          iban,
          pin_code || null,
          phone_number || null,
          email || null,
          status,
          id,
        ]
      );

      await syncRowToFirestore('employees', id);
      const updated = await get(`SELECT * FROM employees WHERE id = ?`, [id]);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // VERIFY EMPLOYEE PIN / ACCESS KEY
  app.post('/api/employees/:id/verify-pin', async (req: Request, res: Response) => {
    try {
      const id = req.params.id;
      const { pin } = req.body;

      if (!pin) {
        res.status(400).json({ verified: false, error: 'PIN or Security code is required.' });
        return;
      }

      const emp = await get(`SELECT * FROM employees WHERE id = ?`, [id]);
      if (!emp) {
        res.status(404).json({ verified: false, error: 'Employee record not found.' });
        return;
      }

      const cleanPin = String(pin).trim();
      const storedPin = emp.pin_code ? String(emp.pin_code).trim() : '';
      const last4Iqama = emp.iqama_number ? String(emp.iqama_number).trim().slice(-4) : '';
      const empCode = String(emp.employee_id).trim();

      if (
        (storedPin && cleanPin === storedPin) ||
        (last4Iqama && cleanPin === last4Iqama) ||
        (empCode && cleanPin.toLowerCase() === empCode.toLowerCase())
      ) {
        res.json({ verified: true, message: 'Access granted.' });
      } else {
        res.status(401).json({ verified: false, error: 'Incorrect PIN code or Iqama digits.' });
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/employees/:id', async (req: Request, res: Response) => {
    try {
      const id = req.params.id;
      await run(`DELETE FROM employees WHERE id = ?`, [id]);
      await deleteRowFromFirestore('employees', id);
      res.json({ success: true, message: 'Employee deleted.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // ATTENDANCE (KIOSK & ADMIN)
  // ==========================================
  app.get('/api/attendance', async (req: Request, res: Response) => {
    try {
      const { date, employee_id, month } = req.query;
      let query = `
        SELECT a.*, e.full_name as employee_name, e.employee_id as employee_code
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE 1=1
      `;
      const params: any[] = [];

      if (date) {
        query += ` AND a.date = ?`;
        params.push(date);
      }
      if (employee_id) {
        query += ` AND a.employee_id = ?`;
        params.push(employee_id);
      }
      if (month) {
        query += ` AND a.date LIKE ?`;
        params.push(`${month}%`);
      }

      query += ` ORDER BY a.date DESC, a.id DESC`;
      const records = await all(query, params);
      res.json(records);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Kiosk Punch In / Punch Out
  app.post('/api/attendance/punch', async (req: Request, res: Response) => {
    try {
      const { employee_id, action } = req.body; // action can be 'in' | 'out' | 'auto'
      if (!employee_id) {
        res.status(400).json({ error: 'Employee is required.' });
        return;
      }

      const emp = await get(`SELECT * FROM employees WHERE id = ? AND status = 'active'`, [employee_id]);
      if (!emp) {
        res.status(404).json({ error: 'Active employee record not found.' });
        return;
      }

      const now = new Date();
      const today = now.toISOString().split('T')[0];
      const timeStr = now.toTimeString().split(' ')[0]; // HH:MM:SS

      const existing = await get(`SELECT * FROM attendance WHERE employee_id = ? AND date = ?`, [employee_id, today]);

      if (action === 'in') {
        if (existing && existing.time_in) {
          res.status(400).json({
            error: `Already punched in today at ${existing.time_in}`,
            record: existing,
          });
          return;
        }
        if (existing) {
          await run(`UPDATE attendance SET time_in = ? WHERE id = ?`, [timeStr, existing.id]);
        } else {
          await run(`INSERT INTO attendance (employee_id, date, time_in) VALUES (?, ?, ?)`, [
            employee_id,
            today,
            timeStr,
          ]);
        }
        res.json({
          success: true,
          action: 'PUNCH_IN',
          message: `Successfully punched IN for ${emp.full_name} at ${timeStr}`,
          employee: emp,
          time: timeStr,
        });
        return;
      }

      if (action === 'out') {
        if (!existing || !existing.time_in) {
          res.status(400).json({
            error: `Cannot punch out without punching in first.`,
          });
          return;
        }
        if (existing.time_out) {
          res.status(400).json({
            error: `Already punched out today at ${existing.time_out}`,
            record: existing,
          });
          return;
        }
        await run(`UPDATE attendance SET time_out = ? WHERE id = ?`, [timeStr, existing.id]);
        res.json({
          success: true,
          action: 'PUNCH_OUT',
          message: `Successfully punched OUT for ${emp.full_name} at ${timeStr}`,
          employee: emp,
          time: timeStr,
        });
        return;
      }

      // Auto mode
      if (!existing || !existing.time_in) {
        await run(`INSERT INTO attendance (employee_id, date, time_in) VALUES (?, ?, ?)`, [employee_id, today, timeStr]);
        res.json({
          success: true,
          action: 'PUNCH_IN',
          message: `Punched IN for ${emp.full_name} at ${timeStr}`,
          employee: emp,
          time: timeStr,
        });
      } else if (!existing.time_out) {
        await run(`UPDATE attendance SET time_out = ? WHERE id = ?`, [timeStr, existing.id]);
        res.json({
          success: true,
          action: 'PUNCH_OUT',
          message: `Punched OUT for ${emp.full_name} at ${timeStr}`,
          employee: emp,
          time: timeStr,
        });
      } else {
        res.status(400).json({
          error: `${emp.full_name} has already completed both Punch In (${existing.time_in}) and Punch Out (${existing.time_out}) for today.`,
        });
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Admin manual entry
  app.post('/api/attendance/manual', async (req: Request, res: Response) => {
    try {
      const { employee_id, date, time_in, time_out } = req.body;
      if (!employee_id || !date) {
        res.status(400).json({ error: 'Employee and date are required.' });
        return;
      }

      const existing = await get(`SELECT id FROM attendance WHERE employee_id = ? AND date = ?`, [employee_id, date]);
      if (existing) {
        await run(`UPDATE attendance SET time_in = ?, time_out = ? WHERE id = ?`, [
          time_in || null,
          time_out || null,
          existing.id,
        ]);
      } else {
        await run(`INSERT INTO attendance (employee_id, date, time_in, time_out) VALUES (?, ?, ?, ?)`, [
          employee_id,
          date,
          time_in || null,
          time_out || null,
        ]);
      }

      res.json({ success: true, message: 'Attendance record updated successfully.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/attendance/:id', async (req: Request, res: Response) => {
    try {
      await run(`DELETE FROM attendance WHERE id = ?`, [req.params.id]);
      res.json({ success: true, message: 'Attendance log removed.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // PAYROLL ROUTES
  // ==========================================
  app.get('/api/payroll/periods', async (_req: Request, res: Response) => {
    try {
      const periods = await all(`
        SELECT DISTINCT period_start, period_end
        FROM payroll
        ORDER BY period_start DESC
      `);
      res.json(periods);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/payroll', async (req: Request, res: Response) => {
    try {
      const { period_start, period_end, employee_id } = req.query;
      let query = `
        SELECT p.*, e.full_name as employee_name, e.employee_id as employee_code, e.job_title, e.iban
        FROM payroll p
        JOIN employees e ON p.employee_id = e.id
        WHERE 1=1
      `;
      const params: any[] = [];

      if (period_start) {
        query += ` AND p.period_start = ?`;
        params.push(period_start);
      }
      if (period_end) {
        query += ` AND p.period_end = ?`;
        params.push(period_end);
      }
      if (employee_id) {
        query += ` AND p.employee_id = ?`;
        params.push(employee_id);
      }

      query += ` ORDER BY p.generated_date DESC, p.id DESC`;
      const list = await all(query, params);
      res.json(list);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Calculate/Preview payroll for a given date range
  app.post('/api/payroll/calculate', async (req: Request, res: Response) => {
    try {
      const { period_start, period_end } = req.body;
      if (!period_start || !period_end) {
        res.status(400).json({ error: 'Start and end dates required.' });
        return;
      }

      const activeEmployees = await all(`SELECT * FROM employees WHERE status = 'active' ORDER BY full_name ASC`);

      const sDate = new Date(period_start);
      const eDate = new Date(period_end);
      const periodDays = Math.max(1, Math.round((eDate.getTime() - sDate.getTime()) / (1000 * 60 * 60 * 24)) + 1);

      const calculations = [];

      for (const emp of activeEmployees) {
        // Fetch active cash advance
        const activeAdvance = await get(
          `SELECT * FROM cash_advances WHERE employee_id = ? AND status = 'active' AND balance > 0`,
          [emp.id]
        );

        let cashAdvanceDeduction = 0;
        if (activeAdvance) {
          cashAdvanceDeduction = Math.min(activeAdvance.monthly_deduction, activeAdvance.balance);
        }

        // Fetch insurance
        const insuranceDeduction = Number(emp.insurance) || 0;

        // Fetch attendance logs within period
        const attendanceLogs = await all(
          `SELECT date FROM attendance WHERE employee_id = ? AND date >= ? AND date <= ? AND time_in IS NOT NULL`,
          [emp.id, period_start, period_end]
        );
        const presentDays = attendanceLogs.length;

        // Fetch approved leave requests overlapping period
        const approvedLeaves = await all(
          `SELECT * FROM leave_requests
           WHERE employee_id = ? AND status = 'approved'
           AND start_date <= ? AND end_date >= ?`,
          [emp.id, period_end, period_start]
        );

        let paidLeaveDays = 0;
        let unpaidLeaveDays = 0;

        for (const l of approvedLeaves) {
          const lStart = new Date(l.start_date) < sDate ? sDate : new Date(l.start_date);
          const lEnd = new Date(l.end_date) > eDate ? eDate : new Date(l.end_date);
          const diffDays = Math.max(1, Math.round((lEnd.getTime() - lStart.getTime()) / (1000 * 60 * 60 * 24)) + 1);

          if (l.leave_type === 'Unpaid') {
            unpaidLeaveDays += diffDays;
          } else {
            paidLeaveDays += diffDays;
          }
        }

        // Calculate unexcused absence days (if employee did not punch in and was not on approved leave)
        const accountedDays = presentDays + paidLeaveDays + unpaidLeaveDays;
        const absentDays = Math.max(0, periodDays - accountedDays);

        // Standard 30-day labor law daily salary rate
        const dailySalaryRate = (Number(emp.basic_salary) + Number(emp.allowances)) / 30;

        const unpaidLeaveDeduction = Math.round(dailySalaryRate * unpaidLeaveDays * 100) / 100;
        const absenceDeduction = Math.round(dailySalaryRate * absentDays * 100) / 100;
        const attendanceDeduction = Math.round((unpaidLeaveDeduction + absenceDeduction) * 100) / 100;

        const basic = Number(emp.basic_salary) || 0;
        const allowances = Number(emp.allowances) || 0;

        // Fetch pending bonuses for this employee
        const pendingBonuses = await all(
          `SELECT * FROM employee_bonuses WHERE employee_id = ? AND status = 'pending'`,
          [emp.id]
        );
        const bonusPay = pendingBonuses.reduce((sum: number, b: any) => sum + Number(b.amount || 0), 0);
        const bonusDetails = pendingBonuses.length > 0 ? JSON.stringify(pendingBonuses) : null;

        // Calculate Overtime Pay
        let overtimeHours = 0;
        let overtimePay = 0;
        let overtimeRuleId: number | null = null;

        const otInput = req.body.overtime_data ? req.body.overtime_data[emp.id] : null;
        if (otInput && Number(otInput.hours) > 0) {
          overtimeHours = Number(otInput.hours) || 0;
          overtimeRuleId = otInput.rule_id || null;
          let multiplier = 1.5;
          if (overtimeRuleId) {
            const rule = await get(`SELECT * FROM overtime_rules WHERE id = ?`, [overtimeRuleId]);
            if (rule) multiplier = Number(rule.multiplier) || 1.5;
          }
          const hourlyRate = (basic + allowances) / 240;
          overtimePay = Math.round(hourlyRate * multiplier * overtimeHours * 100) / 100;
        }

        const grossSalary = basic + allowances + overtimePay + bonusPay;
        const totalDeductions = Math.round((attendanceDeduction + insuranceDeduction + cashAdvanceDeduction) * 100) / 100;
        const netSalary = Math.max(0, Math.round((grossSalary - totalDeductions) * 100) / 100);

        calculations.push({
          employee_id: emp.id,
          employee_name: emp.full_name,
          employee_code: emp.employee_id,
          job_title: emp.job_title,
          iban: emp.iban,
          period_start,
          period_end,
          basic_salary: basic,
          allowances: allowances,
          present_days: presentDays,
          absent_days: absentDays,
          unpaid_leave_days: unpaidLeaveDays,
          daily_rate: Math.round(dailySalaryRate * 100) / 100,
          attendance_deduction: attendanceDeduction,
          deductions: attendanceDeduction, // maps to attendance/unpaid deductions column
          insurance_deduction: insuranceDeduction,
          cash_advance_deduction: cashAdvanceDeduction,
          overtime_hours: overtimeHours,
          overtime_pay: overtimePay,
          overtime_rule_id: overtimeRuleId,
          bonus_pay: bonusPay,
          bonus_details: bonusDetails,
          net_salary: netSalary,
        });
      }

      res.json(calculations);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Generate / Commit Payroll records
  app.post('/api/payroll/generate', async (req: Request, res: Response) => {
    try {
      const { items, period_start, period_end } = req.body;
      if (!Array.isArray(items) || items.length === 0) {
        res.status(400).json({ error: 'No payroll items provided.' });
        return;
      }

      const nowStr = new Date().toISOString().split('T')[0];

      for (const item of items) {
        // Insert payroll entry with attendance, overtime & bonus metrics
        const pResult = await run(
          `INSERT INTO payroll (
            employee_id, period_start, period_end, basic_salary, allowances,
            present_days, absent_days, unpaid_leave_days, deductions,
            insurance_deduction, cash_advance_deduction, overtime_hours, overtime_pay,
            overtime_rule_id, bonus_pay, bonus_details, net_salary, generated_date
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            item.employee_id,
            period_start,
            period_end,
            item.basic_salary,
            item.allowances,
            item.present_days || 0,
            item.absent_days || 0,
            item.unpaid_leave_days || 0,
            item.deductions || 0,
            item.insurance_deduction || 0,
            item.cash_advance_deduction || 0,
            item.overtime_hours || 0,
            item.overtime_pay || 0,
            item.overtime_rule_id || null,
            item.bonus_pay || 0,
            item.bonus_details || null,
            item.net_salary,
            nowStr,
          ]
        );

        // Mark pending bonuses as processed for this employee
        if (item.bonus_pay > 0) {
          await run(
            `UPDATE employee_bonuses SET status = 'processed', payroll_id = ? WHERE employee_id = ? AND status = 'pending'`,
            [pResult.lastID, item.employee_id]
          );
        }

        // Deduct from cash advance if applicable
        if (item.cash_advance_deduction > 0) {
          const activeAdvance = await get(
            `SELECT * FROM cash_advances WHERE employee_id = ? AND status = 'active' AND balance > 0`,
            [item.employee_id]
          );

          if (activeAdvance) {
            const newBalance = Math.max(0, activeAdvance.balance - item.cash_advance_deduction);
            const newStatus = newBalance === 0 ? 'paid' : 'active';
            await run(`UPDATE cash_advances SET balance = ?, status = ? WHERE id = ?`, [
              newBalance,
              newStatus,
              activeAdvance.id,
            ]);
          }

          // Trigger "Cash advance deducted" Notification
          await run(
            `INSERT INTO notifications (employee_id, type, title, message) VALUES (?, 'cash_advance_deducted', ?, ?)`,
            [
              item.employee_id,
              'Cash Advance Deducted',
              `Monthly installment deduction of ${item.cash_advance_deduction.toLocaleString()} SAR was applied to your account during payroll calculation.`,
            ]
          );
        }

        // Trigger "Salary released" Notification
        await run(
          `INSERT INTO notifications (employee_id, type, title, message) VALUES (?, 'salary_released', ?, ?)`,
          [
            item.employee_id,
            'Salary Released',
            `Your paystub for period ${period_start} to ${period_end} of ${item.net_salary.toLocaleString()} SAR has been released.`,
          ]
        );
      }

      res.json({ success: true, message: `Successfully generated payroll for ${items.length} employees.` });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/payroll/:id', async (req: Request, res: Response) => {
    try {
      await run(`DELETE FROM payroll WHERE id = ?`, [req.params.id]);
      res.json({ success: true, message: 'Payroll entry deleted.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // CASH ADVANCES
  // ==========================================
  app.get('/api/cash-advances', async (req: Request, res: Response) => {
    try {
      const list = await all(`
        SELECT c.*, e.full_name as employee_name, e.employee_id as employee_code
        FROM cash_advances c
        JOIN employees e ON c.employee_id = e.id
        ORDER BY c.id DESC
      `);
      res.json(list);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/cash-advances', async (req: Request, res: Response) => {
    try {
      const { employee_id, amount, monthly_deduction } = req.body;
      if (!employee_id || !amount || !monthly_deduction) {
        res.status(400).json({ error: 'Employee, amount, and monthly repayment are required.' });
        return;
      }

      const result = await run(
        `INSERT INTO cash_advances (employee_id, amount, balance, monthly_deduction, status)
         VALUES (?, ?, ?, ?, 'active')`,
        [employee_id, Number(amount), Number(amount), Number(monthly_deduction)]
      );

      const created = await get(
        `SELECT c.*, e.full_name as employee_name, e.employee_id as employee_code
         FROM cash_advances c JOIN employees e ON c.employee_id = e.id
         WHERE c.id = ?`,
        [result.lastID]
      );
      res.status(201).json(created);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/cash-advances/:id', async (req: Request, res: Response) => {
    try {
      const { balance, monthly_deduction, status } = req.body;
      const id = req.params.id;

      let calcStatus = status;
      if (Number(balance) <= 0) {
        calcStatus = 'paid';
      }

      await run(
        `UPDATE cash_advances SET balance = ?, monthly_deduction = ?, status = ? WHERE id = ?`,
        [Number(balance), Number(monthly_deduction), calcStatus, id]
      );

      const updated = await get(`SELECT * FROM cash_advances WHERE id = ?`, [id]);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/cash-advances/:id', async (req: Request, res: Response) => {
    try {
      await run(`DELETE FROM cash_advances WHERE id = ?`, [req.params.id]);
      res.json({ success: true, message: 'Cash advance record removed.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // LEAVE REQUESTS
  // ==========================================
  app.get('/api/leave-requests', async (req: Request, res: Response) => {
    try {
      const list = await all(`
        SELECT l.*, e.full_name as employee_name, e.employee_id as employee_code
        FROM leave_requests l
        JOIN employees e ON l.employee_id = e.id
        ORDER BY l.id DESC
      `);
      res.json(list);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/leave-requests', async (req: Request, res: Response) => {
    try {
      const { employee_id, leave_type, start_date, end_date, reason } = req.body;
      if (!employee_id || !leave_type || !start_date || !end_date) {
        res.status(400).json({ error: 'Employee, type, start, and end date required.' });
        return;
      }

      const result = await run(
        `INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, reason, status)
         VALUES (?, ?, ?, ?, ?, 'pending')`,
        [employee_id, leave_type, start_date, end_date, reason || '']
      );

      const created = await get(
        `SELECT l.*, e.full_name as employee_name, e.employee_id as employee_code
         FROM leave_requests l JOIN employees e ON l.employee_id = e.id
         WHERE l.id = ?`,
        [result.lastID]
      );
      res.status(201).json(created);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/leave-requests/:id/status', async (req: Request, res: Response) => {
    try {
      const { status } = req.body;
      if (!['approved', 'rejected', 'pending'].includes(status)) {
        res.status(400).json({ error: 'Invalid status.' });
        return;
      }

      await run(`UPDATE leave_requests SET status = ? WHERE id = ?`, [status, req.params.id]);
      const updated = await get(`SELECT * FROM leave_requests WHERE id = ?`, [req.params.id]);

      if (status === 'approved' && updated) {
        await run(
          `INSERT INTO notifications (employee_id, type, title, message) VALUES (?, 'leave_approved', ?, ?)`,
          [
            updated.employee_id,
            'Leave Request Approved',
            `Your ${updated.leave_type} leave request from ${updated.start_date} to ${updated.end_date} has been approved.`,
          ]
        );
      }

      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // OVERTIME RULES
  // ==========================================
  app.get('/api/overtime-rules', async (_req: Request, res: Response) => {
    try {
      const list = await all(`SELECT * FROM overtime_rules ORDER BY multiplier ASC`);
      res.json(list);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/overtime-rules', async (req: Request, res: Response) => {
    try {
      const { rule_name, multiplier, description } = req.body;
      if (!rule_name || !multiplier) {
        res.status(400).json({ error: 'Rule name and multiplier are required.' });
        return;
      }
      const result = await run(
        `INSERT INTO overtime_rules (rule_name, multiplier, description) VALUES (?, ?, ?)`,
        [rule_name, Number(multiplier), description || '']
      );
      const created = await get(`SELECT * FROM overtime_rules WHERE id = ?`, [result.lastID]);
      res.status(201).json(created);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/overtime-rules/:id', async (req: Request, res: Response) => {
    try {
      const { rule_name, multiplier, description, is_active } = req.body;
      await run(
        `UPDATE overtime_rules SET rule_name = ?, multiplier = ?, description = ?, is_active = ? WHERE id = ?`,
        [rule_name, Number(multiplier), description || '', is_active !== undefined ? is_active : 1, req.params.id]
      );
      const updated = await get(`SELECT * FROM overtime_rules WHERE id = ?`, [req.params.id]);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/overtime-rules/:id', async (req: Request, res: Response) => {
    try {
      await run(`DELETE FROM overtime_rules WHERE id = ?`, [req.params.id]);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // EMPLOYEE BONUSES
  // ==========================================
  app.get('/api/bonuses', async (req: Request, res: Response) => {
    try {
      const { employee_id } = req.query;
      let sql = `
        SELECT b.*, e.full_name as employee_name, e.employee_id as employee_code
        FROM employee_bonuses b
        JOIN employees e ON b.employee_id = e.id
      `;
      const params: any[] = [];
      if (employee_id) {
        sql += ` WHERE b.employee_id = ?`;
        params.push(employee_id);
      }
      sql += ` ORDER BY b.id DESC`;

      const list = await all(sql, params);
      res.json(list);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/bonuses', async (req: Request, res: Response) => {
    try {
      const { employee_id, bonus_type, amount, effective_date, description } = req.body;
      if (!employee_id || !bonus_type || !amount) {
        res.status(400).json({ error: 'Employee, bonus type, and amount are required.' });
        return;
      }

      const dateStr = effective_date || new Date().toISOString().split('T')[0];
      const result = await run(
        `INSERT INTO employee_bonuses (employee_id, bonus_type, amount, effective_date, description) VALUES (?, ?, ?, ?, ?)`,
        [employee_id, bonus_type, Number(amount), dateStr, description || '']
      );

      // Create Notification
      const emp = await get(`SELECT full_name FROM employees WHERE id = ?`, [employee_id]);
      await run(
        `INSERT INTO notifications (employee_id, type, title, message) VALUES (?, 'system', ?, ?)`,
        [
          employee_id,
          'Bonus Awarded',
          `A ${bonus_type} of ${Number(amount).toLocaleString()} SAR has been assigned for processing in your next paystub.`,
        ]
      );

      const created = await get(`SELECT * FROM employee_bonuses WHERE id = ?`, [result.lastID]);
      res.status(201).json({ ...created, employee_name: emp?.full_name });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/bonuses/:id/cancel', async (req: Request, res: Response) => {
    try {
      await run(`UPDATE employee_bonuses SET status = 'cancelled' WHERE id = ?`, [req.params.id]);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // DASHBOARD STATS
  // ==========================================
  app.get('/api/dashboard/stats', async (_req: Request, res: Response) => {
    try {
      const totalEmployeesRow = await get<{ count: number }>(`SELECT COUNT(*) as count FROM employees`);
      const activeEmployeesRow = await get<{ count: number }>(`SELECT COUNT(*) as count FROM employees WHERE status = 'active'`);
      const saudiRow = await get<{ count: number }>(`SELECT COUNT(*) as count FROM employees WHERE nationality = 'Saudi' AND status = 'active'`);
      const expatRow = await get<{ count: number }>(`SELECT COUNT(*) as count FROM employees WHERE nationality = 'Expat' AND status = 'active'`);

      const today = new Date().toISOString().split('T')[0];
      const presentRow = await get<{ count: number }>(`SELECT COUNT(*) as count FROM attendance WHERE date = ? AND time_in IS NOT NULL`, [today]);

      const pendingLeavesRow = await get<{ count: number }>(`SELECT COUNT(*) as count FROM leave_requests WHERE status = 'pending'`);

      const advanceSumRow = await get<{ total: number }>(`SELECT SUM(balance) as total FROM cash_advances WHERE status = 'active'`);

      // Current month total payroll
      const currentMonth = today.substring(0, 7); // YYYY-MM
      const payrollSumRow = await get<{ total: number }>(`SELECT SUM(net_salary) as total FROM payroll WHERE period_start LIKE ?`, [`${currentMonth}%`]);

      // Iqama expiring within 30 days
      const in30DaysDate = new Date();
      in30DaysDate.setDate(in30DaysDate.getDate() + 30);
      const in30DaysStr = in30DaysDate.toISOString().split('T')[0];

      const iqamaRow = await get<{ count: number }>(
        `SELECT COUNT(*) as count FROM employees WHERE status = 'active' AND iqama_expiry != '' AND iqama_expiry <= ?`,
        [in30DaysStr]
      );

      res.json({
        totalEmployees: totalEmployeesRow?.count || 0,
        activeEmployees: activeEmployeesRow?.count || 0,
        saudiCount: saudiRow?.count || 0,
        expatCount: expatRow?.count || 0,
        presentToday: presentRow?.count || 0,
        pendingLeaves: pendingLeavesRow?.count || 0,
        activeAdvancesTotal: advanceSumRow?.total || 0,
        currentMonthPayrollTotal: payrollSumRow?.total || 0,
        iqamaExpiringSoonCount: iqamaRow?.count || 0,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Settings & Network LAN Info
  app.get('/api/settings/lan-info', (_req: Request, res: Response) => {
    const ips = getLocalIpAddresses();
    res.json({
      port: PORT,
      lanIps: ips,
      companyName: 'Dunya AlMuehmat for Office Equipments',
      companyNameArabic: 'دنيا المهمات لمعدات المكاتب',
      currency: 'SAR',
      version: '1.0.0',
    });
  });

  // ==========================================
  // COMPREHENSIVE REPORTS ENDPOINTS
  // ==========================================
  app.get('/api/reports/payroll-summary', async (req: Request, res: Response) => {
    try {
      const { startDate, endDate, employeeId } = req.query;
      let query = `
        SELECT p.*, e.full_name as employee_name, e.employee_id as employee_code, e.job_title, e.iban, e.nationality
        FROM payroll p
        JOIN employees e ON p.employee_id = e.id
        WHERE 1=1
      `;
      const params: any[] = [];
      if (startDate) { query += ` AND p.period_start >= ?`; params.push(startDate); }
      if (endDate) { query += ` AND p.period_end <= ?`; params.push(endDate); }
      if (employeeId && employeeId !== 'all') { query += ` AND p.employee_id = ?`; params.push(employeeId); }

      query += ` ORDER BY p.period_start DESC, e.full_name ASC`;
      const records = await all(query, params);

      const totals = records.reduce(
        (acc, r) => {
          acc.basic += Number(r.basic_salary || 0);
          acc.allowances += Number(r.allowances || 0);
          acc.overtime += Number(r.overtime_pay || 0);
          acc.bonuses += Number(r.bonus_pay || 0);
          acc.deductions += Number(r.deductions || 0) + Number(r.insurance_deduction || 0) + Number(r.cash_advance_deduction || 0);
          acc.net += Number(r.net_salary || 0);
          return acc;
        },
        { basic: 0, allowances: 0, overtime: 0, bonuses: 0, deductions: 0, net: 0 }
      );

      res.json({ totals, records });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/reports/attendance-logs', async (req: Request, res: Response) => {
    try {
      const { startDate, endDate, employeeId } = req.query;
      let query = `
        SELECT a.*, e.full_name as employee_name, e.employee_id as employee_code, e.job_title
        FROM attendance a
        JOIN employees e ON a.employee_id = e.id
        WHERE 1=1
      `;
      const params: any[] = [];
      if (startDate) { query += ` AND a.date >= ?`; params.push(startDate); }
      if (endDate) { query += ` AND a.date <= ?`; params.push(endDate); }
      if (employeeId && employeeId !== 'all') { query += ` AND a.employee_id = ?`; params.push(employeeId); }

      query += ` ORDER BY a.date DESC, e.full_name ASC`;
      const records = await all(query, params);

      let totalPresent = 0;
      let totalLate = 0;
      let totalCompleteShifts = 0;

      const processed = records.map((r: any) => {
        let status = 'Present';
        if (r.time_in) {
          totalPresent++;
          if (r.time_in > '08:30:00') {
            status = 'Late Arrival';
            totalLate++;
          }
        }
        if (r.time_in && r.time_out) {
          totalCompleteShifts++;
        } else if (r.time_in && !r.time_out) {
          status = 'Punched In (Active)';
        }

        return { ...r, status };
      });

      res.json({
        summary: {
          totalRecords: records.length,
          totalPresent,
          totalLate,
          totalCompleteShifts,
        },
        records: processed,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/reports/leave-stats', async (req: Request, res: Response) => {
    try {
      const { startDate, endDate, employeeId } = req.query;
      let query = `
        SELECT l.*, e.full_name as employee_name, e.employee_id as employee_code, e.job_title
        FROM leave_requests l
        JOIN employees e ON l.employee_id = e.id
        WHERE 1=1
      `;
      const params: any[] = [];
      if (startDate) { query += ` AND l.start_date >= ?`; params.push(startDate); }
      if (endDate) { query += ` AND l.end_date <= ?`; params.push(endDate); }
      if (employeeId && employeeId !== 'all') { query += ` AND l.employee_id = ?`; params.push(employeeId); }

      query += ` ORDER BY l.created_at DESC`;
      const records = await all(query, params);

      const summary = {
        totalRequests: records.length,
        approved: records.filter((r) => r.status === 'approved').length,
        pending: records.filter((r) => r.status === 'pending').length,
        rejected: records.filter((r) => r.status === 'rejected').length,
        byType: {
          Annual: 0,
          Sick: 0,
          Emergency: 0,
          Unpaid: 0,
        },
      };

      records.forEach((r) => {
        if (r.status === 'approved') {
          const s = new Date(r.start_date);
          const e = new Date(r.end_date);
          const days = Math.max(1, Math.round((e.getTime() - s.getTime()) / (1000 * 60 * 60 * 24)) + 1);
          const typeKey = (r.leave_type as 'Annual' | 'Sick' | 'Emergency' | 'Unpaid') || 'Annual';
          if (summary.byType[typeKey] !== undefined) {
            summary.byType[typeKey] += days;
          }
        }
      });

      res.json({ summary, records });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/reports/cash-advances', async (req: Request, res: Response) => {
    try {
      const { employeeId } = req.query;
      let query = `
        SELECT c.*, e.full_name as employee_name, e.employee_id as employee_code, e.job_title, e.basic_salary
        FROM cash_advances c
        JOIN employees e ON c.employee_id = e.id
        WHERE 1=1
      `;
      const params: any[] = [];
      if (employeeId && employeeId !== 'all') { query += ` AND c.employee_id = ?`; params.push(employeeId); }

      query += ` ORDER BY c.id DESC`;
      const records = await all(query, params);

      const totals = records.reduce(
        (acc, r) => {
          acc.totalGranted += Number(r.amount || 0);
          acc.totalBalance += Number(r.balance || 0);
          acc.totalRepaid += Number(r.amount || 0) - Number(r.balance || 0);
          if (r.status === 'active') acc.activeCount++;
          return acc;
        },
        { totalGranted: 0, totalBalance: 0, totalRepaid: 0, activeCount: 0 }
      );

      res.json({ totals, records });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // NOTIFICATIONS
  // ==========================================
  app.get('/api/notifications', async (req: Request, res: Response) => {
    try {
      const { employee_id } = req.query;
      let sql = `
        SELECT n.*, e.full_name as employee_name, e.employee_id as employee_code
        FROM notifications n
        LEFT JOIN employees e ON n.employee_id = e.id
      `;
      const params: any[] = [];
      if (employee_id) {
        sql += ` WHERE n.employee_id = ?`;
        params.push(employee_id);
      }
      sql += ` ORDER BY n.id DESC LIMIT 50`;

      const list = await all(sql, params);
      res.json(list);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/notifications/mark-read', async (req: Request, res: Response) => {
    try {
      const { id } = req.body;
      if (id) {
        await run(`UPDATE notifications SET is_read = 1 WHERE id = ?`, [id]);
      } else {
        await run(`UPDATE notifications SET is_read = 1`);
      }
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // DATABASE BACKUP & RESTORE OPTIONS
  // ==========================================
  app.get('/api/admin/backup-db', async (_req: Request, res: Response) => {
    try {
      const dbPath = path.resolve(process.cwd(), 'dunya_payroll.db');
      if (!fs.existsSync(dbPath)) {
        res.status(404).json({ error: 'Database file not found on disk.' });
        return;
      }
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `dunya_payroll_backup_${dateStr}.db`;

      res.setHeader('Content-Type', 'application/x-sqlite3');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      const fileBuffer = fs.readFileSync(dbPath);
      res.send(fileBuffer);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/admin/backup-json', async (_req: Request, res: Response) => {
    try {
      const employees = await all(`SELECT * FROM employees`);
      const attendance = await all(`SELECT * FROM attendance`);
      const payroll = await all(`SELECT * FROM payroll`);
      const cash_advances = await all(`SELECT * FROM cash_advances`);
      const leave_requests = await all(`SELECT * FROM leave_requests`);
      const notifications = await all(`SELECT * FROM notifications`);
      const dbPath = path.resolve(process.cwd(), 'dunya_payroll.db');
      const stats = fs.existsSync(dbPath) ? fs.statSync(dbPath) : null;

      const dump = {
        app: 'Dunya AlMuehmat Payroll & HR System',
        backup_date: new Date().toISOString(),
        database_file_size_bytes: stats?.size || 0,
        data: {
          employees,
          attendance,
          payroll,
          cash_advances,
          leave_requests,
          notifications,
        },
      };

      const dateStr = new Date().toISOString().split('T')[0];
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="dunya_payroll_data_${dateStr}.json"`);
      res.json(dump);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ==========================================
  // VITE / STATIC MIDDLWARE
  // ==========================================
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Dunya AlMuehmat Payroll Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
