import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { getFirestoreInstance, syncToFirestore, deleteFromFirestore, fetchCollectionFromFirestore } from './firebase';

const dbPath = path.resolve(process.cwd(), 'dunya_payroll.db');
let dbInstance: Database | null = null;

function saveDb() {
  if (dbInstance) {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  }
}

export async function getDb(): Promise<Database> {
  if (!dbInstance) {
    const SQL = await initSqlJs();
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      dbInstance = new SQL.Database(fileBuffer);
    } else {
      dbInstance = new SQL.Database();
    }
  }
  return dbInstance;
}

export async function run(sql: string, params: any[] = []): Promise<{ lastID: number; changes: number }> {
  const db = await getDb();
  db.run(sql, params);

  const res = db.exec("SELECT last_insert_rowid() as lastID, changes() as changes");
  let lastID = 0;
  let changes = 0;
  if (res.length > 0 && res[0].values.length > 0) {
    lastID = (res[0].values[0][0] as number) || 0;
    changes = (res[0].values[0][1] as number) || 0;
  }

  saveDb();
  return { lastID, changes };
}

// Helper to sync table row to Firestore doc
export async function syncRowToFirestore(tableName: string, recordId: number | string): Promise<void> {
  try {
    const row = await get(`SELECT * FROM ${tableName} WHERE id = ?`, [recordId]);
    if (row) {
      await syncToFirestore(tableName, String(recordId), row);
    }
  } catch (err) {
    console.error(`Error syncing row ${recordId} in ${tableName} to Firestore:`, err);
  }
}

export async function deleteRowFromFirestore(tableName: string, recordId: number | string): Promise<void> {
  try {
    await deleteFromFirestore(tableName, String(recordId));
  } catch (err) {
    console.error(`Error deleting row ${recordId} in ${tableName} from Firestore:`, err);
  }
}

export async function get<T = any>(sql: string, params: any[] = []): Promise<T | undefined> {
  const db = await getDb();
  const stmt = db.prepare(sql);
  if (params && params.length > 0) {
    stmt.bind(params);
  }
  if (stmt.step()) {
    const row = stmt.getAsObject() as T;
    stmt.free();
    return row;
  }
  stmt.free();
  return undefined;
}

export async function all<T = any>(sql: string, params: any[] = []): Promise<T[]> {
  const db = await getDb();
  const stmt = db.prepare(sql);
  if (params && params.length > 0) {
    stmt.bind(params);
  }
  const rows: T[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject() as T);
  }
  stmt.free();
  return rows;
}

export async function initDb() {
  // 1. admins
  await run(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 2. employees
  await run(`
    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      nationality TEXT CHECK(nationality IN ('Saudi', 'Expat')) NOT NULL,
      iqama_number TEXT NOT NULL,
      iqama_expiry TEXT NOT NULL,
      passport_number TEXT NOT NULL,
      job_title TEXT NOT NULL,
      hire_date TEXT NOT NULL,
      basic_salary REAL NOT NULL DEFAULT 0,
      allowances REAL NOT NULL DEFAULT 0,
      insurance REAL NOT NULL DEFAULT 0,
      iban TEXT NOT NULL,
      pin_code TEXT DEFAULT NULL,
      status TEXT CHECK(status IN ('active', 'inactive')) NOT NULL DEFAULT 'active'
    )
  `);

  try { await run(`ALTER TABLE employees ADD COLUMN pin_code TEXT DEFAULT NULL`); } catch (_) {}
  try { await run(`ALTER TABLE employees ADD COLUMN phone_number TEXT DEFAULT NULL`); } catch (_) {}
  try { await run(`ALTER TABLE employees ADD COLUMN email TEXT DEFAULT NULL`); } catch (_) {}

  // 3. attendance
  await run(`
    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      time_in TEXT,
      time_out TEXT,
      FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE,
      UNIQUE(employee_id, date)
    )
  `);

  // 4. payroll
  await run(`
    CREATE TABLE IF NOT EXISTS payroll (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      period_start TEXT NOT NULL,
      period_end TEXT NOT NULL,
      basic_salary REAL NOT NULL,
      allowances REAL NOT NULL,
      present_days INTEGER DEFAULT 0,
      absent_days INTEGER DEFAULT 0,
      unpaid_leave_days INTEGER DEFAULT 0,
      deductions REAL NOT NULL DEFAULT 0,
      insurance_deduction REAL NOT NULL DEFAULT 0,
      cash_advance_deduction REAL NOT NULL DEFAULT 0,
      net_salary REAL NOT NULL,
      generated_date TEXT NOT NULL,
      FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )
  `);

  try { await run(`ALTER TABLE payroll ADD COLUMN present_days INTEGER DEFAULT 0`); } catch (_) {}
  try { await run(`ALTER TABLE payroll ADD COLUMN absent_days INTEGER DEFAULT 0`); } catch (_) {}
  try { await run(`ALTER TABLE payroll ADD COLUMN unpaid_leave_days INTEGER DEFAULT 0`); } catch (_) {}
  try { await run(`ALTER TABLE payroll ADD COLUMN overtime_hours REAL DEFAULT 0`); } catch (_) {}
  try { await run(`ALTER TABLE payroll ADD COLUMN overtime_pay REAL DEFAULT 0`); } catch (_) {}
  try { await run(`ALTER TABLE payroll ADD COLUMN overtime_rule_id INTEGER DEFAULT NULL`); } catch (_) {}
  try { await run(`ALTER TABLE payroll ADD COLUMN bonus_pay REAL DEFAULT 0`); } catch (_) {}
  try { await run(`ALTER TABLE payroll ADD COLUMN bonus_details TEXT DEFAULT NULL`); } catch (_) {}

  // 5. cash_advances
  await run(`
    CREATE TABLE IF NOT EXISTS cash_advances (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      amount REAL NOT NULL,
      balance REAL NOT NULL,
      monthly_deduction REAL NOT NULL,
      status TEXT CHECK(status IN ('active', 'paid')) NOT NULL DEFAULT 'active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )
  `);

  // 6. leave_requests
  await run(`
    CREATE TABLE IF NOT EXISTS leave_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      leave_type TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      reason TEXT,
      status TEXT CHECK(status IN ('pending', 'approved', 'rejected')) NOT NULL DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )
  `);

  // 7. notifications
  await run(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )
  `);

  // 8. overtime_rules
  await run(`
    CREATE TABLE IF NOT EXISTS overtime_rules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rule_name TEXT NOT NULL,
      multiplier REAL NOT NULL DEFAULT 1.5,
      description TEXT,
      is_active INTEGER DEFAULT 1
    )
  `);

  // 9. employee_bonuses
  await run(`
    CREATE TABLE IF NOT EXISTS employee_bonuses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      bonus_type TEXT NOT NULL,
      amount REAL NOT NULL,
      effective_date TEXT NOT NULL,
      description TEXT,
      status TEXT CHECK(status IN ('pending', 'processed', 'cancelled')) NOT NULL DEFAULT 'pending',
      payroll_id INTEGER DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )
  `);

  // Seed default Overtime Rules if empty
  const ruleCount = await get<{ count: number }>(`SELECT COUNT(*) as count FROM overtime_rules`);
  if (ruleCount && ruleCount.count === 0) {
    await run(
      `INSERT INTO overtime_rules (rule_name, multiplier, description) VALUES (?, ?, ?)`,
      ['Time-and-a-Half (1.5x)', 1.5, 'Standard workday overtime rate (150% hourly base rate)']
    );
    await run(
      `INSERT INTO overtime_rules (rule_name, multiplier, description) VALUES (?, ?, ?)`,
      ['Holiday / Friday Double-Time (2.0x)', 2.0, 'National holiday or Friday weekend shift (200% hourly base rate)']
    );
    await run(
      `INSERT INTO overtime_rules (rule_name, multiplier, description) VALUES (?, ?, ?)`,
      ['Weekend Shift (1.25x)', 1.25, 'Standard rest day weekend shift (125% hourly base rate)']
    );
  }

  // Seed default Admin if none exists
  const adminExists = await get(`SELECT id FROM admins WHERE username = 'admin'`);
  if (!adminExists) {
    const defaultPasswordHash = await bcrypt.hash('admin123', 10);
    await run(`INSERT INTO admins (username, password_hash) VALUES (?, ?)`, ['admin', defaultPasswordHash]);
    console.log('✅ Created default admin: username="admin", password="admin123"');
  }

  // Seed initial Employees if empty
  const empCount = await get<{ count: number }>(`SELECT COUNT(*) as count FROM employees`);
  if (empCount && empCount.count === 0) {
    const seedEmployees = [
      {
        employee_id: 'EMP-101',
        full_name: 'Fahad Abdullah Al-Otaibi',
        nationality: 'Saudi',
        iqama_number: '1084729103',
        iqama_expiry: '2027-04-15',
        passport_number: 'KSA-9284102',
        job_title: 'Senior Office Equipment Sales Specialist',
        hire_date: '2022-01-15',
        basic_salary: 6500,
        allowances: 1500,
        insurance: 300,
        iban: 'SA4280000001234567890101',
        status: 'active',
      },
      {
        employee_id: 'EMP-102',
        full_name: 'Muhammad Tariq Mahmood',
        nationality: 'Expat',
        iqama_number: '2491029384',
        iqama_expiry: '2026-08-30',
        passport_number: 'PK-7829104',
        job_title: 'Printer & Copier Maintenance Technician',
        hire_date: '2021-06-01',
        basic_salary: 4200,
        allowances: 800,
        insurance: 250,
        iban: 'SA1220000009876543210102',
        status: 'active',
      },
      {
        employee_id: 'EMP-103',
        full_name: 'Nouf Salem Al-Dosari',
        nationality: 'Saudi',
        iqama_number: '1029384756',
        iqama_expiry: '2028-01-10',
        passport_number: 'KSA-5510293',
        job_title: 'Administrative & Procurement Officer',
        hire_date: '2023-03-01',
        basic_salary: 5800,
        allowances: 1200,
        insurance: 300,
        iban: 'SA5510000003334445550103',
        status: 'active',
      },
      {
        employee_id: 'EMP-104',
        full_name: 'Rahul Ramesh Kumar',
        nationality: 'Expat',
        iqama_number: '2384710293',
        iqama_expiry: '2026-12-20',
        passport_number: 'IN-8839201',
        job_title: 'Warehouse & Logistics Coordinator',
        hire_date: '2022-09-10',
        basic_salary: 3800,
        allowances: 700,
        insurance: 200,
        iban: 'SA9040000001112223330104',
        status: 'active',
      },
      {
        employee_id: 'EMP-105',
        full_name: 'Anas Ibrahim Al-Mansoor',
        nationality: 'Saudi',
        iqama_number: '1092837465',
        iqama_expiry: '2027-11-05',
        passport_number: 'KSA-3382910',
        job_title: 'IT & Digital Office Solutions Specialist',
        hire_date: '2023-08-15',
        basic_salary: 6000,
        allowances: 1400,
        insurance: 300,
        iban: 'SA1030000006667778880105',
        status: 'active',
      },
    ];

    for (const emp of seedEmployees) {
      await run(
        `INSERT INTO employees (employee_id, full_name, nationality, iqama_number, iqama_expiry, passport_number, job_title, hire_date, basic_salary, allowances, insurance, iban, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          emp.employee_id,
          emp.full_name,
          emp.nationality,
          emp.iqama_number,
          emp.iqama_expiry,
          emp.passport_number,
          emp.job_title,
          emp.hire_date,
          emp.basic_salary,
          emp.allowances,
          emp.insurance,
          emp.iban,
          emp.status,
        ]
      );
    }

    // Seed sample attendance for today
    const today = new Date().toISOString().split('T')[0];
    await run(
      `INSERT INTO attendance (employee_id, date, time_in, time_out) VALUES (1, ?, '08:15:00', '17:02:00')`,
      [today]
    );
    await run(
      `INSERT INTO attendance (employee_id, date, time_in, time_out) VALUES (2, ?, '08:28:00', NULL)`,
      [today]
    );
    await run(
      `INSERT INTO attendance (employee_id, date, time_in, time_out) VALUES (3, ?, '08:00:00', '17:00:00')`,
      [today]
    );

    // Seed sample cash advance
    await run(
      `INSERT INTO cash_advances (employee_id, amount, balance, monthly_deduction, status)
       VALUES (2, 3000, 2000, 500, 'active')`
    );

    // Seed sample leave request
    await run(
      `INSERT INTO leave_requests (employee_id, leave_type, start_date, end_date, reason, status)
       VALUES (4, 'Annual', '2026-08-01', '2026-08-15', 'Annual family visit vacation', 'pending')`
    );

    console.log('✅ Seeded default employees, attendance, cash advances, and leave requests.');
  }

  // Initial Sync with Firebase Firestore
  try {
    const tables = ['employees', 'attendance', 'payroll', 'cash_advances', 'leave_requests', 'overtime_rules', 'employee_bonuses', 'notifications', 'admins'];
    for (const table of tables) {
      const rows = await all(`SELECT * FROM ${table}`);
      for (const row of rows) {
        if (row.id) {
          await syncToFirestore(table, String(row.id), row);
        }
      }
    }
    console.log('🔥 Initialized & synced all database tables with Firebase Firestore.');
  } catch (err) {
    console.error('Firestore initial sync error:', err);
  }
}

