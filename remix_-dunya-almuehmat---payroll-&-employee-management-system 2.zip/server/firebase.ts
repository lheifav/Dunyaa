import { Firestore } from '@google-cloud/firestore';
import fs from 'fs';
import path from 'path';

let firestoreInstance: Firestore | null = null;
let isFirestoreAvailable = false;

export function getFirestoreInstance(): Firestore | null {
  if (firestoreInstance) return firestoreInstance;

  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      firestoreInstance = new Firestore({
        projectId: config.projectId,
        databaseId: config.firestoreDatabaseId || undefined,
      });
      isFirestoreAvailable = true;
      console.log(`🔥 Firebase Firestore initialized successfully (Project: ${config.projectId}, Database: ${config.firestoreDatabaseId})`);
    } else {
      console.warn('⚠️ firebase-applet-config.json not found, falling back to SQLite persistent mode');
    }
  } catch (err) {
    console.error('❌ Firestore initialization error:', err);
    firestoreInstance = null;
    isFirestoreAvailable = false;
  }

  return firestoreInstance;
}

export function isFirebaseReady(): boolean {
  if (!firestoreInstance) {
    getFirestoreInstance();
  }
  return isFirestoreAvailable;
}

// Firestore Helper Functions for CRUD sync
export async function syncToFirestore(collectionName: string, docId: string, data: Record<string, any>): Promise<void> {
  const db = getFirestoreInstance();
  if (!db) return;
  try {
    const cleanData = { ...data, updatedAt: new Date().toISOString() };
    await db.collection(collectionName).doc(docId).set(cleanData, { merge: true });
  } catch (err) {
    console.error(`Error writing to Firestore collection ${collectionName} [doc: ${docId}]:`, err);
  }
}

export async function deleteFromFirestore(collectionName: string, docId: string): Promise<void> {
  const db = getFirestoreInstance();
  if (!db) return;
  try {
    await db.collection(collectionName).doc(docId).delete();
  } catch (err) {
    console.error(`Error deleting from Firestore collection ${collectionName} [doc: ${docId}]:`, err);
  }
}

export async function fetchCollectionFromFirestore<T = any>(collectionName: string): Promise<T[]> {
  const db = getFirestoreInstance();
  if (!db) return [];
  try {
    const snapshot = await db.collection(collectionName).get();
    return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as T));
  } catch (err) {
    console.error(`Error reading from Firestore collection ${collectionName}:`, err);
    return [];
  }
}
